// Q.2) Write a program to find the specific location of an Android device and display details of the place like Address line, city with Geocoding.
// File Name: MainActivity.java
// File Path: src/main/java/com/example/geocodingapp/MainActivity.java

package com.example.geocodingapp;

import android.Manifest;
import android.annotation.SuppressLint;
import android.content.Context;
import android.content.pm.PackageManager;
import android.location.Address;
import android.location.Geocoder;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import java.io.IOException;
import java.util.List;
import java.util.Locale;

public class MainActivity extends AppCompatActivity implements LocationListener {

    private static final int LOCATION_PERMISSION_REQUEST_CODE = 200;

    private TextView tvCoordinates, tvCity, tvFullAddress;
    private Button btnGetLocation;
    private LocationManager locationManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Bind layout views
        tvCoordinates = findViewById(R.id.tvCoordinates);
        tvCity = findViewById(R.id.tvCity);
        tvFullAddress = findViewById(R.id.tvFullAddress);
        btnGetLocation = findViewById(R.id.btnGetLocation);

        locationManager = (LocationManager) getSystemService(Context.LOCATION_SERVICE);

        btnGetLocation.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                checkPermissionAndGetLocation();
            }
        });
    }

    private void checkPermissionAndGetLocation() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED
                && ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {

            ActivityCompat.requestPermissions(this,
                    new String[]{Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION},
                    LOCATION_PERMISSION_REQUEST_CODE);
        } else {
            fetchDeviceLocation();
        }
    }

    @SuppressLint("MissingPermission")
    private void fetchDeviceLocation() {
        boolean isGpsEnabled = locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER);
        boolean isNetworkEnabled = locationManager.isProviderEnabled(LocationManager.NETWORK_PROVIDER);

        if (!isGpsEnabled && !isNetworkEnabled) {
            Toast.makeText(this, "Please enable GPS/Location Services", Toast.LENGTH_SHORT).show();
            return;
        }

        Toast.makeText(this, "Fetching current location...", Toast.LENGTH_SHORT).show();

        // Check Network Provider first for faster indoor lock
        if (isNetworkEnabled) {
            locationManager.requestSingleUpdate(LocationManager.NETWORK_PROVIDER, this, null);
        } else if (isGpsEnabled) {
            locationManager.requestSingleUpdate(LocationManager.GPS_PROVIDER, this, null);
        }

        // Try last known location as immediate fallback
        Location lastKnown = locationManager.getLastKnownLocation(LocationManager.NETWORK_PROVIDER);
        if (lastKnown == null) {
            lastKnown = locationManager.getLastKnownLocation(LocationManager.GPS_PROVIDER);
        }

        if (lastKnown != null) {
            updateLocationAndAddress(lastKnown.getLatitude(), lastKnown.getLongitude());
        }
    }

    // Geocoding: Converts Latitude and Longitude into a readable address and city
    private void updateLocationAndAddress(double latitude, double longitude) {
        tvCoordinates.setText(String.format(Locale.getDefault(), "Coordinates: Lat %.4f, Lon %.4f", latitude, longitude));

        Geocoder geocoder = new Geocoder(MainActivity.this, Locale.getDefault());
        try {
            List<Address> addresses = geocoder.getFromLocation(latitude, longitude, 1);

            if (addresses != null && !addresses.isEmpty()) {
                Address addressObj = addresses.get(0);

                String addressLine = addressObj.getAddressLine(0);
                String city = addressObj.getLocality();

                tvCity.setText("City: " + (city != null ? city : "N/A"));
                tvFullAddress.setText("Address Line:\n" + addressLine);
            } else {
                tvCity.setText("City: Unable to detect");
                tvFullAddress.setText("Address Line: Geocoder returned no address.");
            }
        } catch (IOException e) {
            tvFullAddress.setText("Address Line: Geocoding service unavailable (Check Internet).");
        }
    }

    @Override
    public void onLocationChanged(@NonNull Location location) {
        updateLocationAndAddress(location.getLatitude(), location.getLongitude());
    }

    @Override
    public void onProviderEnabled(@NonNull String provider) {}

    @Override
    public void onProviderDisabled(@NonNull String provider) {}

    @Override
    public void onStatusChanged(String provider, int status, Bundle extras) {}

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == LOCATION_PERMISSION_REQUEST_CODE) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                fetchDeviceLocation();
            } else {
                Toast.makeText(this, "Location permission denied", Toast.LENGTH_SHORT).show();
            }
        }
    }
}