// Q.1) Create an Android Application that Demonstrate Radio Button. [10 Marks]
// File Name: MainActivity.java
// File Path: src/main/java/com/example/radiobuttonapp/MainActivity.java

package com.example.radiobuttonapp;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private RadioGroup rgCourses;
    private Button btnSubmit;
    private TextView tvSelectedCourse;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Bind layout views
        rgCourses = findViewById(R.id.rgCourses);
        btnSubmit = findViewById(R.id.btnSubmit);
        tvSelectedCourse = findViewById(R.id.tvSelectedCourse);

        // 1. Dynamic listener when selection changes directly in the RadioGroup
        rgCourses.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId) {
                RadioButton selectedRadio = findViewById(checkedId);
                if (selectedRadio != null) {
                    String selectedText = selectedRadio.getText().toString();
                    tvSelectedCourse.setText("Selected: " + selectedText);
                }
            }
        });

        // 2. Explicit button click to read and confirm selection
        btnSubmit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int selectedId = rgCourses.getCheckedRadioButtonId();

                if (selectedId == -1) {
                    Toast.makeText(MainActivity.this, "Please select an option", Toast.LENGTH_SHORT).show();
                } else {
                    RadioButton selectedRadio = findViewById(selectedId);
                    String courseName = selectedRadio.getText().toString();

                    tvSelectedCourse.setText("Confirmed: " + courseName);
                    Toast.makeText(MainActivity.this, "Selected: " + courseName, Toast.LENGTH_SHORT).show();
                }
            }
        });
    }
}