// Q.2) Create Table Student (Rollno, Name, Class, contact). Create an Android Application for performing the insert and display operation on the table. (Using SQLite Database). [20 Marks]
// File Name: DatabaseHelper.java
// File Path: src/main/java/com/example/studentsqliteapp/DatabaseHelper.java

package com.example.studentsqliteapp;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class DatabaseHelper extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "StudentRecords.db";
    private static final int DATABASE_VERSION = 1;

    public static final String TABLE_NAME = "Student";
    public static final String COL_ROLLNO = "Rollno";
    public static final String COL_NAME = "Name";
    public static final String COL_CLASS = "Class";
    public static final String COL_CONTACT = "contact";

    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String createTableQuery = "CREATE TABLE " + TABLE_NAME + " ("
                + COL_ROLLNO + " INTEGER PRIMARY KEY, "
                + COL_NAME + " TEXT, "
                + COL_CLASS + " TEXT, "
                + COL_CONTACT + " TEXT)";
        db.execSQL(createTableQuery);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_NAME);
        onCreate(db);
    }

    // Insert Operation
    public boolean insertStudent(int rollno, String name, String className, String contact) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(COL_ROLLNO, rollno);
        contentValues.put(COL_NAME, name);
        contentValues.put(COL_CLASS, className);
        contentValues.put(COL_CONTACT, contact);

        long result = db.insert(TABLE_NAME, null, contentValues);
        return result != -1;
    }

    // Display Operation
    public Cursor getAllStudents() {
        SQLiteDatabase db = this.getReadableDatabase();
        return db.rawQuery("SELECT * FROM " + TABLE_NAME, null);
    }
}