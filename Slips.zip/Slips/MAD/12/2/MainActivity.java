// Q.2) Create Table Student (Rollno, Name, Class, contact). Create an Android Application for performing the insert and display operation on the table. (Using SQLite Database). [20 Marks]
// File Name: MainActivity.java
// File Path: src/main/java/com/example/studentsqliteapp/MainActivity.java

package com.example.studentsqliteapp;

import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private DatabaseHelper dbHelper;
    private EditText etRollno, etName, etClass, etContact;
    private Button btnInsert, btnDisplay;
    private TextView tvDisplayData;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        dbHelper = new DatabaseHelper(this);

        // Bind layout views
        etRollno = findViewById(R.id.etRollno);
        etName = findViewById(R.id.etName);
        etClass = findViewById(R.id.etClass);
        etContact = findViewById(R.id.etContact);
        btnInsert = findViewById(R.id.btnInsert);
        btnDisplay = findViewById(R.id.btnDisplay);
        tvDisplayData = findViewById(R.id.tvDisplayData);

        // Handle Insert Operation
        btnInsert.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                insertRecord();
            }
        });

        // Handle Display Operation
        btnDisplay.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                displayRecords();
            }
        });
    }

    private void insertRecord() {
        String rollnoStr = etRollno.getText().toString().trim();
        String name = etName.getText().toString().trim();
        String className = etClass.getText().toString().trim();
        String contact = etContact.getText().toString().trim();

        // Validate empty fields
        if (rollnoStr.isEmpty() || name.isEmpty() || className.isEmpty() || contact.isEmpty()) {
            Toast.makeText(MainActivity.this, "Please enter all details", Toast.LENGTH_SHORT).show();
            return;
        }

        int rollno = Integer.parseInt(rollnoStr);
        boolean isInserted = dbHelper.insertStudent(rollno, name, className, contact);

        if (isInserted) {
            Toast.makeText(MainActivity.this, "Record Inserted Successfully", Toast.LENGTH_SHORT).show();
            etRollno.setText("");
            etName.setText("");
            etClass.setText("");
            etContact.setText("");
        } else {
            Toast.makeText(MainActivity.this, "Insertion Failed (Rollno already exists)", Toast.LENGTH_SHORT).show();
        }
    }

    private void displayRecords() {
        Cursor cursor = dbHelper.getAllStudents();

        if (cursor == null || cursor.getCount() == 0) {
            tvDisplayData.setText("No student records found in database.");
            Toast.makeText(MainActivity.this, "No records found", Toast.LENGTH_SHORT).show();
            return;
        }

        StringBuilder stringBuilder = new StringBuilder();
        while (cursor.moveToNext()) {
            int rollno = cursor.getInt(0);
            String name = cursor.getString(1);
            String className = cursor.getString(2);
            String contact = cursor.getString(3);

            stringBuilder.append("Roll No : ").append(rollno).append("\n");
            stringBuilder.append("Name    : ").append(name).append("\n");
            stringBuilder.append("Class   : ").append(className).append("\n");
            stringBuilder.append("Contact : ").append(contact).append("\n");
            stringBuilder.append("------------------------------------\n");
        }
        cursor.close();

        tvDisplayData.setText(stringBuilder.toString());
    }
}