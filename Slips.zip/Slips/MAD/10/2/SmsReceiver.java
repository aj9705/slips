// Q.2) Create an application to send and receive messages using SMS Manager
// File Name: SmsReceiver.java
// File Path: src/main/java/com/example/smsapp/SmsReceiver.java

package com.example.smsapp;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.telephony.SmsMessage;
import android.widget.Toast;

public class SmsReceiver extends BroadcastReceiver {

    // Interface to pass received SMS directly to MainActivity
    public interface SmsListener {
        void onSmsReceived(String sender, String message);
    }

    private static SmsListener listener;

    public static void setListener(SmsListener smsListener) {
        listener = smsListener;
    }

    @Override
    public void onReceive(Context context, Intent intent) {
        if ("android.provider.Telephony.SMS_RECEIVED".equals(intent.getAction())) {
            Bundle bundle = intent.getExtras();
            if (bundle != null) {
                // Read PDUs from extras
                Object[] pdus = (Object[]) bundle.get("pdus");
                String format = bundle.getString("format");

                if (pdus != null) {
                    for (Object pdu : pdus) {
                        SmsMessage smsMessage;
                        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.M) {
                            smsMessage = SmsMessage.createFromPdu((byte[]) pdu, format);
                        } else {
                            smsMessage = SmsMessage.createFromPdu((byte[]) pdu);
                        }

                        String sender = smsMessage.getDisplayOriginatingAddress();
                        String messageBody = smsMessage.getMessageBody();

                        Toast.makeText(context, "SMS from: " + sender + "\n" + messageBody, Toast.LENGTH_LONG).show();

                        if (listener != null) {
                            listener.onSmsReceived(sender, messageBody);
                        }
                    }
                }
            }
        }
    }
}