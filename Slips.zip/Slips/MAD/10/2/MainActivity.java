// Q.2) Create an application to send and receive messages using SMS Manager
// File Name: MainActivity.java
// File Path: src/main/java/com/example/smsapp/MainActivity.java

package com.example.smsapp;

import android.Manifest;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

public class MainActivity extends AppCompatActivity implements SmsReceiver.SmsListener {

    private static final int PERMISSION_REQUEST_CODE = 100;

    private EditText etPhoneNumber, etMessageBody;
    private Button btnSendSms;
    private TextView tvReceivedSms;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Bind layout views
        etPhoneNumber = findViewById(R.id.etPhoneNumber);
        etMessageBody = findViewById(R.id.etMessageBody);
        btnSendSms = findViewById(R.id.btnSendSms);
        tvReceivedSms = findViewById(R.id.tvReceivedSms);

        // Register listener for incoming SMS from SmsReceiver
        SmsReceiver.setListener(this);

        // Check runtime permissions on startup
        checkPermissions();

        // Send SMS click listener
        btnSendSms.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                sendSmsMessage();
            }
        });
    }

    private void checkPermissions() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS) != PackageManager.PERMISSION_GRANTED ||
            ContextCompat.checkSelfPermission(this, Manifest.permission.RECEIVE_SMS) != PackageManager.PERMISSION_GRANTED ||
            ContextCompat.checkSelfPermission(this, Manifest.permission.READ_SMS) != PackageManager.PERMISSION_GRANTED) {

            ActivityCompat.requestPermissions(
                    this,
                    new String[]{
                            Manifest.permission.SEND_SMS,
                            Manifest.permission.RECEIVE_SMS,
                            Manifest.permission.READ_SMS
                    },
                    PERMISSION_REQUEST_CODE
            );
        }
    }

    private void sendSmsMessage() {
        String phoneNumber = etPhoneNumber.getText().toString().trim();
        String message = etMessageBody.getText().toString().trim();

        if (phoneNumber.isEmpty() || message.isEmpty()) {
            Toast.makeText(this, "Please enter phone number and message", Toast.LENGTH_SHORT).show();
            return;
        }

        // Verify permission before attempting to send
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS) == PackageManager.PERMISSION_GRANTED) {
            try {
                // Get default instance of SmsManager
                SmsManager smsManager = SmsManager.getDefault();
                smsManager.sendTextMessage(phoneNumber, null, message, null, null);

                Toast.makeText(this, "SMS Sent Successfully!", Toast.LENGTH_SHORT).show();
                etMessageBody.setText("");
            } catch (Exception e) {
                Toast.makeText(this, "Failed to send SMS: " + e.getMessage(), Toast.LENGTH_SHORT).show();
            }
        } else {
            Toast.makeText(this, "SEND_SMS permission not granted", Toast.LENGTH_SHORT).show();
            checkPermissions();
        }
    }

    // Callback invoked when SmsReceiver receives an incoming message
    @Override
    public void onSmsReceived(String sender, String message) {
        String log = "Sender: " + sender + "\nMessage: " + message + "\n------------------------------------\n";
        tvReceivedSms.append("\n" + log);
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == PERMISSION_REQUEST_CODE) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                Toast.makeText(this, "SMS Permissions Granted", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(this, "SMS Permissions Denied", Toast.LENGTH_SHORT).show();
            }
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        SmsReceiver.setListener(null);
    }
}