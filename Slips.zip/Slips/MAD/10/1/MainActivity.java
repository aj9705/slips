// Q.1) Create an application that Demonstrates List View and Onclick of List Display with Toast Message. [10 Marks]
// File Name: MainActivity.java
// File Path: src/main/java/com/example/listviewtoastapp/MainActivity.java

package com.example.listviewtoastapp;

import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private ListView listView;

    // Array containing items shown in the screenshot[cite: 4]
    private String[] technologies = {
            "Android",
            "Java",
            "Php",
            "Hadoop",
            "Sap",
            "Python",
            "Ajax",
            "C++",
            "Ruby",
            "Rails",
            ".Net"
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Bind ListView
        listView = findViewById(R.id.listView);

        // Initialize ArrayAdapter with built-in Android list item layout
        ArrayAdapter<String> adapter = new ArrayAdapter<>(
                this,
                android.R.layout.simple_list_item_1,
                technologies
        );

        // Attach adapter to ListView
        listView.setAdapter(adapter);

        // Set click listener to display Toast message on item click[cite: 4]
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                String selectedItem = technologies[position];
                Toast.makeText(MainActivity.this, selectedItem, Toast.LENGTH_SHORT).show();
            }
        });
    }
}