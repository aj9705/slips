// Q.2) Create Tables Student (roll_no, name, percentage). Using database perform following operation.
// 1) Add new record into table.
// 2) Display information of students passes with first class.
// File Name: MainActivity.java
// File Path: src/main/java/com/example/studentfirstclassapp/MainActivity.java

package com.example.studentfirstclassapp;

import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

import java.util.Locale;

public class MainActivity extends AppCompatActivity {

    private DatabaseHelper dbHelper;
    private EditText etRollNo, etName, etPercentage;
    private Button btnAddStudent, btnDisplayFirstClass;
    private TextView tvDisplayResults;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        dbHelper = new DatabaseHelper(this);

        // Bind layout views
        etRollNo = findViewById(R.id.etRollNo);
        etName = findViewById(R.id.etName);
        etPercentage = findViewById(R.id.etPercentage);
        btnAddStudent = findViewById(R.id.btnAddStudent);
        btnDisplayFirstClass = findViewById(R.id.btnDisplayFirstClass);
        tvDisplayResults = findViewById(R.id.tvDisplayResults);

        // 1) Add new student record
        btnAddStudent.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                insertStudentRecord();
            }
        });

        // 2) Display students passing with first class (>= 60%)
        btnDisplayFirstClass.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                displayFirstClassStudents();
            }
        });
    }

    private void insertStudentRecord() {
        String rollNoStr = etRollNo.getText().toString().trim();
        String name = etName.getText().toString().trim();
        String percentageStr = etPercentage.getText().toString().trim();

        if (rollNoStr.isEmpty() || name.isEmpty() || percentageStr.isEmpty()) {
            Toast.makeText(MainActivity.this, "Please enter all fields", Toast.LENGTH_SHORT).show();
            return;
        }

        try {
            int rollNo = Integer.parseInt(rollNoStr);
            double percentage = Double.parseDouble(percentageStr);

            if (percentage < 0.0 || percentage > 100.0) {
                Toast.makeText(MainActivity.this, "Percentage must be between 0 and 100", Toast.LENGTH_SHORT).show();
                return;
            }

            boolean isInserted = dbHelper.insertStudent(rollNo, name, percentage);

            if (isInserted) {
                Toast.makeText(MainActivity.this, "Student record added successfully", Toast.LENGTH_SHORT).show();
                etRollNo.setText("");
                etName.setText("");
                etPercentage.setText("");
            } else {
                Toast.makeText(MainActivity.this, "Insertion failed (Roll No already exists)", Toast.LENGTH_SHORT).show();
            }
        } catch (NumberFormatException e) {
            Toast.makeText(MainActivity.this, "Invalid Roll No or Percentage format", Toast.LENGTH_SHORT).show();
        }
    }

    private void displayFirstClassStudents() {
        Cursor cursor = dbHelper.getFirstClassStudents();

        if (cursor == null || cursor.getCount() == 0) {
            tvDisplayResults.setText("No students found passing with First Class (>= 60%).");
            Toast.makeText(MainActivity.this, "No First Class records found", Toast.LENGTH_SHORT).show();
            return;
        }

        StringBuilder sb = new StringBuilder();
        sb.append("Students with First Class (>= 60%):\n");
        sb.append("====================================\n");

        while (cursor.moveToNext()) {
            int rollNo = cursor.getInt(0);
            String name = cursor.getString(1);
            double percentage = cursor.getDouble(2);

            sb.append("Roll No    : ").append(rollNo).append("\n");
            sb.append("Name       : ").append(name).append("\n");
            sb.append(String.format(Locale.getDefault(), "Percentage : %.2f%%\n", percentage));
            sb.append("------------------------------------\n");
        }
        cursor.close();

        tvDisplayResults.setText(sb.toString());
    }
}