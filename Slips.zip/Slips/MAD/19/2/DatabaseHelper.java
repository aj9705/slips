// Q.2) Create Tables Student (roll_no, name, percentage). Using database perform following operation.
// 1) Add new record into table.
// 2) Display information of students passes with first class.
// File Name: DatabaseHelper.java
// File Path: src/main/java/com/example/studentfirstclassapp/DatabaseHelper.java

package com.example.studentfirstclassapp;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class DatabaseHelper extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "StudentDB.db";
    private static final int DATABASE_VERSION = 1;

    public static final String TABLE_NAME = "Student";
    public static final String COL_ROLL_NO = "roll_no";
    public static final String COL_NAME = "name";
    public static final String COL_PERCENTAGE = "percentage";

    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String createTableQuery = "CREATE TABLE " + TABLE_NAME + " ("
                + COL_ROLL_NO + " INTEGER PRIMARY KEY, "
                + COL_NAME + " TEXT, "
                + COL_PERCENTAGE + " REAL)";
        db.execSQL(createTableQuery);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_NAME);
        onCreate(db);
    }

    // 1) Add new record into table
    public boolean insertStudent(int rollNo, String name, double percentage) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COL_ROLL_NO, rollNo);
        values.put(COL_NAME, name);
        values.put(COL_PERCENTAGE, percentage);

        long result = db.insert(TABLE_NAME, null, values);
        return result != -1;
    }

    // 2) Display information of students passing with First Class (percentage >= 60.0)
    public Cursor getFirstClassStudents() {
        SQLiteDatabase db = this.getReadableDatabase();
        String query = "SELECT * FROM " + TABLE_NAME + " WHERE " + COL_PERCENTAGE + " >= 60.0 ORDER BY " + COL_PERCENTAGE + " DESC";
        return db.rawQuery(query, null);
    }
}