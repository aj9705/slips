// Q.1) Create application to search a specific location on Google Map.
// File Name: MainActivity.java
// File Path: src/main/java/com/example/mapsearchapp/MainActivity.java

package com.example.mapsearchapp;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private EditText etLocationQuery;
    private Button btnSearchMap;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Bind layout views
        etLocationQuery = findViewById(R.id.etLocationQuery);
        btnSearchMap = findViewById(R.id.btnSearchMap);

        btnSearchMap.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                searchLocationOnMap();
            }
        });
    }

    private void searchLocationOnMap() {
        String location = etLocationQuery.getText().toString().trim();

        if (location.isEmpty()) {
            Toast.makeText(MainActivity.this, "Please enter a location to search", Toast.LENGTH_SHORT).show();
            return;
        }

        // Create a URI using geo intent scheme with encoded query
        Uri gmmIntentUri = Uri.parse("geo:0,0?q=" + Uri.encode(location));

        // Create an Intent with ACTION_VIEW
        Intent mapIntent = new Intent(Intent.ACTION_VIEW, gmmIntentUri);

        // Explicitly set package to Google Maps to open the Maps app directly
        mapIntent.setPackage("com.google.android.apps.maps");

        try {
            startActivity(mapIntent);
        } catch (android.content.ActivityNotFoundException e) {
            // Fallback: If Google Maps app is not installed, open via browser or chooser
            Intent fallbackMapIntent = new Intent(Intent.ACTION_VIEW, gmmIntentUri);
            try {
                startActivity(Intent.createChooser(fallbackMapIntent, "Select Maps Application"));
            } catch (Exception ex) {
                Toast.makeText(MainActivity.this, "No map application or browser available", Toast.LENGTH_SHORT).show();
            }
        }
    }
}