// Q.2] Create an Android Application to perform following string operation according to user selection of radio button.
// File Name: MainActivity.java
// File Path: src/main/java/com/example/stringoperationapp/MainActivity.java

package com.example.stringoperationapp;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private EditText etInputString, etOutputString;
    private RadioGroup rgOperations;
    private RadioButton rbUppercase, rbLowercase, rbRight5, rbLeft5;
    private Button btnClick;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Bind layout views
        etInputString = findViewById(R.id.etInputString);
        etOutputString = findViewById(R.id.etOutputString);
        rgOperations = findViewById(R.id.rgOperations);
        rbUppercase = findViewById(R.id.rbUppercase);
        rbLowercase = findViewById(R.id.rbLowercase);
        rbRight5 = findViewById(R.id.rbRight5);
        rbLeft5 = findViewById(R.id.rbLeft5);
        btnClick = findViewById(R.id.btnClick);

        btnClick.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String input = etInputString.getText().toString();

                if (input.isEmpty()) {
                    Toast.makeText(MainActivity.this, "Please enter a string", Toast.LENGTH_SHORT).show();
                    return;
                }

                String result = "";

                if (rbUppercase.isChecked()) {
                    result = input.toUpperCase();
                } else if (rbLowercase.isChecked()) {
                    result = input.toLowerCase();
                } else if (rbRight5.isChecked()) {
                    if (input.length() >= 5) {
                        result = input.substring(input.length() - 5);
                    } else {
                        result = input; // If length is less than 5, return entire string
                    }
                } else if (rbLeft5.isChecked()) {
                    if (input.length() >= 5) {
                        result = input.substring(0, 5);
                    } else {
                        result = input; // If length is less than 5, return entire string
                    }
                }

                etOutputString.setText(result);
            }
        });
    }
}