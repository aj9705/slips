// Q.1] Create an Android Application to accept two numbers to calculate it’s Power and Average.
// Create two buttons: Power and Average.
// Display the appropriate result on the next activity on Button click.
// File Name: MainActivity.java
// File Path: src/main/java/com/example/poweravgapp/MainActivity.java

package com.example.poweravgapp;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private EditText etFirstNumber, etSecondNumber;
    private Button btnPower, btnAverage;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        etFirstNumber = findViewById(R.id.etFirstNumber);
        etSecondNumber = findViewById(R.id.etSecondNumber);
        btnPower = findViewById(R.id.btnPower);
        btnAverage = findViewById(R.id.btnAverage);

        // Power calculation click listener
        btnPower.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                processAndNavigate("Power");
            }
        });

        // Average calculation click listener
        btnAverage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                processAndNavigate("Average");
            }
        });
    }

    private void processAndNavigate(String operation) {
        String num1Str = etFirstNumber.getText().toString().trim();
        String num2Str = etSecondNumber.getText().toString().trim();

        if (num1Str.isEmpty() || num2Str.isEmpty()) {
            Toast.makeText(MainActivity.this, "Please enter both numbers", Toast.LENGTH_SHORT).show();
            return;
        }

        double num1 = Double.parseDouble(num1Str);
        double num2 = Double.parseDouble(num2Str);
        double result = 0;

        if (operation.equals("Power")) {
            result = Math.pow(num1, num2);
        } else if (operation.equals("Average")) {
            result = (num1 + num2) / 2.0;
        }

        // Pass calculated details to ResultActivity via Intent
        Intent intent = new Intent(MainActivity.this, ResultActivity.class);
        intent.putExtra("OPERATION", operation);
        intent.putExtra("NUM1", num1);
        intent.putExtra("NUM2", num2);
        intent.putExtra("RESULT", result);
        startActivity(intent);
    }
}