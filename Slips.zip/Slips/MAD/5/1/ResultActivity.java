// Q.1] Create an Android Application to accept two numbers to calculate it’s Power and Average.
// Create two buttons: Power and Average.
// Display the appropriate result on the next activity on Button click.
// File Name: ResultActivity.java
// File Path: src/main/java/com/example/poweravgapp/ResultActivity.java

package com.example.poweravgapp;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class ResultActivity extends AppCompatActivity {

    private TextView tvOperationTitle, tvInputValues, tvFinalResult;
    private Button btnBack;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_result);

        tvOperationTitle = findViewById(R.id.tvOperationTitle);
        tvInputValues = findViewById(R.id.tvInputValues);
        tvFinalResult = findViewById(R.id.tvFinalResult);
        btnBack = findViewById(R.id.btnBack);

        // Retrieve data sent from MainActivity
        Intent intent = getIntent();
        String operation = intent.getStringExtra("OPERATION");
        double num1 = intent.getDoubleExtra("NUM1", 0.0);
        double num2 = intent.getDoubleExtra("NUM2", 0.0);
        double result = intent.getDoubleExtra("RESULT", 0.0);

        tvOperationTitle.setText(operation + " Calculation");
        tvInputValues.setText("First Number: " + num1 + "\nSecond Number: " + num2);
        tvFinalResult.setText("Calculated " + operation + ": " + result);

        btnBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish(); // Returns to MainActivity
            }
        });
    }
}