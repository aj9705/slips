// Q.1) Create an application that allows the user to enter a number in the textbox. Check whether the number in the textbox is Armstrong or not. Print the message accordingly in the label control.
// File Name: MainActivity.java
// File Path: src/main/java/com/example/armstrongapp/MainActivity.java

package com.example.armstrongapp;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private EditText etNumber;
    private Button btnCheck;
    private TextView tvResult;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Bind layout controls
        etNumber = findViewById(R.id.etNumber);
        btnCheck = findViewById(R.id.btnCheck);
        tvResult = findViewById(R.id.tvResult);

        btnCheck.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                checkArmstrongNumber();
            }
        });
    }

    private void checkArmstrongNumber() {
        String input = etNumber.getText().toString().trim();

        if (input.isEmpty()) {
            Toast.makeText(MainActivity.this, "Please enter a number in the textbox", Toast.LENGTH_SHORT).show();
            return;
        }

        try {
            int originalNumber = Integer.parseInt(input);

            if (originalNumber < 0) {
                tvResult.setText(originalNumber + " is NOT an Armstrong number (Negative number).");
                return;
            }

            int digitsCount = String.valueOf(originalNumber).length();
            int temp = originalNumber;
            int sum = 0;

            // Compute sum of each digit raised to the power of total digits
            while (temp > 0) {
                int remainder = temp % 10;
                sum += Math.pow(remainder, digitsCount);
                temp /= 10;
            }

            // Print the result message in the label control (TextView)
            if (sum == originalNumber) {
                tvResult.setText(originalNumber + " is an Armstrong Number!");
            } else {
                tvResult.setText(originalNumber + " is NOT an Armstrong Number.");
            }

        } catch (NumberFormatException e) {
            Toast.makeText(MainActivity.this, "Input number is too large", Toast.LENGTH_SHORT).show();
        }
    }
}