// Q.2) Create an application that demonstrate Options Menu, Context Menu and Popup Menu in android.
// File Name: MainActivity.java
// File Path: src/main/java/com/example/menudemoapp/MainActivity.java

package com.example.menudemoapp;

import android.os.Bundle;
import android.view.ContextMenu;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.PopupMenu;

public class MainActivity extends AppCompatActivity {

    private TextView tvContextMenuTarget;
    private Button btnShowPopup;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        tvContextMenuTarget = findViewById(R.id.tvContextMenuTarget);
        btnShowPopup = findViewById(R.id.btnShowPopup);

        // Register view for Context Menu (long press trigger)
        registerForContextMenu(tvContextMenuTarget);

        // Set listener for Popup Menu
        btnShowPopup.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showPopupMenu(v);
            }
        });
    }

    // ==========================================
    // 1. OPTIONS MENU IMPLEMENTATION
    // ==========================================
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.options_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        int id = item.getItemId();
        if (id == R.id.opt_settings) {
            Toast.makeText(this, "Options Menu: Settings selected", Toast.LENGTH_SHORT).show();
            return true;
        } else if (id == R.id.opt_search) {
            Toast.makeText(this, "Options Menu: Search selected", Toast.LENGTH_SHORT).show();
            return true;
        } else if (id == R.id.opt_about) {
            Toast.makeText(this, "Options Menu: About Us selected", Toast.LENGTH_SHORT).show();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    // ==========================================
    // 2. CONTEXT MENU IMPLEMENTATION
    // ==========================================
    @Override
    public void onCreateContextMenu(ContextMenu menu, View v, ContextMenu.ContextMenuInfo menuInfo) {
        super.onCreateContextMenu(menu, v, menuInfo);
        menu.setHeaderTitle("Context Menu Options");
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.context_menu, menu);
    }

    @Override
    public boolean onContextItemSelected(@NonNull MenuItem item) {
        int id = item.getItemId();
        if (id == R.id.ctx_edit) {
            Toast.makeText(this, "Context Menu: Edit selected", Toast.LENGTH_SHORT).show();
            return true;
        } else if (id == R.id.ctx_share) {
            Toast.makeText(this, "Context Menu: Share selected", Toast.LENGTH_SHORT).show();
            return true;
        } else if (id == R.id.ctx_delete) {
            Toast.makeText(this, "Context Menu: Delete selected", Toast.LENGTH_SHORT).show();
            return true;
        }
        return super.onContextItemSelected(item);
    }

    // ==========================================
    // 3. POPUP MENU IMPLEMENTATION
    // ==========================================
    private void showPopupMenu(View anchorView) {
        PopupMenu popup = new PopupMenu(MainActivity.this, anchorView);
        popup.getMenuInflater().inflate(R.menu.popup_menu, popup.getMenu());

        popup.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() {
            @Override
            public boolean onMenuItemClick(MenuItem item) {
                int id = item.getItemId();
                if (id == R.id.pop_reply) {
                    Toast.makeText(MainActivity.this, "Popup Menu: Reply clicked", Toast.LENGTH_SHORT).show();
                    return true;
                } else if (id == R.id.pop_forward) {
                    Toast.makeText(MainActivity.this, "Popup Menu: Forward clicked", Toast.LENGTH_SHORT).show();
                    return true;
                } else if (id == R.id.pop_dismiss) {
                    Toast.makeText(MainActivity.this, "Popup Menu: Dismiss clicked", Toast.LENGTH_SHORT).show();
                    return true;
                }
                return false;
            }
        });

        popup.show();
    }
}