// File: java/com/example/employeedb/MainActivity.java
package com.example.employeedb;

import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private DatabaseHelper databaseHelper;
    private Button btnInsert, btnView;
    private TextView tvDisplay;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        databaseHelper = new DatabaseHelper(this);
        btnInsert = findViewById(R.id.btnInsert);
        btnView = findViewById(R.id.btnView);
        tvDisplay = findViewById(R.id.tvDisplay);

        btnInsert.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                insertFiveEmployees();
            }
        });

        btnView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                displayAllEmployees();
            }
        });
    }

    private void insertFiveEmployees() {
        int[] eids = {1001, 1002, 1003, 1004, 1005};
        String[] names = {"Rajesh Sharma", "Pooja Mehta", "Vikas Gupta", "Sneha Kulkarni", "Amit Deshmukh"};
        String[] addresses = {"Pune", "Mumbai", "Nagpur", "Nashik", "Aurangabad"};
        String[] phoneNumbers = {"9876543210", "9123456780", "9988776655", "9811223344", "9765432109"};

        boolean allInserted = true;
        for (int i = 0; i < 5; i++) {
            boolean isInserted = databaseHelper.insertEmployeeRecord(
                    eids[i],
                    names[i],
                    addresses[i],
                    phoneNumbers[i]
            );
            if (!isInserted) {
                allInserted = false;
            }
        }

        if (allInserted) {
            Toast.makeText(MainActivity.this, "5 Employee Records Inserted Successfully", Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(MainActivity.this, "Failed or duplicate records found", Toast.LENGTH_SHORT).show();
        }
    }

    private void displayAllEmployees() {
        Cursor cursor = databaseHelper.getAllEmployees();

        if (cursor == null || cursor.getCount() == 0) {
            tvDisplay.setText("No records found in database.");
            return;
        }

        StringBuilder builder = new StringBuilder();
        while (cursor.moveToNext()) {
            int eid = cursor.getInt(cursor.getColumnIndexOrThrow(DatabaseHelper.COL_EID));
            String name = cursor.getString(cursor.getColumnIndexOrThrow(DatabaseHelper.COL_NAME));
            String address = cursor.getString(cursor.getColumnIndexOrThrow(DatabaseHelper.COL_ADDRESS));
            String phoNo = cursor.getString(cursor.getColumnIndexOrThrow(DatabaseHelper.COL_PHO_NO));

            builder.append("Employee ID: ").append(eid).append("\n")
                    .append("Name: ").append(name).append("\n")
                    .append("Address: ").append(address).append("\n")
                    .append("Phone No: ").append(phoNo).append("\n")
                    .append("------------------------------------\n");
        }
        cursor.close();

        tvDisplay.setText(builder.toString());
    }
}