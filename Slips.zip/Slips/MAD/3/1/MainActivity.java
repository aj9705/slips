// File: java/com/example/imageswitcher/MainActivity.java
package com.example.imageswitcher;

import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.AnimationUtils;
import android.widget.Button;
import android.widget.ImageSwitcher;
import android.widget.ImageView;
import android.widget.ViewSwitcher;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private ImageSwitcher imageSwitcher;
    private Button btnPrevious, btnNext;

    private final int[] imageResources = {
            android.R.drawable.ic_dialog_info,
            android.R.drawable.ic_dialog_email,
            android.R.drawable.ic_dialog_alert,
            android.R.drawable.ic_dialog_map
    };

    private int currentIndex = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        imageSwitcher = findViewById(R.id.imageSwitcher);
        btnPrevious = findViewById(R.id.btnPrevious);
        btnNext = findViewById(R.id.btnNext);

        // Implementing ViewFactory using setFactory()
        imageSwitcher.setFactory(new ViewSwitcher.ViewFactory() {
            @Override
            public View makeView() {
                ImageView imageView = new ImageView(MainActivity.this);
                imageView.setScaleType(ImageView.ScaleType.FIT_CENTER);
                imageView.setLayoutParams(new ImageSwitcher.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT,
                        ViewGroup.LayoutParams.MATCH_PARENT
                ));
                return imageView;
            }
        });

        // Setup built-in animations for smooth transitions
        imageSwitcher.setInAnimation(AnimationUtils.loadAnimation(this, android.R.anim.slide_in_left));
        imageSwitcher.setOutAnimation(AnimationUtils.loadAnimation(this, android.R.anim.slide_out_right));

        // Set initial image
        imageSwitcher.setImageResource(imageResources[currentIndex]);

        btnNext.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (currentIndex < imageResources.length - 1) {
                    currentIndex++;
                } else {
                    currentIndex = 0; // Wrap around to first image
                }
                imageSwitcher.setImageResource(imageResources[currentIndex]);
            }
        });

        btnPrevious.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (currentIndex > 0) {
                    currentIndex--;
                } else {
                    currentIndex = imageResources.length - 1; // Wrap around to last image
                }
                imageSwitcher.setImageResource(imageResources[currentIndex]);
            }
        });
    }
}