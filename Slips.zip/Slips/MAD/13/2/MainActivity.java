// Q.2) Construct a bank app to display different menu like withdraw, deposit etc.
// File Name: MainActivity.java
// File Path: src/main/java/com/example/bankapp/MainActivity.java

package com.example.bankapp;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class MainActivity extends AppCompatActivity {

    private TextView tvCurrentBalance, tvStatement;
    private EditText etTransactionAmount;
    private Button btnDeposit, btnWithdraw, btnCheckBalance, btnClearStatement;

    // Initial account balance
    private double currentBalance = 10000.00;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Bind layout views
        tvCurrentBalance = findViewById(R.id.tvCurrentBalance);
        tvStatement = findViewById(R.id.tvStatement);
        etTransactionAmount = findViewById(R.id.etTransactionAmount);
        btnDeposit = findViewById(R.id.btnDeposit);
        btnWithdraw = findViewById(R.id.btnWithdraw);
        btnCheckBalance = findViewById(R.id.btnCheckBalance);
        btnClearStatement = findViewById(R.id.btnClearStatement);

        updateBalanceDisplay();

        // 1. DEPOSIT OPERATION
        btnDeposit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                handleDeposit();
            }
        });

        // 2. WITHDRAW OPERATION
        btnWithdraw.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                handleWithdraw();
            }
        });

        // 3. CHECK BALANCE OPERATION
        btnCheckBalance.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(MainActivity.this, "Current Balance: ₹" + String.format(Locale.getDefault(), "%.2f", currentBalance), Toast.LENGTH_LONG).show();
            }
        });

        // 4. CLEAR STATEMENT LOG
        btnClearStatement.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                tvStatement.setText("No transactions yet.\n");
            }
        });
    }

    private void handleDeposit() {
        String amountStr = etTransactionAmount.getText().toString().trim();
        if (amountStr.isEmpty()) {
            Toast.makeText(this, "Please enter an amount to deposit", Toast.LENGTH_SHORT).show();
            return;
        }

        double amount = Double.parseDouble(amountStr);
        if (amount <= 0) {
            Toast.makeText(this, "Deposit amount must be greater than zero", Toast.LENGTH_SHORT).show();
            return;
        }

        currentBalance += amount;
        updateBalanceDisplay();
        logTransaction("Credited (Deposit)", amount);
        etTransactionAmount.setText("");
        Toast.makeText(this, "₹" + amount + " deposited successfully!", Toast.LENGTH_SHORT).show();
    }

    private void handleWithdraw() {
        String amountStr = etTransactionAmount.getText().toString().trim();
        if (amountStr.isEmpty()) {
            Toast.makeText(this, "Please enter an amount to withdraw", Toast.LENGTH_SHORT).show();
            return;
        }

        double amount = Double.parseDouble(amountStr);
        if (amount <= 0) {
            Toast.makeText(this, "Withdrawal amount must be greater than zero", Toast.LENGTH_SHORT).show();
            return;
        }

        if (amount > currentBalance) {
            Toast.makeText(this, "Insufficient Balance!", Toast.LENGTH_LONG).show();
            return;
        }

        currentBalance -= amount;
        updateBalanceDisplay();
        logTransaction("Debited (Withdraw)", amount);
        etTransactionAmount.setText("");
        Toast.makeText(this, "₹" + amount + " withdrawn successfully!", Toast.LENGTH_SHORT).show();
    }

    private void updateBalanceDisplay() {
        tvCurrentBalance.setText("Available Balance: ₹" + String.format(Locale.getDefault(), "%.2f", currentBalance));
    }

    private void logTransaction(String type, double amount) {
        String timestamp = new SimpleDateFormat("dd-MM HH:mm", Locale.getDefault()).format(new Date());
        String logEntry = String.format(Locale.getDefault(), "[%s] %s: ₹%.2f | Bal: ₹%.2f\n", timestamp, type, amount, currentBalance);

        if (tvStatement.getText().toString().contains("No transactions yet.")) {
            tvStatement.setText(logEntry);
        } else {
            tvStatement.append(logEntry);
        }
    }
}