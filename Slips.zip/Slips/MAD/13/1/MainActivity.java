// Q.1) Create an application to find the factorial of a number and Display the Result on alert box.
// File Name: MainActivity.java
// File Path: src/main/java/com/example/factorialapp/MainActivity.java

package com.example.factorialapp;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private EditText etNumber;
    private Button btnCalculate;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Bind layout views
        etNumber = findViewById(R.id.etNumber);
        btnCalculate = findViewById(R.id.btnCalculate);

        btnCalculate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                calculateAndShowFactorial();
            }
        });
    }

    private void calculateAndShowFactorial() {
        String input = etNumber.getText().toString().trim();

        if (input.isEmpty()) {
            Toast.makeText(MainActivity.this, "Please enter a valid number", Toast.LENGTH_SHORT).show();
            return;
        }

        int number;
        try {
            number = Integer.parseInt(input);
        } catch (NumberFormatException e) {
            Toast.makeText(MainActivity.this, "Input number is too large", Toast.LENGTH_SHORT).show();
            return;
        }

        if (number < 0) {
            Toast.makeText(MainActivity.this, "Factorial does not exist for negative numbers", Toast.LENGTH_SHORT).show();
            return;
        }

        if (number > 20) {
            Toast.makeText(MainActivity.this, "Enter a number <= 20 to prevent data overflow", Toast.LENGTH_SHORT).show();
            return;
        }

        // Calculate factorial using 64-bit long
        long factorial = 1;
        for (int i = 1; i <= number; i++) {
            factorial *= i;
        }

        // Display the output using AlertDialog
        AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.this);
        builder.setTitle("Factorial Result");
        builder.setMessage("The factorial of " + number + " (" + number + "!) is:\n\n" + factorial);
        builder.setPositiveButton("OK", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.dismiss();
            }
        });
        builder.setCancelable(false);
        builder.create().show();
    }
}