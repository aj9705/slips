// Q.1) Create an Android Application to accept a number and display the multiplication table (Use table Layout).
// File Name: MainActivity.java
// File Path: src/main/java/com/example/multiplicationtableapp/MainActivity.java

package com.example.multiplicationtableapp;

import android.graphics.Color;
import android.graphics.Typeface;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private EditText etNumber;
    private Button btnGenerate;
    private TableLayout tlMultiplicationTable;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Bind layout views
        etNumber = findViewById(R.id.etNumber);
        btnGenerate = findViewById(R.id.btnGenerate);
        tlMultiplicationTable = findViewById(R.id.tlMultiplicationTable);

        btnGenerate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                generateTable();
            }
        });
    }

    private void generateTable() {
        String inputStr = etNumber.getText().toString().trim();

        if (inputStr.isEmpty()) {
            Toast.makeText(MainActivity.this, "Please enter a number", Toast.LENGTH_SHORT).show();
            return;
        }

        int number;
        try {
            number = Integer.parseInt(inputStr);
        } catch (NumberFormatException e) {
            Toast.makeText(MainActivity.this, "Invalid number entered", Toast.LENGTH_SHORT).show();
            return;
        }

        // Clear existing rows before populating new table
        tlMultiplicationTable.removeAllViews();

        // 1. Create and add Header Row
        TableRow headerRow = new TableRow(this);
        headerRow.setBackgroundColor(Color.parseColor("#3F51B5"));
        headerRow.setPadding(8, 12, 8, 12);

        String[] headers = {"Multiplicand", "×", "Multiplier", "=", "Result"};
        for (String text : headers) {
            TextView tvHeader = new TextView(this);
            tvHeader.setText(text);
            tvHeader.setTextColor(Color.WHITE);
            tvHeader.setTextSize(16sp);
            tvHeader.setTypeface(null, Typeface.BOLD);
            tvHeader.setGravity(Gravity.CENTER);
            headerRow.addView(tvHeader);
        }
        tlMultiplicationTable.addView(headerRow);

        // 2. Generate and add 10 Table Rows (1 to 10)
        for (int i = 1; i <= 10; i++) {
            TableRow row = new TableRow(this);
            row.setPadding(8, 10, 8, 10);

            // Alternating row background colors for clarity
            if (i % 2 == 0) {
                row.setBackgroundColor(Color.parseColor("#E8EAF6"));
            } else {
                row.setBackgroundColor(Color.WHITE);
            }

            // Cell 1: Base Number
            TextView tvNum = createTableCell(String.valueOf(number));
            row.addView(tvNum);

            // Cell 2: Multiplication Sign
            TextView tvSign = createTableCell("×");
            row.addView(tvSign);

            // Cell 3: Multiplier (1 through 10)
            TextView tvMultiplier = createTableCell(String.valueOf(i));
            row.addView(tvMultiplier);

            // Cell 4: Equal Sign
            TextView tvEquals = createTableCell("=");
            row.addView(tvEquals);

            // Cell 5: Calculated Result
            TextView tvResult = createTableCell(String.valueOf(number * i));
            tvResult.setTypeface(null, Typeface.BOLD);
            row.addView(tvResult);

            tlMultiplicationTable.addView(row);
        }
    }

    private TextView createTableCell(String text) {
        TextView textView = new TextView(this);
        textView.setText(text);
        textView.setTextSize(16);
        textView.setTextColor(Color.parseColor("#212121"));
        textView.setGravity(Gravity.CENTER);
        return textView;
    }
}