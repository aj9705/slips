// Q.2) Create table Student (id, name, address, phno). Create Application for performing the following operation on the table.
// i) Insert New Student Details.
// ii) Show All the Students Details.
// File Name: MainActivity.java
// File Path: src/main/java/com/example/studentdbapp/MainActivity.java

package com.example.studentdbapp;

import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private DatabaseHelper dbHelper;
    private EditText etStudentId, etStudentName, etStudentAddress, etStudentPhone;
    private Button btnInsertStudent, btnShowAllStudents;
    private TextView tvDisplayStudentDetails;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Initialize SQLite helper and UI references
        dbHelper = new DatabaseHelper(this);

        etStudentId = findViewById(R.id.etStudentId);
        etStudentName = findViewById(R.id.etStudentName);
        etStudentAddress = findViewById(R.id.etStudentAddress);
        etStudentPhone = findViewById(R.id.etStudentPhone);

        btnInsertStudent = findViewById(R.id.btnInsertStudent);
        btnShowAllStudents = findViewById(R.id.btnShowAllStudents);
        tvDisplayStudentDetails = findViewById(R.id.tvDisplayStudentDetails);

        // i) Insert New Student Details
        btnInsertStudent.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String idStr = etStudentId.getText().toString().trim();
                String name = etStudentName.getText().toString().trim();
                String address = etStudentAddress.getText().toString().trim();
                String phno = etStudentPhone.getText().toString().trim();

                if (idStr.isEmpty() || name.isEmpty() || address.isEmpty() || phno.isEmpty()) {
                    Toast.makeText(MainActivity.this, "Please enter all fields", Toast.LENGTH_SHORT).show();
                    return;
                }

                int id = Integer.parseInt(idStr);
                boolean isInserted = dbHelper.insertStudent(id, name, address, phno);

                if (isInserted) {
                    Toast.makeText(MainActivity.this, "Student record inserted successfully", Toast.LENGTH_SHORT).show();
                    etStudentId.setText("");
                    etStudentName.setText("");
                    etStudentAddress.setText("");
                    etStudentPhone.setText("");
                } else {
                    Toast.makeText(MainActivity.this, "Insertion failed (ID may already exist)", Toast.LENGTH_SHORT).show();
                }
            }
        });

        // ii) Show All the Students Details
        btnShowAllStudents.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Cursor cursor = dbHelper.getAllStudents();

                if (cursor == null || cursor.getCount() == 0) {
                    tvDisplayStudentDetails.setText("No student records found.");
                    Toast.makeText(MainActivity.this, "Database is empty", Toast.LENGTH_SHORT).show();
                    return;
                }

                StringBuilder stringBuilder = new StringBuilder();
                while (cursor.moveToNext()) {
                    int id = cursor.getInt(0);
                    String name = cursor.getString(1);
                    String address = cursor.getString(2);
                    String phno = cursor.getString(3);

                    stringBuilder.append("ID: ").append(id).append("\n");
                    stringBuilder.append("Name: ").append(name).append("\n");
                    stringBuilder.append("Address: ").append(address).append("\n");
                    stringBuilder.append("Phone No: ").append(phno).append("\n");
                    stringBuilder.append("------------------------------------\n");
                }
                cursor.close();

                tvDisplayStudentDetails.setText(stringBuilder.toString());
            }
        });
    }
}