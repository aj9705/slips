// Q.1) Create an Android Application that Demonstrate Switch and Toggle Button
// File Name: MainActivity.java
// File Path: src/main/java/com/example/switchtoggleapp/MainActivity.java

package com.example.switchtoggleapp;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.ToggleButton;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private Switch switchWifi;
    private ToggleButton toggleBluetooth;
    private Button btnCheckStatus;
    private TextView tvStatus;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Bind layout views
        switchWifi = findViewById(R.id.switchWifi);
        toggleBluetooth = findViewById(R.id.toggleBluetooth);
        btnCheckStatus = findViewById(R.id.btnCheckStatus);
        tvStatus = findViewById(R.id.tvStatus);

        // 1. Switch Listener
        switchWifi.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (isChecked) {
                    Toast.makeText(MainActivity.this, "Wi-Fi is ON", Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(MainActivity.this, "Wi-Fi is OFF", Toast.LENGTH_SHORT).show();
                }
                updateStatusDisplay();
            }
        });

        // 2. ToggleButton Listener
        toggleBluetooth.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (isChecked) {
                    Toast.makeText(MainActivity.this, "Bluetooth is Enabled", Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(MainActivity.this, "Bluetooth is Disabled", Toast.LENGTH_SHORT).show();
                }
                updateStatusDisplay();
            }
        });

        // 3. Read both current states on Button click
        btnCheckStatus.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                updateStatusDisplay();
                String message = "Switch is: " + (switchWifi.isChecked() ? "ON" : "OFF")
                        + "\nToggle is: " + (toggleBluetooth.isChecked() ? "ON" : "OFF");
                Toast.makeText(MainActivity.this, message, Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void updateStatusDisplay() {
        String switchState = switchWifi.isChecked() ? "ON" : "OFF";
        String toggleState = toggleBluetooth.isChecked() ? "ON" : "OFF";
        tvStatus.setText("Switch (Wi-Fi): " + switchState + " | Toggle (Bluetooth): " + toggleState);
    }
}