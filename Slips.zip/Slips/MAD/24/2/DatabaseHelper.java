// Q.2) Write an application to accept a teacher name from user and display the names of students along with subjects to whom they are teaching.
// Create table Student (sno , s_name,s_class,s_addr)
// Teacher (tno, t_name, qualification, experience) Student-Teacher has Many to Many relationship. [20 Marks]
// File Name: DatabaseHelper.java
// File Path: src/main/java/com/example/studentteacherapp/DatabaseHelper.java

package com.example.studentteacherapp;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class DatabaseHelper extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "SchoolDB.db";
    private static final int DATABASE_VERSION = 1;

    // Table 1: Student
    public static final String TABLE_STUDENT = "Student";
    public static final String COL_SNO = "sno";
    public static final String COL_S_NAME = "s_name";
    public static final String COL_S_CLASS = "s_class";
    public static final String COL_S_ADDR = "s_addr";

    // Table 2: Teacher
    public static final String TABLE_TEACHER = "Teacher";
    public static final String COL_TNO = "tno";
    public static final String COL_T_NAME = "t_name";
    public static final String COL_QUALIFICATION = "qualification";
    public static final String COL_EXPERIENCE = "experience";

    // Table 3: Junction Table for Many-to-Many Relationship (Student_Teacher)
    public static final String TABLE_STUDENT_TEACHER = "Student_Teacher";
    public static final String COL_ST_SNO = "sno";
    public static final String COL_ST_TNO = "tno";
    public static final String COL_SUBJECT = "subject";

    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        // Create Student Table
        String createStudentTable = "CREATE TABLE " + TABLE_STUDENT + " ("
                + COL_SNO + " INTEGER PRIMARY KEY, "
                + COL_S_NAME + " TEXT, "
                + COL_S_CLASS + " TEXT, "
                + COL_S_ADDR + " TEXT)";
        db.execSQL(createStudentTable);

        // Create Teacher Table
        String createTeacherTable = "CREATE TABLE " + TABLE_TEACHER + " ("
                + COL_TNO + " INTEGER PRIMARY KEY, "
                + COL_T_NAME + " TEXT, "
                + COL_QUALIFICATION + " TEXT, "
                + COL_EXPERIENCE + " TEXT)";
        db.execSQL(createTeacherTable);

        // Create Junction Table with Subject attribute
        String createJunctionTable = "CREATE TABLE " + TABLE_STUDENT_TEACHER + " ("
                + COL_ST_SNO + " INTEGER, "
                + COL_ST_TNO + " INTEGER, "
                + COL_SUBJECT + " TEXT, "
                + "PRIMARY KEY (" + COL_ST_SNO + ", " + COL_ST_TNO + ", " + COL_SUBJECT + "), "
                + "FOREIGN KEY (" + COL_ST_SNO + ") REFERENCES " + TABLE_STUDENT + "(" + COL_SNO + "), "
                + "FOREIGN KEY (" + COL_ST_TNO + ") REFERENCES " + TABLE_TEACHER + "(" + COL_TNO + "))";
        db.execSQL(createJunctionTable);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_STUDENT_TEACHER);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_STUDENT);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_TEACHER);
        onCreate(db);
    }

    // Add Student
    public boolean insertStudent(int sno, String sName, String sClass, String sAddr) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put(COL_SNO, sno);
        cv.put(COL_S_NAME, sName);
        cv.put(COL_S_CLASS, sClass);
        cv.put(COL_S_ADDR, sAddr);
        long res = db.insert(TABLE_STUDENT, null, cv);
        return res != -1;
    }

    // Add Teacher
    public boolean insertTeacher(int tno, String tName, String qual, String exp) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put(COL_TNO, tno);
        cv.put(COL_T_NAME, tName);
        cv.put(COL_QUALIFICATION, qual);
        cv.put(COL_EXPERIENCE, exp);
        long res = db.insert(TABLE_TEACHER, null, cv);
        return res != -1;
    }

    // Assign Student, Teacher, and Subject (Many-to-Many Mapping)
    public boolean assignStudentTeacher(int sno, int tno, String subject) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put(COL_ST_SNO, sno);
        cv.put(COL_ST_TNO, tno);
        cv.put(COL_SUBJECT, subject);
        long res = db.insert(TABLE_STUDENT_TEACHER, null, cv);
        return res != -1;
    }

    // Query: Accept teacher name and fetch student names along with subjects
    public Cursor getStudentsAndSubjectsByTeacherName(String teacherName) {
        SQLiteDatabase db = this.getReadableDatabase();
        String query = "SELECT s." + COL_S_NAME + ", s." + COL_S_CLASS + ", st." + COL_SUBJECT + ", t." + COL_T_NAME
                + " FROM " + TABLE_STUDENT + " s "
                + " JOIN " + TABLE_STUDENT_TEACHER + " st ON s." + COL_SNO + " = st." + COL_ST_SNO
                + " JOIN " + TABLE_TEACHER + " t ON st." + COL_ST_TNO + " = t." + COL_TNO
                + " WHERE LOWER(t." + COL_T_NAME + ") = LOWER(?)";

        return db.rawQuery(query, new String[]{teacherName});
    }
}