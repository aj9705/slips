// Q.2) Write an application to accept a teacher name from user and display the names of students along with subjects to whom they are teaching.
// Create table Student (sno , s_name,s_class,s_addr)
// Teacher (tno, t_name, qualification, experience) Student-Teacher has Many to Many relationship. [20 Marks]
// File Name: MainActivity.java
// File Path: src/main/java/com/example/studentteacherapp/MainActivity.java

package com.example.studentteacherapp;

import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private DatabaseHelper dbHelper;

    // Student Views
    private EditText etSno, etSname, etSclass, etSaddr;
    private Button btnAddStudent;

    // Teacher Views
    private EditText etTno, etTname, etQualification, etExperience;
    private Button btnAddTeacher;

    // Assignment Views
    private EditText etAssignSno, etAssignTno, etAssignSubject;
    private Button btnAssign;

    // Search Views
    private EditText etSearchTeacherName;
    private Button btnSearch;
    private TextView tvDisplayResults;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        dbHelper = new DatabaseHelper(this);

        // Bind Student Views
        etSno = findViewById(R.id.etSno);
        etSname = findViewById(R.id.etSname);
        etSclass = findViewById(R.id.etSclass);
        etSaddr = findViewById(R.id.etSaddr);
        btnAddStudent = findViewById(R.id.btnAddStudent);

        // Bind Teacher Views
        etTno = findViewById(R.id.etTno);
        etTname = findViewById(R.id.etTname);
        etQualification = findViewById(R.id.etQualification);
        etExperience = findViewById(R.id.etExperience);
        btnAddTeacher = findViewById(R.id.btnAddTeacher);

        // Bind Assignment Views
        etAssignSno = findViewById(R.id.etAssignSno);
        etAssignTno = findViewById(R.id.etAssignTno);
        etAssignSubject = findViewById(R.id.etAssignSubject);
        btnAssign = findViewById(R.id.btnAssign);

        // Bind Search Views
        etSearchTeacherName = findViewById(R.id.etSearchTeacherName);
        btnSearch = findViewById(R.id.btnSearch);
        tvDisplayResults = findViewById(R.id.tvDisplayResults);

        // 1. Add Student
        btnAddStudent.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String snoStr = etSno.getText().toString().trim();
                String sName = etSname.getText().toString().trim();
                String sClass = etSclass.getText().toString().trim();
                String sAddr = etSaddr.getText().toString().trim();

                if (snoStr.isEmpty() || sName.isEmpty() || sClass.isEmpty() || sAddr.isEmpty()) {
                    Toast.makeText(MainActivity.this, "Fill all student fields", Toast.LENGTH_SHORT).show();
                    return;
                }

                int sno = Integer.parseInt(snoStr);
                if (dbHelper.insertStudent(sno, sName, sClass, sAddr)) {
                    Toast.makeText(MainActivity.this, "Student added successfully", Toast.LENGTH_SHORT).show();
                    etSno.setText("");
                    etSname.setText("");
                    etSclass.setText("");
                    etSaddr.setText("");
                } else {
                    Toast.makeText(MainActivity.this, "Student insert failed (sno exists)", Toast.LENGTH_SHORT).show();
                }
            }
        });

        // 2. Add Teacher
        btnAddTeacher.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String tnoStr = etTno.getText().toString().trim();
                String tName = etTname.getText().toString().trim();
                String qual = etQualification.getText().toString().trim();
                String exp = etExperience.getText().toString().trim();

                if (tnoStr.isEmpty() || tName.isEmpty() || qual.isEmpty() || exp.isEmpty()) {
                    Toast.makeText(MainActivity.this, "Fill all teacher fields", Toast.LENGTH_SHORT).show();
                    return;
                }

                int tno = Integer.parseInt(tnoStr);
                if (dbHelper.insertTeacher(tno, tName, qual, exp)) {
                    Toast.makeText(MainActivity.this, "Teacher added successfully", Toast.LENGTH_SHORT).show();
                    etTno.setText("");
                    etTname.setText("");
                    etQualification.setText("");
                    etExperience.setText("");
                } else {
                    Toast.makeText(MainActivity.this, "Teacher insert failed (tno exists)", Toast.LENGTH_SHORT).show();
                }
            }
        });

        // 3. Assign Student, Teacher and Subject
        btnAssign.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String snoStr = etAssignSno.getText().toString().trim();
                String tnoStr = etAssignTno.getText().toString().trim();
                String subject = etAssignSubject.getText().toString().trim();

                if (snoStr.isEmpty() || tnoStr.isEmpty() || subject.isEmpty()) {
                    Toast.makeText(MainActivity.this, "Fill Student No, Teacher No, and Subject", Toast.LENGTH_SHORT).show();
                    return;
                }

                int sno = Integer.parseInt(snoStr);
                int tno = Integer.parseInt(tnoStr);

                if (dbHelper.assignStudentTeacher(sno, tno, subject)) {
                    Toast.makeText(MainActivity.this, "Subject and Teacher assigned", Toast.LENGTH_SHORT).show();
                    etAssignSno.setText("");
                    etAssignTno.setText("");
                    etAssignSubject.setText("");
                } else {
                    Toast.makeText(MainActivity.this, "Assignment already exists", Toast.LENGTH_SHORT).show();
                }
            }
        });

        // 4. Query: Search by Teacher Name
        btnSearch.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String teacherName = etSearchTeacherName.getText().toString().trim();

                if (teacherName.isEmpty()) {
                    Toast.makeText(MainActivity.this, "Please enter a Teacher name", Toast.LENGTH_SHORT).show();
                    return;
                }

                Cursor cursor = dbHelper.getStudentsAndSubjectsByTeacherName(teacherName);

                if (cursor == null || cursor.getCount() == 0) {
                    tvDisplayResults.setText("No students/subjects found taught by: " + teacherName);
                    Toast.makeText(MainActivity.this, "No records found", Toast.LENGTH_SHORT).show();
                    return;
                }

                StringBuilder sb = new StringBuilder();
                sb.append("Taught by Teacher: ").append(teacherName).append("\n");
                sb.append("====================================\n");

                while (cursor.moveToNext()) {
                    String studentName = cursor.getString(0);
                    String studentClass = cursor.getString(1);
                    String subject = cursor.getString(2);

                    sb.append("Student Name : ").append(studentName).append("\n");
                    sb.append("Class        : ").append(studentClass).append("\n");
                    sb.append("Subject      : ").append(subject).append("\n");
                    sb.append("------------------------------------\n");
                }
                cursor.close();

                tvDisplayResults.setText(sb.toString());
            }
        });
    }
}