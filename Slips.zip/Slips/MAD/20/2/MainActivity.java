// Q.2) Create Tables Patient (pno, p_name, disease) and Doctor (id, d_name), assume Patient–Doctor has a many to many relationships. Using database perform following operation. 1) Add new record into table. 2) Accept a doctor name from user and display information of patients treated by doctor.
// File Name: MainActivity.java
// File Path: src/main/java/com/example/hospitaldbapp/MainActivity.java

package com.example.hospitaldbapp;

import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private DatabaseHelper dbHelper;

    // Patient Fields
    private EditText etPatientNo, etPatientName, etDisease;
    private Button btnAddPatient;

    // Doctor Fields
    private EditText etDoctorId, etDoctorName;
    private Button btnAddDoctor;

    // Assign Fields
    private EditText etAssignPno, etAssignDocId;
    private Button btnAssign;

    // Search Fields
    private EditText etSearchDocName;
    private Button btnSearchPatients;
    private TextView tvDisplayResults;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        dbHelper = new DatabaseHelper(this);

        // Bind Views
        etPatientNo = findViewById(R.id.etPatientNo);
        etPatientName = findViewById(R.id.etPatientName);
        etDisease = findViewById(R.id.etDisease);
        btnAddPatient = findViewById(R.id.btnAddPatient);

        etDoctorId = findViewById(R.id.etDoctorId);
        etDoctorName = findViewById(R.id.etDoctorName);
        btnAddDoctor = findViewById(R.id.btnAddDoctor);

        etAssignPno = findViewById(R.id.etAssignPno);
        etAssignDocId = findViewById(R.id.etAssignDocId);
        btnAssign = findViewById(R.id.btnAssign);

        etSearchDocName = findViewById(R.id.etSearchDocName);
        btnSearchPatients = findViewById(R.id.btnSearchPatients);
        tvDisplayResults = findViewById(R.id.tvDisplayResults);

        // 1. Add Patient
        btnAddPatient.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String pnoStr = etPatientNo.getText().toString().trim();
                String pName = etPatientName.getText().toString().trim();
                String disease = etDisease.getText().toString().trim();

                if (pnoStr.isEmpty() || pName.isEmpty() || disease.isEmpty()) {
                    Toast.makeText(MainActivity.this, "Fill all Patient fields", Toast.LENGTH_SHORT).show();
                    return;
                }

                int pno = Integer.parseInt(pnoStr);
                if (dbHelper.insertPatient(pno, pName, disease)) {
                    Toast.makeText(MainActivity.this, "Patient added successfully", Toast.LENGTH_SHORT).show();
                    etPatientNo.setText("");
                    etPatientName.setText("");
                    etDisease.setText("");
                } else {
                    Toast.makeText(MainActivity.this, "Patient insertion failed (pno exists)", Toast.LENGTH_SHORT).show();
                }
            }
        });

        // 1. Add Doctor
        btnAddDoctor.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String idStr = etDoctorId.getText().toString().trim();
                String dName = etDoctorName.getText().toString().trim();

                if (idStr.isEmpty() || dName.isEmpty()) {
                    Toast.makeText(MainActivity.this, "Fill all Doctor fields", Toast.LENGTH_SHORT).show();
                    return;
                }

                int docId = Integer.parseInt(idStr);
                if (dbHelper.insertDoctor(docId, dName)) {
                    Toast.makeText(MainActivity.this, "Doctor added successfully", Toast.LENGTH_SHORT).show();
                    etDoctorId.setText("");
                    etDoctorName.setText("");
                } else {
                    Toast.makeText(MainActivity.this, "Doctor insertion failed (id exists)", Toast.LENGTH_SHORT).show();
                }
            }
        });

        // 1. Assign Patient to Doctor
        btnAssign.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String pnoStr = etAssignPno.getText().toString().trim();
                String docIdStr = etAssignDocId.getText().toString().trim();

                if (pnoStr.isEmpty() || docIdStr.isEmpty()) {
                    Toast.makeText(MainActivity.this, "Enter both Patient No and Doctor ID", Toast.LENGTH_SHORT).show();
                    return;
                }

                int pno = Integer.parseInt(pnoStr);
                int docId = Integer.parseInt(docIdStr);

                if (dbHelper.assignPatientToDoctor(pno, docId)) {
                    Toast.makeText(MainActivity.this, "Patient assigned to Doctor", Toast.LENGTH_SHORT).show();
                    etAssignPno.setText("");
                    etAssignDocId.setText("");
                } else {
                    Toast.makeText(MainActivity.this, "Assignment failed (Already mapped)", Toast.LENGTH_SHORT).show();
                }
            }
        });

        // 2. Search Patients by Doctor Name
        btnSearchPatients.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String doctorName = etSearchDocName.getText().toString().trim();

                if (doctorName.isEmpty()) {
                    Toast.makeText(MainActivity.this, "Please enter a Doctor name", Toast.LENGTH_SHORT).show();
                    return;
                }

                Cursor cursor = dbHelper.getPatientsByDoctorName(doctorName);

                if (cursor == null || cursor.getCount() == 0) {
                    tvDisplayResults.setText("No patients found treated by: " + doctorName);
                    Toast.makeText(MainActivity.this, "No matching records found", Toast.LENGTH_SHORT).show();
                    return;
                }

                StringBuilder sb = new StringBuilder();
                sb.append("Patients Treated by Dr. ").append(doctorName).append(":\n");
                sb.append("====================================\n");

                while (cursor.moveToNext()) {
                    int pno = cursor.getInt(0);
                    String pName = cursor.getString(1);
                    String disease = cursor.getString(2);

                    sb.append("Patient No   : ").append(pno).append("\n");
                    sb.append("Patient Name : ").append(pName).append("\n");
                    sb.append("Disease      : ").append(disease).append("\n");
                    sb.append("------------------------------------\n");
                }
                cursor.close();

                tvDisplayResults.setText(sb.toString());
            }
        });
    }
}