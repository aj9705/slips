// Q.2) Create Tables Patient (pno, p_name, disease) and Doctor (id, d_name), assume Patient–Doctor has a many to many relationships. Using database perform following operation. 1) Add new record into table. 2) Accept a doctor name from user and display information of patients treated by doctor.
// File Name: DatabaseHelper.java
// File Path: src/main/java/com/example/hospitaldbapp/DatabaseHelper.java

package com.example.hospitaldbapp;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class DatabaseHelper extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "HospitalDB.db";
    private static final int DATABASE_VERSION = 1;

    // Table 1: Patient
    public static final String TABLE_PATIENT = "Patient";
    public static final String COL_PNO = "pno";
    public static final String COL_P_NAME = "p_name";
    public static final String COL_DISEASE = "disease";

    // Table 2: Doctor
    public static final String TABLE_DOCTOR = "Doctor";
    public static final String COL_DOC_ID = "id";
    public static final String COL_D_NAME = "d_name";

    // Table 3: Patient_Doctor Junction Table (Many-to-Many Relationship)
    public static final String TABLE_PATIENT_DOCTOR = "Patient_Doctor";
    public static final String COL_PD_PNO = "pno";
    public static final String COL_PD_DOC_ID = "doc_id";

    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        // Patient Table
        String createPatientTable = "CREATE TABLE " + TABLE_PATIENT + " ("
                + COL_PNO + " INTEGER PRIMARY KEY, "
                + COL_P_NAME + " TEXT, "
                + COL_DISEASE + " TEXT)";
        db.execSQL(createPatientTable);

        // Doctor Table
        String createDoctorTable = "CREATE TABLE " + TABLE_DOCTOR + " ("
                + COL_DOC_ID + " INTEGER PRIMARY KEY, "
                + COL_D_NAME + " TEXT)";
        db.execSQL(createDoctorTable);

        // Junction Table for Many-to-Many Relationship
        String createJunctionTable = "CREATE TABLE " + TABLE_PATIENT_DOCTOR + " ("
                + COL_PD_PNO + " INTEGER, "
                + COL_PD_DOC_ID + " INTEGER, "
                + "PRIMARY KEY (" + COL_PD_PNO + ", " + COL_PD_DOC_ID + "), "
                + "FOREIGN KEY (" + COL_PD_PNO + ") REFERENCES " + TABLE_PATIENT + "(" + COL_PNO + "), "
                + "FOREIGN KEY (" + COL_PD_DOC_ID + ") REFERENCES " + TABLE_DOCTOR + "(" + COL_DOC_ID + "))";
        db.execSQL(createJunctionTable);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_PATIENT_DOCTOR);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_PATIENT);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_DOCTOR);
        onCreate(db);
    }

    // 1) Add new Patient record
    public boolean insertPatient(int pno, String pName, String disease) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put(COL_PNO, pno);
        cv.put(COL_P_NAME, pName);
        cv.put(COL_DISEASE, disease);
        long res = db.insert(TABLE_PATIENT, null, cv);
        return res != -1;
    }

    // 1) Add new Doctor record
    public boolean insertDoctor(int docId, String dName) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put(COL_DOC_ID, docId);
        cv.put(COL_D_NAME, dName);
        long res = db.insert(TABLE_DOCTOR, null, cv);
        return res != -1;
    }

    // 1) Map Patient to Doctor (Treatment assignment)
    public boolean assignPatientToDoctor(int pno, int docId) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put(COL_PD_PNO, pno);
        cv.put(COL_PD_DOC_ID, docId);
        long res = db.insert(TABLE_PATIENT_DOCTOR, null, cv);
        return res != -1;
    }

    // 2) Accept doctor name and fetch all patients treated by that doctor
    public Cursor getPatientsByDoctorName(String doctorName) {
        SQLiteDatabase db = this.getReadableDatabase();
        String query = "SELECT p." + COL_PNO + ", p." + COL_P_NAME + ", p." + COL_DISEASE + ", d." + COL_D_NAME
                + " FROM " + TABLE_PATIENT + " p "
                + " JOIN " + TABLE_PATIENT_DOCTOR + " pd ON p." + COL_PNO + " = pd." + COL_PD_PNO
                + " JOIN " + TABLE_DOCTOR + " d ON pd." + COL_PD_DOC_ID + " = d." + COL_DOC_ID
                + " WHERE LOWER(d." + COL_D_NAME + ") = LOWER(?)";

        return db.rawQuery(query, new String[]{doctorName});
    }
}
