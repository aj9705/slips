// Q.1) Create application to send and receive messages using SMS Manager. [10 Marks]
// File Name: SmsReceiver.java
// File Path: src/main/java/com/example/smsmanagerapp/SmsReceiver.java

package com.example.smsmanagerapp;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.telephony.SmsMessage;
import android.widget.Toast;

public class SmsReceiver extends BroadcastReceiver {

    // Custom action to broadcast received SMS data to the Activity
    public static final String SMS_RECEIVED_ACTION = "com.example.smsmanagerapp.SMS_RECEIVED";

    @Override
    public void onReceive(Context context, Intent intent) {
        Bundle bundle = intent.getExtras();

        if (bundle != null) {
            // Retrieve PDU (Protocol Data Unit) array from SMS intent extras
            Object[] pdus = (Object[]) bundle.get("pdus");
            String format = bundle.getString("format");

            if (pdus != null) {
                StringBuilder messageBody = new StringBuilder();
                String senderNumber = "";

                for (Object pdu : pdus) {
                    SmsMessage smsMessage;
                    if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.M) {
                        smsMessage = SmsMessage.createFromPdu((byte[]) pdu, format);
                    } else {
                        smsMessage = SmsMessage.createFromPdu((byte[]) pdu);
                    }

                    senderNumber = smsMessage.getDisplayOriginatingAddress();
                    messageBody.append(smsMessage.getMessageBody());
                }

                Toast.makeText(context, "SMS Received from: " + senderNumber, Toast.LENGTH_SHORT).show();

                // Send broadcast to update the UI in MainActivity
                Intent broadcastIntent = new Intent(SMS_RECEIVED_ACTION);
                broadcastIntent.putExtra("SENDER", senderNumber);
                broadcastIntent.putExtra("MESSAGE", messageBody.toString());
                context.sendBroadcast(broadcastIntent);
            }
        }
    }
}