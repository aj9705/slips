// Q.2) Create an application Which reads the person greet message from one activity and display the Greet message on another activity on click of Button (Use Intent).
// File Name: DisplayGreetActivity.java
// File Path: src/main/java/com/example/greetingapp/DisplayGreetActivity.java

package com.example.greetingapp;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class DisplayGreetActivity extends AppCompatActivity {

    private TextView tvDisplayMessage, tvDisplayPerson;
    private Button btnBack;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_display_greet);

        tvDisplayMessage = findViewById(R.id.tvDisplayMessage);
        tvDisplayPerson = findViewById(R.id.tvDisplayPerson);
        btnBack = findViewById(R.id.btnBack);

        // Retrieve data sent from MainActivity
        Intent intent = getIntent();
        String personName = intent.getStringExtra("PERSON_NAME");
        String greetMessage = intent.getStringExtra("GREET_MESSAGE");

        // Set received data to TextViews
        tvDisplayMessage.setText(greetMessage);
        tvDisplayPerson.setText("Dear " + personName + "!");

        // Return back to MainActivity
        btnBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
    }
}