// Q.2) Create an application Which reads the person greet message from one activity and display the Greet message on another activity on click of Button (Use Intent).
// File Name: MainActivity.java
// File Path: src/main/java/com/example/greetingapp/MainActivity.java

package com.example.greetingapp;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private EditText etPersonName, etGreetMessage;
    private Button btnSendGreet;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Bind layout views
        etPersonName = findViewById(R.id.etPersonName);
        etGreetMessage = findViewById(R.id.etGreetMessage);
        btnSendGreet = findViewById(R.id.btnSendGreet);

        btnSendGreet.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String personName = etPersonName.getText().toString().trim();
                String greetMessage = etGreetMessage.getText().toString().trim();

                // Validate empty inputs
                if (personName.isEmpty() || greetMessage.isEmpty()) {
                    Toast.makeText(MainActivity.this, "Please fill in all fields", Toast.LENGTH_SHORT).show();
                    return;
                }

                // Explicit Intent to navigate to DisplayGreetActivity
                Intent intent = new Intent(MainActivity.this, DisplayGreetActivity.class);
                intent.putExtra("PERSON_NAME", personName);
                intent.putExtra("GREET_MESSAGE", greetMessage);
                startActivity(intent);
            }
        });
    }
}