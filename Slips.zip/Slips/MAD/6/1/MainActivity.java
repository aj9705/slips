// Q.1] Construct an Android application to accept a number and calculate Armstrong and Perfect number of a given number.
// File Name: MainActivity.java
// File Path: src/main/java/com/example/armstrongperfectapp/MainActivity.java

package com.example.armstrongperfectapp;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private EditText etNumber;
    private Button btnArmstrong, btnPerfect;
    private TextView tvResult;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        etNumber = findViewById(R.id.etNumber);
        btnArmstrong = findViewById(R.id.btnArmstrong);
        btnPerfect = findViewById(R.id.btnPerfect);
        tvResult = findViewById(R.id.tvResult);

        // Check for Armstrong Number
        btnArmstrong.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String input = etNumber.getText().toString().trim();
                if (input.isEmpty()) {
                    Toast.makeText(MainActivity.this, "Please enter a number", Toast.LENGTH_SHORT).show();
                    return;
                }

                try {
                    int num = Integer.parseInt(input);
                    if (isArmstrong(num)) {
                        tvResult.setText(num + " is an Armstrong Number.\n\n(Sum of digits each raised to the power of number of digits equals the number itself)");
                    } else {
                        tvResult.setText(num + " is NOT an Armstrong Number.");
                    }
                } catch (NumberFormatException e) {
                    Toast.makeText(MainActivity.this, "Number is too large", Toast.LENGTH_SHORT).show();
                }
            }
        });

        // Check for Perfect Number
        btnPerfect.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String input = etNumber.getText().toString().trim();
                if (input.isEmpty()) {
                    Toast.makeText(MainActivity.this, "Please enter a number", Toast.LENGTH_SHORT).show();
                    return;
                }

                try {
                    int num = Integer.parseInt(input);
                    if (isPerfect(num)) {
                        tvResult.setText(num + " is a Perfect Number.\n\n(Sum of its proper positive divisors equals the number itself)");
                    } else {
                        tvResult.setText(num + " is NOT a Perfect Number.");
                    }
                } catch (NumberFormatException e) {
                    Toast.makeText(MainActivity.this, "Number is too large", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    // Armstrong logic: e.g., 153 = 1^3 + 5^3 + 3^3 = 1 + 125 + 27 = 153
    private boolean isArmstrong(int number) {
        if (number < 0) return false;

        int originalNumber = number;
        int digits = String.valueOf(number).length();
        int sum = 0;

        int temp = number;
        while (temp > 0) {
            int remainder = temp % 10;
            sum += Math.pow(remainder, digits);
            temp /= 10;
        }

        return sum == originalNumber;
    }

    // Perfect number logic: e.g., 6 -> divisors 1 + 2 + 3 = 6
    private boolean isPerfect(int number) {
        if (number <= 1) return false;

        int sum = 0;
        for (int i = 1; i <= number / 2; i++) {
            if (number % i == 0) {
                sum += i;
            }
        }

        return sum == number;
    }
}