// Q.2] Write a Java Android Program to Demonstrate List View Activity with all operations Such as: Insert, Delete, Search
// File Name: MainActivity.java
// File Path: src/main/java/com/example/listviewoperationsapp/MainActivity.java

package com.example.listviewoperationsapp;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    private EditText etSearchItem, etNewItem;
    private Button btnAddItem;
    private ListView lvItems;

    private ArrayList<String> itemList;
    private ArrayAdapter<String> adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        etSearchItem = findViewById(R.id.etSearchItem);
        etNewItem = findViewById(R.id.etNewItem);
        btnAddItem = findViewById(R.id.btnAddItem);
        lvItems = findViewById(R.id.lvItems);

        // 1. Initialize dataset with sample entries
        itemList = new ArrayList<>();
        itemList.add("Android");
        itemList.add("Java");
        itemList.add("Kotlin");
        itemList.add("Python");
        itemList.add("Flutter");

        // 2. Set up ArrayAdapter
        adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, itemList);
        lvItems.setAdapter(adapter);

        // 3. INSERT OPERATION
        btnAddItem.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String itemText = etNewItem.getText().toString().trim();
                if (itemText.isEmpty()) {
                    Toast.makeText(MainActivity.this, "Please enter an item name", Toast.LENGTH_SHORT).show();
                    return;
                }

                itemList.add(itemText);
                adapter.notifyDataSetChanged();
                etNewItem.setText("");
                Toast.makeText(MainActivity.this, "Item inserted successfully", Toast.LENGTH_SHORT).show();
            }
        });

        // 4. SEARCH / FILTER OPERATION
        etSearchItem.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
                // Not needed
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                // Filters the ListView in real time using the adapter's filter
                adapter.getFilter().filter(s);
            }

            @Override
            public void afterTextChanged(Editable s) {
                // Not needed
            }
        });

        // 5. CLICK LISTENER (Show Selected Item)
        lvItems.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                String selectedItem = adapter.getItem(position);
                Toast.makeText(MainActivity.this, "Selected: " + selectedItem, Toast.LENGTH_SHORT).show();
            }
        });

        // 6. DELETE OPERATION (Triggered on Long Click with confirmation)
        lvItems.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(AdapterView<?> parent, View view, final int position, long id) {
                final String itemToDelete = adapter.getItem(position);

                new AlertDialog.Builder(MainActivity.this)
                        .setTitle("Delete Item")
                        .setMessage("Do you want to delete \"" + itemToDelete + "\"?")
                        .setPositiveButton("Delete", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                itemList.remove(itemToDelete);
                                adapter.notifyDataSetChanged();
                                Toast.makeText(MainActivity.this, "Item deleted", Toast.LENGTH_SHORT).show();
                            }
                        })
                        .setNegativeButton("Cancel", null)
                        .show();

                return true; // Return true so click listener is not triggered
            }
        });
    }
}