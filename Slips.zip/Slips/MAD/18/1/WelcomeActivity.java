// Q.1) Create sample application with login module. Verify Check username and password. On successful login, pass username to next screen and if login fails, prompt the user.
// File Name: WelcomeActivity.java
// File Path: src/main/java/com/example/loginmoduleapp/WelcomeActivity.java

package com.example.loginmoduleapp;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class WelcomeActivity extends AppCompatActivity {

    private TextView tvWelcomeUser;
    private Button btnLogout;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_welcome);

        tvWelcomeUser = findViewById(R.id.tvWelcomeUser);
        btnLogout = findViewById(R.id.btnLogout);

        // Retrieve passed username from Intent
        Intent intent = getIntent();
        String username = intent.getStringExtra("LOGGED_IN_USER");

        if (username != null && !username.isEmpty()) {
            tvWelcomeUser.setText("Welcome, " + username + "!");
        }

        // Logout action
        btnLogout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
    }
}