// Q.1) Create sample application with login module. Verify Check username and password. On successful login, pass username to next screen and if login fails, prompt the user.
// File Name: MainActivity.java
// File Path: src/main/java/com/example/loginmoduleapp/MainActivity.java

package com.example.loginmoduleapp;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private EditText etUsername, etPassword;
    private Button btnLogin;

    // Hardcoded credentials for verification
    private static final String CORRECT_USER = "admin";
    private static final String CORRECT_PASS = "admin123";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Bind layout views
        etUsername = findViewById(R.id.etUsername);
        etPassword = findViewById(R.id.etPassword);
        btnLogin = findViewById(R.id.btnLogin);

        btnLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                verifyLogin();
            }
        });
    }

    private void verifyLogin() {
        String enteredUser = etUsername.getText().toString().trim();
        String enteredPass = etPassword.getText().toString().trim();

        // 1. Validation for empty inputs
        if (enteredUser.isEmpty() || enteredPass.isEmpty()) {
            Toast.makeText(MainActivity.this, "Please enter both username and password", Toast.LENGTH_SHORT).show();
            return;
        }

        // 2. Credential Verification
        if (enteredUser.equals(CORRECT_USER) && enteredPass.equals(CORRECT_PASS)) {
            // Success: Pass username to next screen via Intent
            Intent intent = new Intent(MainActivity.this, WelcomeActivity.class);
            intent.putExtra("LOGGED_IN_USER", enteredUser);
            startActivity(intent);
        } else {
            // Failure: Prompt the user with an alert dialog
            new AlertDialog.Builder(MainActivity.this)
                    .setTitle("Login Failed")
                    .setMessage("Invalid username or password. Please try again.")
                    .setPositiveButton("Retry", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            etPassword.setText("");
                            etPassword.requestFocus();
                        }
                    })
                    .setCancelable(false)
                    .show();
        }
    }
}