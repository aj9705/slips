// Q.2) Create Tables Employee (emp_id, emp_name, emp_desg, emp_salary) Using database perform following operation.
// 1) Add new record into table.
// 2) Accept employee name from user and display information of employee.
// File Name: MainActivity.java
// File Path: src/main/java/com/example/employeedbapp/MainActivity.java

package com.example.employeedbapp;

import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

import java.util.Locale;

public class MainActivity extends AppCompatActivity {

    private DatabaseHelper dbHelper;
    private EditText etEmpId, etEmpName, etEmpDesg, etEmpSalary, etSearchName;
    private Button btnAddRecord, btnSearchRecord;
    private TextView tvDisplayEmployee;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        dbHelper = new DatabaseHelper(this);

        // Bind input views
        etEmpId = findViewById(R.id.etEmpId);
        etEmpName = findViewById(R.id.etEmpName);
        etEmpDesg = findViewById(R.id.etEmpDesg);
        etEmpSalary = findViewById(R.id.etEmpSalary);
        etSearchName = findViewById(R.id.etSearchName);

        btnAddRecord = findViewById(R.id.btnAddRecord);
        btnSearchRecord = findViewById(R.id.btnSearchRecord);
        tvDisplayEmployee = findViewById(R.id.tvDisplayEmployee);

        // 1) Add new record
        btnAddRecord.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                insertRecord();
            }
        });

        // 2) Search and display record by name
        btnSearchRecord.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                searchRecordByName();
            }
        });
    }

    private void insertRecord() {
        String idStr = etEmpId.getText().toString().trim();
        String name = etEmpName.getText().toString().trim();
        String desg = etEmpDesg.getText().toString().trim();
        String salaryStr = etEmpSalary.getText().toString().trim();

        if (idStr.isEmpty() || name.isEmpty() || desg.isEmpty() || salaryStr.isEmpty()) {
            Toast.makeText(MainActivity.this, "Please fill all employee fields", Toast.LENGTH_SHORT).show();
            return;
        }

        try {
            int id = Integer.parseInt(idStr);
            double salary = Double.parseDouble(salaryStr);

            boolean isInserted = dbHelper.insertEmployee(id, name, desg, salary);

            if (isInserted) {
                Toast.makeText(MainActivity.this, "Employee record added successfully", Toast.LENGTH_SHORT).show();
                etEmpId.setText("");
                etEmpName.setText("");
                etEmpDesg.setText("");
                etEmpSalary.setText("");
            } else {
                Toast.makeText(MainActivity.this, "Failed to add record (Employee ID already exists)", Toast.LENGTH_SHORT).show();
            }
        } catch (NumberFormatException e) {
            Toast.makeText(MainActivity.this, "Invalid ID or Salary format", Toast.LENGTH_SHORT).show();
        }
    }

    private void searchRecordByName() {
        String searchName = etSearchName.getText().toString().trim();

        if (searchName.isEmpty()) {
            Toast.makeText(MainActivity.this, "Please enter an employee name to search", Toast.LENGTH_SHORT).show();
            return;
        }

        Cursor cursor = dbHelper.getEmployeeByName(searchName);

        if (cursor == null || cursor.getCount() == 0) {
            tvDisplayEmployee.setText("No employee found with name: " + searchName);
            Toast.makeText(MainActivity.this, "No record found", Toast.LENGTH_SHORT).show();
            return;
        }

        StringBuilder sb = new StringBuilder();
        while (cursor.moveToNext()) {
            int id = cursor.getInt(0);
            String name = cursor.getString(1);
            String desg = cursor.getString(2);
            double salary = cursor.getDouble(3);

            sb.append("Employee ID   : ").append(id).append("\n");
            sb.append("Name          : ").append(name).append("\n");
            sb.append("Designation   : ").append(desg).append("\n");
            sb.append(String.format(Locale.getDefault(), "Salary        : ₹%.2f\n", salary));
            sb.append("------------------------------------\n");
        }
        cursor.close();

        tvDisplayEmployee.setText(sb.toString());
    }
}