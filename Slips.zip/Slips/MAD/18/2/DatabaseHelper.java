// Q.2) Create Tables Employee (emp_id, emp_name, emp_desg, emp_salary) Using database perform following operation.
// 1) Add new record into table.
// 2) Accept employee name from user and display information of employee.
// File Name: DatabaseHelper.java
// File Path: src/main/java/com/example/employeedbapp/DatabaseHelper.java

package com.example.employeedbapp;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class DatabaseHelper extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "EmployeeDB.db";
    private static final int DATABASE_VERSION = 1;

    public static final String TABLE_NAME = "Employee";
    public static final String COL_EMP_ID = "emp_id";
    public static final String COL_EMP_NAME = "emp_name";
    public static final String COL_EMP_DESG = "emp_desg";
    public static final String COL_EMP_SALARY = "emp_salary";

    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String createTableQuery = "CREATE TABLE " + TABLE_NAME + " ("
                + COL_EMP_ID + " INTEGER PRIMARY KEY, "
                + COL_EMP_NAME + " TEXT, "
                + COL_EMP_DESG + " TEXT, "
                + COL_EMP_SALARY + " REAL)";
        db.execSQL(createTableQuery);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_NAME);
        onCreate(db);
    }

    // 1) Add new record into table
    public boolean insertEmployee(int id, String name, String desg, double salary) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COL_EMP_ID, id);
        values.put(COL_EMP_NAME, name);
        values.put(COL_EMP_DESG, desg);
        values.put(COL_EMP_SALARY, salary);

        long result = db.insert(TABLE_NAME, null, values);
        return result != -1;
    }

    // 2) Accept employee name from user and search/display information
    public Cursor getEmployeeByName(String name) {
        SQLiteDatabase db = this.getReadableDatabase();
        return db.rawQuery("SELECT * FROM " + TABLE_NAME + " WHERE LOWER(" + COL_EMP_NAME + ") = LOWER(?)", new String[]{name});
    }
}