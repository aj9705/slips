// Q.2) Create an application that accept multiple items from one activity and pass to next activity and display the calculation of the first and second activity data on third.
// File Name: FirstActivity.java
// File Path: src/main/java/com/example/multiactivitycalcapp/FirstActivity.java

package com.example.multiactivitycalcapp;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class FirstActivity extends AppCompatActivity {

    private EditText etItem1Qty, etItem2Qty;
    private Button btnGoToActivity2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_first);

        // Bind layout views
        etItem1Qty = findViewById(R.id.etItem1Qty);
        etItem2Qty = findViewById(R.id.etItem2Qty);
        btnGoToActivity2 = findViewById(R.id.btnGoToActivity2);

        btnGoToActivity2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String qty1Str = etItem1Qty.getText().toString().trim();
                String qty2Str = etItem2Qty.getText().toString().trim();

                // Validate empty fields
                if (qty1Str.isEmpty() || qty2Str.isEmpty()) {
                    Toast.makeText(FirstActivity.this, "Please enter quantities for both items", Toast.LENGTH_SHORT).show();
                    return;
                }

                int qty1 = Integer.parseInt(qty1Str);
                int qty2 = Integer.parseInt(qty2Str);

                // Pass Activity 1 data forward to Activity 2
                Intent intent = new Intent(FirstActivity.this, SecondActivity.class);
                intent.putExtra("ITEM1_QTY", qty1);
                intent.putExtra("ITEM2_QTY", qty2);
                startActivity(intent);
            }
        });
    }
}