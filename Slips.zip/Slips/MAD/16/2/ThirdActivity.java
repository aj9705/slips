// Q.2) Create an application that accept multiple items from one activity and pass to next activity and display the calculation of the first and second activity data on third.
// File Name: ThirdActivity.java
// File Path: src/main/java/com/example/multiactivitycalcapp/ThirdActivity.java

package com.example.multiactivitycalcapp;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

import java.util.Locale;

public class ThirdActivity extends AppCompatActivity {

    private TextView tvItem1Breakdown, tvItem2Breakdown, tvTotalCost;
    private Button btnRestart;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_third);

        // Bind layout views
        tvItem1Breakdown = findViewById(R.id.tvItem1Breakdown);
        tvItem2Breakdown = findViewById(R.id.tvItem2Breakdown);
        tvTotalCost = findViewById(R.id.tvTotalCost);
        btnRestart = findViewById(R.id.btnRestart);

        // Retrieve combined data passed across activities
        Intent intent = getIntent();
        int qty1 = intent.getIntExtra("ITEM1_QTY", 0);
        int qty2 = intent.getIntExtra("ITEM2_QTY", 0);
        double price1 = intent.getDoubleExtra("ITEM1_PRICE", 0.0);
        double price2 = intent.getDoubleExtra("ITEM2_PRICE", 0.0);

        // Compute cost calculations combining data from Activity 1 and Activity 2
        double item1Total = qty1 * price1;
        double item2Total = qty2 * price2;
        double grandTotal = item1Total + item2Total;

        // Display results
        tvItem1Breakdown.setText(String.format(Locale.getDefault(),
                "Item 1: %d pcs @ ₹%.2f = ₹%.2f", qty1, price1, item1Total));
        tvItem2Breakdown.setText(String.format(Locale.getDefault(),
                "Item 2: %d pcs @ ₹%.2f = ₹%.2f", qty2, price2, item2Total));
        tvTotalCost.setText(String.format(Locale.getDefault(),
                "Grand Total: ₹%.2f", grandTotal));

        // Restart to FirstActivity clearing back stack
        btnRestart.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent restartIntent = new Intent(ThirdActivity.this, FirstActivity.class);
                restartIntent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(restartIntent);
                finish();
            }
        });
    }
}