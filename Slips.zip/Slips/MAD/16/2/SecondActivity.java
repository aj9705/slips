// Q.2) Create an application that accept multiple items from one activity and pass to next activity and display the calculation of the first and second activity data on third.
// File Name: SecondActivity.java
// File Path: src/main/java/com/example/multiactivitycalcapp/SecondActivity.java

package com.example.multiactivitycalcapp;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class SecondActivity extends AppCompatActivity {

    private TextView tvQtySummary;
    private EditText etItem1Price, etItem2Price;
    private Button btnGoToActivity3;

    private int qty1, qty2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_second);

        // Bind layout views
        tvQtySummary = findViewById(R.id.tvQtySummary);
        etItem1Price = findViewById(R.id.etItem1Price);
        etItem2Price = findViewById(R.id.etItem2Price);
        btnGoToActivity3 = findViewById(R.id.btnGoToActivity3);

        // Retrieve passed data from FirstActivity
        Intent receivedIntent = getIntent();
        qty1 = receivedIntent.getIntExtra("ITEM1_QTY", 0);
        qty2 = receivedIntent.getIntExtra("ITEM2_QTY", 0);

        tvQtySummary.setText("Item 1 Quantity: " + qty1 + " | Item 2 Quantity: " + qty2);

        btnGoToActivity3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String price1Str = etItem1Price.getText().toString().trim();
                String price2Str = etItem2Price.getText().toString().trim();

                if (price1Str.isEmpty() || price2Str.isEmpty()) {
                    Toast.makeText(SecondActivity.this, "Please enter prices for both items", Toast.LENGTH_SHORT).show();
                    return;
                }

                double price1 = Double.parseDouble(price1Str);
                double price2 = Double.parseDouble(price2Str);

                // Pass both Activity 1 data and Activity 2 data forward to ThirdActivity
                Intent intent = new Intent(SecondActivity.this, ThirdActivity.class);
                intent.putExtra("ITEM1_QTY", qty1);
                intent.putExtra("ITEM2_QTY", qty2);
                intent.putExtra("ITEM1_PRICE", price1);
                intent.putExtra("ITEM2_PRICE", price2);
                startActivity(intent);
            }
        });
    }
}