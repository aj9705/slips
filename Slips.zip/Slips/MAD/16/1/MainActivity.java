// Q.1) Create an application to accept two numbers and find power and Average. Display the result on the next activity on Button click.
// File Name: MainActivity.java
// File Path: src/main/java/com/example/poweraverageapp/MainActivity.java

package com.example.poweraverageapp;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private EditText etNumber1, etNumber2;
    private Button btnCalculate;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Bind layout views
        etNumber1 = findViewById(R.id.etNumber1);
        etNumber2 = findViewById(R.id.etNumber2);
        btnCalculate = findViewById(R.id.btnCalculate);

        btnCalculate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                calculateAndNavigate();
            }
        });
    }

    private void calculateAndNavigate() {
        String num1Str = etNumber1.getText().toString().trim();
        String num2Str = etNumber2.getText().toString().trim();

        // Validation for empty inputs
        if (num1Str.isEmpty() || num2Str.isEmpty()) {
            Toast.makeText(MainActivity.this, "Please enter both numbers", Toast.LENGTH_SHORT).show();
            return;
        }

        try {
            double num1 = Double.parseDouble(num1Str);
            double num2 = Double.parseDouble(num2Str);

            // 1. Calculate Power (num1 ^ num2)
            double powerResult = Math.pow(num1, num2);

            // 2. Calculate Average
            double avgResult = (num1 + num2) / 2.0;

            // Pass inputs and calculated results to ResultActivity
            Intent intent = new Intent(MainActivity.this, ResultActivity.class);
            intent.putExtra("NUM1", num1);
            intent.putExtra("NUM2", num2);
            intent.putExtra("POWER", powerResult);
            intent.putExtra("AVERAGE", avgResult);

            startActivity(intent);

        } catch (NumberFormatException e) {
            Toast.makeText(MainActivity.this, "Invalid number entered", Toast.LENGTH_SHORT).show();
        }
    }
}