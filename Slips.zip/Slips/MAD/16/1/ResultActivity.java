// Q.1) Create an application to accept two numbers and find power and Average. Display the result on the next activity on Button click.
// File Name: ResultActivity.java
// File Path: src/main/java/com/example/poweraverageapp/ResultActivity.java

package com.example.poweraverageapp;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

import java.util.Locale;

public class ResultActivity extends AppCompatActivity {

    private TextView tvInputValues, tvPowerResult, tvAverageResult;
    private Button btnBack;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_result);

        // Bind layout views
        tvInputValues = findViewById(R.id.tvInputValues);
        tvPowerResult = findViewById(R.id.tvPowerResult);
        tvAverageResult = findViewById(R.id.tvAverageResult);
        btnBack = findViewById(R.id.btnBack);

        // Retrieve calculations from Intent extras
        Intent intent = getIntent();
        double num1 = intent.getDoubleExtra("NUM1", 0);
        double num2 = intent.getDoubleExtra("NUM2", 0);
        double power = intent.getDoubleExtra("POWER", 0);
        double average = intent.getDoubleExtra("AVERAGE", 0);

        // Display formatted details
        tvInputValues.setText(String.format(Locale.getDefault(), "Base: %.2f | Exponent: %.2f", num1, num2));
        tvPowerResult.setText(String.format(Locale.getDefault(), "Power (%.2f ^ %.2f) = %.2f", num1, num2, power));
        tvAverageResult.setText(String.format(Locale.getDefault(), "Average = %.2f", average));

        // Return to input screen
        btnBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
    }
}