// Q.1) Create an application to change Font Size, Color and Font Family of String. [10 Marks]
// File Name: MainActivity.java
// File Path: src/main/java/com/example/fontstyleapp/MainActivity.java

package com.example.fontstyleapp;

import android.graphics.Color;
import android.graphics.Typeface;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private TextView tvDisplaySample;
    private Button btnSizeSmall, btnSizeMedium, btnSizeLarge;
    private Button btnColorRed, btnColorGreen, btnColorBlue;
    private Button btnFontSans, btnFontSerif, btnFontMonospace;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Bind TextView
        tvDisplaySample = findViewById(R.id.tvDisplaySample);

        // Bind Font Size Buttons
        btnSizeSmall = findViewById(R.id.btnSizeSmall);
        btnSizeMedium = findViewById(R.id.btnSizeMedium);
        btnSizeLarge = findViewById(R.id.btnSizeLarge);

        // Bind Font Color Buttons
        btnColorRed = findViewById(R.id.btnColorRed);
        btnColorGreen = findViewById(R.id.btnColorGreen);
        btnColorBlue = findViewById(R.id.btnColorBlue);

        // Bind Font Family Buttons
        btnFontSans = findViewById(R.id.btnFontSans);
        btnFontSerif = findViewById(R.id.btnFontSerif);
        btnFontMonospace = findViewById(R.id.btnFontMonospace);

        // 1. Change Font Size
        btnSizeSmall.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                tvDisplaySample.setTextSize(16);
            }
        });

        btnSizeMedium.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                tvDisplaySample.setTextSize(24);
            }
        });

        btnSizeLarge.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                tvDisplaySample.setTextSize(32);
            }
        });

        // 2. Change Font Color
        btnColorRed.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                tvDisplaySample.setTextColor(Color.RED);
            }
        });

        btnColorGreen.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                tvDisplaySample.setTextColor(Color.GREEN);
            }
        });

        btnColorBlue.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                tvDisplaySample.setTextColor(Color.BLUE);
            }
        });

        // 3. Change Font Family
        btnFontSans.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                tvDisplaySample.setTypeface(Typeface.SANS_SERIF);
            }
        });

        btnFontSerif.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                tvDisplaySample.setTypeface(Typeface.SERIF);
            }
        });

        btnFontMonospace.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                tvDisplaySample.setTypeface(Typeface.MONOSPACE);
            }
        });
    }
}