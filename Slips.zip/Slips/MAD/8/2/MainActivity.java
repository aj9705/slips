// Q.2) Create an application for registration form given below. Also perform appropriate validation. [20 Marks]
// File Name: MainActivity.java
// File Path: src/main/java/com/example/registrationapp/MainActivity.java

package com.example.registrationapp;

import android.os.Bundle;
import android.util.Patterns;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private EditText etName, etEmail, etPassword, etAge, etMobile;
    private Button btnRegister;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Bind layout views
        etName = findViewById(R.id.etName);
        etEmail = findViewById(R.id.etEmail);
        etPassword = findViewById(R.id.etPassword);
        etAge = findViewById(R.id.etAge);
        etMobile = findViewById(R.id.etMobile);
        btnRegister = findViewById(R.id.btnRegister);

        btnRegister.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                validateAndRegister();
            }
        });
    }

    private void validateAndRegister() {
        String name = etName.getText().toString().trim();
        String email = etEmail.getText().toString().trim();
        String password = etPassword.getText().toString().trim();
        String ageStr = etAge.getText().toString().trim();
        String mobile = etMobile.getText().toString().trim();

        // 1. Validate Name
        if (name.isEmpty()) {
            etName.setError("Name is required");
            etName.requestFocus();
            return;
        }
        if (!name.matches("^[a-zA-Z\\s]+$")) {
            etName.setError("Name should only contain letters");
            etName.requestFocus();
            return;
        }

        // 2. Validate Email
        if (email.isEmpty()) {
            etEmail.setError("E-mail is required");
            etEmail.requestFocus();
            return;
        }
        if (!Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
            etEmail.setError("Please enter a valid e-mail address");
            etEmail.requestFocus();
            return;
        }

        // 3. Validate Password
        if (password.isEmpty()) {
            etPassword.setError("Password is required");
            etPassword.requestFocus();
            return;
        }
        if (password.length() < 6) {
            etPassword.setError("Password must be at least 6 characters");
            etPassword.requestFocus();
            return;
        }

        // 4. Validate Age
        if (ageStr.isEmpty()) {
            etAge.setError("Age is required");
            etAge.requestFocus();
            return;
        }
        int age;
        try {
            age = Integer.parseInt(ageStr);
            if (age < 1 || age > 120) {
                etAge.setError("Please enter a valid age (1-120)");
                etAge.requestFocus();
                return;
            }
        } catch (NumberFormatException e) {
            etAge.setError("Invalid age format");
            etAge.requestFocus();
            return;
        }

        // 5. Validate Mobile Number (10 digits)
        if (mobile.isEmpty()) {
            etMobile.setError("Mobile number is required");
            etMobile.requestFocus();
            return;
        }
        if (!mobile.matches("^[0-9]{10}$")) {
            etMobile.setError("Enter a valid 10-digit mobile number");
            etMobile.requestFocus();
            return;
        }

        // If all validations pass
        Toast.makeText(MainActivity.this, "Registration Successful!", Toast.LENGTH_LONG).show();

        // Clear fields after successful registration
        etName.setText("");
        etEmail.setText("");
        etPassword.setText("");
        etAge.setText("");
        etMobile.setText("");
    }
}