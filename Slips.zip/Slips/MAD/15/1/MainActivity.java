// Q.1) Create the following Vertical Scroll View Creation in Android.
// File Name: MainActivity.java
// File Path: src/main/java/com/example/creating_scroll_view/MainActivity.java

package com.example.creating_scroll_view;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Array of button resource IDs
        int[] buttonIds = {
                R.id.button1, R.id.button2, R.id.button3, R.id.button4,
                R.id.button5, R.id.button6, R.id.button7, R.id.button8,
                R.id.button9, R.id.button10, R.id.button11, R.id.button12
        };

        // Attach click listeners to all buttons
        for (int id : buttonIds) {
            Button btn = findViewById(id);
            if (btn != null) {
                btn.setOnClickListener(this);
            }
        }
    }

    @Override
    public void onClick(View v) {
        Button clickedButton = (Button) v;
        Toast.makeText(this, clickedButton.getText().toString() + " Clicked", Toast.LENGTH_SHORT).show();
    }
}