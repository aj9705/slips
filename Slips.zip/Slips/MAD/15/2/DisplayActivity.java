// Q.2) Create First Activity to accept information like Employee First Name, Middle Name, Last Name, Date of birth, Address, Email ID and display all information on Second Activity when user click on Submit button. [20 Marks]
// File Name: DisplayActivity.java
// File Path: src/main/java/com/example/employeeinfoapp/DisplayActivity.java

package com.example.employeeinfoapp;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class DisplayActivity extends AppCompatActivity {

    private TextView tvDisplayFullName, tvDisplayDob, tvDisplayAddress, tvDisplayEmail;
    private Button btnBack;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_display);

        // Bind layout views
        tvDisplayFullName = findViewById(R.id.tvDisplayFullName);
        tvDisplayDob = findViewById(R.id.tvDisplayDob);
        tvDisplayAddress = findViewById(R.id.tvDisplayAddress);
        tvDisplayEmail = findViewById(R.id.tvDisplayEmail);
        btnBack = findViewById(R.id.btnBack);

        // Retrieve data sent from MainActivity
        Intent intent = getIntent();
        String firstName = intent.getStringExtra("EMP_FIRST_NAME");
        String middleName = intent.getStringExtra("EMP_MIDDLE_NAME");
        String lastName = intent.getStringExtra("EMP_LAST_NAME");
        String dob = intent.getStringExtra("EMP_DOB");
        String address = intent.getStringExtra("EMP_ADDRESS");
        String email = intent.getStringExtra("EMP_EMAIL");

        // Format and set data to TextViews
        String fullName = firstName + " " + (middleName.equals("N/A") ? "" : middleName + " ") + lastName;
        tvDisplayFullName.setText("Full Name: " + fullName.trim());
        tvDisplayDob.setText("Date of Birth: " + dob);
        tvDisplayAddress.setText("Address: " + address);
        tvDisplayEmail.setText("Email ID: " + email);

        // Close SecondActivity and return to MainActivity
        btnBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
    }
}