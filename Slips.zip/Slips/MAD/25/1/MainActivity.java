// Q.1) Create a custom "Contact" layout to hold multiple pieces of information, including: Photo, Name, Contact Number, E-mail id
// File Name: MainActivity.java
// File Path: src/main/java/com/example/customcontactlayout/MainActivity.java

package com.example.customcontactlayout;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private ImageView ivContactPhoto;
    private TextView tvContactName, tvContactPhone, tvContactEmail;
    private Button btnCall, btnEmail;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Access views defined within the custom contact layout
        ivContactPhoto = findViewById(R.id.ivContactPhoto);
        tvContactName = findViewById(R.id.tvContactName);
        tvContactPhone = findViewById(R.id.tvContactPhone);
        tvContactEmail = findViewById(R.id.tvContactEmail);

        btnCall = findViewById(R.id.btnCall);
        btnEmail = findViewById(R.id.btnEmail);

        // Dynamically bind custom contact information
        ivContactPhoto.setImageResource(R.mipmap.ic_launcher_round);
        tvContactName.setText("Alexander Graham Bell");
        tvContactPhone.setText("+91 9876543210");
        tvContactEmail.setText("alexander.bell@example.com");

        // Action: Initiate phone call dialer
        btnCall.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String phoneNumber = tvContactPhone.getText().toString().trim();
                Intent dialIntent = new Intent(Intent.ACTION_DIAL);
                dialIntent.setData(Uri.parse("tel:" + Uri.encode(phoneNumber)));
                startActivity(dialIntent);
            }
        });

        // Action: Send email to contact
        btnEmail.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String emailAddress = tvContactEmail.getText().toString().trim();
                Intent emailIntent = new Intent(Intent.ACTION_SENDTO);
                emailIntent.setData(Uri.parse("mailto:"));
                emailIntent.putExtra(Intent.EXTRA_EMAIL, new String[]{emailAddress});
                emailIntent.putExtra(Intent.EXTRA_SUBJECT, "Regarding Android Project");

                try {
                    startActivity(Intent.createChooser(emailIntent, "Send Email via:"));
                } catch (Exception e) {
                    Toast.makeText(MainActivity.this, "No email client available", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }
}