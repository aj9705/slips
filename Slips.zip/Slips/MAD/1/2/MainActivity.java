// File: java/com/example/studentdb/MainActivity.java
package com.example.studentdb;

import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private DatabaseHelper databaseHelper;
    private Button btnInsert, btnView;
    private TextView tvDisplay;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        databaseHelper = new DatabaseHelper(this);
        btnInsert = findViewById(R.id.btnInsert);
        btnView = findViewById(R.id.btnView);
        tvDisplay = findViewById(R.id.tvDisplay);

        btnInsert.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                insertFiveStudents();
            }
        });

        btnView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                displayAllStudents();
            }
        });
    }

    private void insertFiveStudents() {
        int[] rollNumbers = {101, 102, 103, 104, 105};
        String[] names = {"Aarav Sharma", "Diya Patel", "Rohan Verma", "Ananya Rao", "Kabir Singh"};
        String[] addresses = {"Mumbai", "Pune", "Delhi", "Bengaluru", "Hyderabad"};
        double[] percentages = {85.5, 91.2, 78.0, 88.4, 94.6};

        boolean allInserted = true;
        for (int i = 0; i < 5; i++) {
            boolean isInserted = databaseHelper.insertStudentRecord(
                    rollNumbers[i],
                    names[i],
                    addresses[i],
                    percentages[i]
            );
            if (!isInserted) {
                allInserted = false;
            }
        }

        if (allInserted) {
            Toast.makeText(MainActivity.this, "5 Student Records Inserted Successfully", Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(MainActivity.this, "Failed or duplicate records found", Toast.LENGTH_SHORT).show();
        }
    }

    private void displayAllStudents() {
        Cursor cursor = databaseHelper.getAllStudents();

        if (cursor == null || cursor.getCount() == 0) {
            tvDisplay.setText("No records found in database.");
            return;
        }

        StringBuilder builder = new StringBuilder();
        while (cursor.moveToNext()) {
            int rollNo = cursor.getInt(cursor.getColumnIndexOrThrow(DatabaseHelper.COL_ROLL_NO));
            String name = cursor.getString(cursor.getColumnIndexOrThrow(DatabaseHelper.COL_NAME));
            String address = cursor.getString(cursor.getColumnIndexOrThrow(DatabaseHelper.COL_ADDRESS));
            double percentage = cursor.getDouble(cursor.getColumnIndexOrThrow(DatabaseHelper.COL_PERCENTAGE));

            builder.append("Roll No: ").append(rollNo).append("\n")
                    .append("Name: ").append(name).append("\n")
                    .append("Address: ").append(address).append("\n")
                    .append("Percentage: ").append(percentage).append("%\n")
                    .append("------------------------------------\n");
        }
        cursor.close();

        tvDisplay.setText(builder.toString());
    }
}