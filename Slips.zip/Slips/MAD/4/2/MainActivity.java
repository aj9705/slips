// Q.2] Create table Customer (id, name, address, ph_no).
// Create Application for performing the following operation on the table.
// (Using SQLite database).
// i] Insert new customer details (At least records).
// ii] Show all the customer details.
// File Name: MainActivity.java
// File Path: src/main/java/com/example/customerapp/MainActivity.java

package com.example.customerapp;

import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private DatabaseHelper dbHelper;
    private EditText etId, etName, etAddress, etPhone;
    private Button btnInsert, btnInsertDefault, btnViewAll;
    private TextView tvDisplayData;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        dbHelper = new DatabaseHelper(this);

        etId = findViewById(R.id.etId);
        etName = findViewById(R.id.etName);
        etAddress = findViewById(R.id.etAddress);
        etPhone = findViewById(R.id.etPhone);

        btnInsert = findViewById(R.id.btnInsert);
        btnInsertDefault = findViewById(R.id.btnInsertDefault);
        btnViewAll = findViewById(R.id.btnViewAll);
        tvDisplayData = findViewById(R.id.tvDisplayData);

        // i] Insert custom record entered by user
        btnInsert.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String idStr = etId.getText().toString().trim();
                String name = etName.getText().toString().trim();
                String address = etAddress.getText().toString().trim();
                String phone = etPhone.getText().toString().trim();

                if (idStr.isEmpty() || name.isEmpty() || address.isEmpty() || phone.isEmpty()) {
                    Toast.makeText(MainActivity.this, "Please enter all fields", Toast.LENGTH_SHORT).show();
                    return;
                }

                int id = Integer.parseInt(idStr);
                boolean isInserted = dbHelper.insertCustomer(id, name, address, phone);

                if (isInserted) {
                    Toast.makeText(MainActivity.this, "Customer Record Inserted", Toast.LENGTH_SHORT).show();
                    etId.setText("");
                    etName.setText("");
                    etAddress.setText("");
                    etPhone.setText("");
                } else {
                    Toast.makeText(MainActivity.this, "Insertion Failed (ID may already exist)", Toast.LENGTH_SHORT).show();
                }
            }
        });

        // i] Batch insert sample customer records
        btnInsertDefault.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int[] ids = {1, 2, 3};
                String[] names = {"Alice Smith", "Bob Johnson", "Charlie Brown"};
                String[] addresses = {"Main Street, NY", "Oak Avenue, CA", "Pine Road, TX"};
                String[] phones = {"9876543210", "8765432109", "7654321098"};

                int insertedCount = 0;
                for (int i = 0; i < ids.length; i++) {
                    if (dbHelper.insertCustomer(ids[i], names[i], addresses[i], phones[i])) {
                        insertedCount++;
                    }
                }
                Toast.makeText(MainActivity.this, insertedCount + " sample records added", Toast.LENGTH_SHORT).show();
            }
        });

        // ii] Show all customer details
        btnViewAll.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Cursor cursor = dbHelper.getAllCustomers();

                if (cursor == null || cursor.getCount() == 0) {
                    tvDisplayData.setText("No records found in Customer table.");
                    Toast.makeText(MainActivity.this, "No records found", Toast.LENGTH_SHORT).show();
                    return;
                }

                StringBuilder builder = new StringBuilder();
                while (cursor.moveToNext()) {
                    int id = cursor.getInt(0);
                    String name = cursor.getString(1);
                    String address = cursor.getString(2);
                    String phone = cursor.getString(3);

                    builder.append("Customer ID: ").append(id).append("\n");
                    builder.append("Name: ").append(name).append("\n");
                    builder.append("Address: ").append(address).append("\n");
                    builder.append("Phone No: ").append(phone).append("\n");
                    builder.append("------------------------------------\n");
                }
                cursor.close();

                tvDisplayData.setText(builder.toString());
            }
        });
    }
}