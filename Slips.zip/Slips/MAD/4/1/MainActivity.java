// Q.1] Create a Application which shows Life Cycle of Activity. [10 Marks]
// File Name: MainActivity.java
// File Path: src/main/java/com/example/lifecycleapp/MainActivity.java

package com.example.lifecycleapp;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private static final String TAG = "LifecycleEvent";
    private TextView tvLifecycleLogs;
    private Button btnClearLogs;

    // Helper method to display events via Logcat, Toast, and on-screen TextView
    private void recordLifecycleEvent(String callbackName) {
        // 1. Output to Logcat
        Log.d(TAG, callbackName + "() called");

        // 2. Display short Toast notification
        Toast.makeText(this, callbackName + "() called", Toast.LENGTH_SHORT).show();

        // 3. Append to on-screen log viewer
        if (tvLifecycleLogs != null) {
            tvLifecycleLogs.append("• " + callbackName + "() called\n");
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        tvLifecycleLogs = findViewById(R.id.tvLifecycleLogs);
        btnClearLogs = findViewById(R.id.btnClearLogs);

        btnClearLogs.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                tvLifecycleLogs.setText("");
            }
        });

        recordLifecycleEvent("onCreate");
    }

    @Override
    protected void onStart() {
        super.onStart();
        recordLifecycleEvent("onStart");
    }

    @Override
    protected void onResume() {
        super.onResume();
        recordLifecycleEvent("onResume");
    }

    @Override
    protected void onPause() {
        super.onPause();
        recordLifecycleEvent("onPause");
    }

    @Override
    protected void onStop() {
        super.onStop();
        recordLifecycleEvent("onStop");
    }

    @Override
    protected void onRestart() {
        super.onRestart();
        recordLifecycleEvent("onRestart");
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        recordLifecycleEvent("onDestroy");
    }
}