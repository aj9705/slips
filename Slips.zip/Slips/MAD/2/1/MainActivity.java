// File: java/com/example/primechecker/MainActivity.java
package com.example.primechecker;

import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private EditText etNumber;
    private Button btnCheckPrime;
    private TextView tvResult;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        etNumber = findViewById(R.id.etNumber);
        btnCheckPrime = findViewById(R.id.btnCheckPrime);
        tvResult = findViewById(R.id.tvResult);

        btnCheckPrime.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                checkPrimeNumber();
            }
        });
    }

    private void checkPrimeNumber() {
        String input = etNumber.getText().toString().trim();

        if (input.isEmpty()) {
            tvResult.setTextColor(Color.RED);
            tvResult.setText("Please enter a valid number.");
            return;
        }

        try {
            int number = Integer.parseInt(input);

            if (isPrime(number)) {
                tvResult.setTextColor(Color.parseColor("#2E7D32")); // Green
                tvResult.setText(number + " is a Prime Number.");
            } else {
                tvResult.setTextColor(Color.parseColor("#C62828")); // Red
                tvResult.setText(number + " is NOT a Prime Number.");
            }
        } catch (NumberFormatException e) {
            tvResult.setTextColor(Color.RED);
            tvResult.setText("Number is too large to evaluate.");
        }
    }

    private boolean isPrime(int n) {
        if (n <= 1) {
            return false;
        }
        if (n <= 3) {
            return true;
        }
        if (n % 2 == 0 || n % 3 == 0) {
            return false;
        }

        for (int i = 5; i * i <= n; i += 6) {
            if (n % i == 0 || n % (i + 2) == 0) {
                return false;
            }
        }
        return true;
    }
}