// File: java/com/example/calculator/MainActivity.java
package com.example.calculator;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    private TextView tvDisplay;
    private double firstOperand = 0;
    private String operator = "";
    private boolean isOperatorClicked = false;
    private boolean isResultShown = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        tvDisplay = findViewById(R.id.tvDisplay);

        int[] buttonIds = {
                R.id.btn0, R.id.btn1, R.id.btn2, R.id.btn3, R.id.btn4,
                R.id.btn5, R.id.btn6, R.id.btn7, R.id.btn8, R.id.btn9,
                R.id.btnDot, R.id.btnAdd, R.id.btnSub, R.id.btnMul,
                R.id.btnDiv, R.id.btnMod, R.id.btnDel, R.id.btnAnswer
        };

        for (int id : buttonIds) {
            findViewById(id).setOnClickListener(this);
        }
    }

    @Override
    public void onClick(View view) {
        Button button = (Button) view;
        String buttonText = button.getText().toString();

        switch (buttonText) {
            case "DEL":
                handleDelete();
                break;

            case "ANSWER":
                calculateResult();
                break;

            case "+":
            case "-":
            case "x":
            case "/":
            case "%":
                handleOperator(buttonText);
                break;

            case ".":
                handleDecimal();
                break;

            default:
                handleNumber(buttonText);
                break;
        }
    }

    private void handleNumber(String num) {
        if (isOperatorClicked || isResultShown || tvDisplay.getText().toString().equals("0")) {
            tvDisplay.setText(num);
            isOperatorClicked = false;
            isResultShown = false;
        } else {
            tvDisplay.append(num);
        }
    }

    private void handleDecimal() {
        if (isOperatorClicked || isResultShown) {
            tvDisplay.setText("0.");
            isOperatorClicked = false;
            isResultShown = false;
        } else if (!tvDisplay.getText().toString().contains(".")) {
            tvDisplay.append(".");
        }
    }

    private void handleOperator(String op) {
        try {
            firstOperand = Double.parseDouble(tvDisplay.getText().toString());
            operator = op;
            isOperatorClicked = true;
        } catch (NumberFormatException e) {
            tvDisplay.setText("Error");
        }
    }

    private void handleDelete() {
        String currentText = tvDisplay.getText().toString();
        if (currentText.length() > 1 && !currentText.equals("Error")) {
            tvDisplay.setText(currentText.substring(0, currentText.length() - 1));
        } else {
            tvDisplay.setText("0");
        }
    }

    private void calculateResult() {
        if (operator.isEmpty()) {
            return;
        }

        try {
            double secondOperand = Double.parseDouble(tvDisplay.getText().toString());
            double result = 0;

            switch (operator) {
                case "+":
                    result = firstOperand + secondOperand;
                    break;
                case "-":
                    result = firstOperand - secondOperand;
                    break;
                case "x":
                    result = firstOperand * secondOperand;
                    break;
                case "/":
                    if (secondOperand == 0) {
                        tvDisplay.setText("Error");
                        operator = "";
                        isResultShown = true;
                        return;
                    }
                    result = firstOperand / secondOperand;
                    break;
                case "%":
                    result = firstOperand % secondOperand;
                    break;
            }

            if (result == (long) result) {
                tvDisplay.setText(String.format("%d", (long) result));
            } else {
                tvDisplay.setText(String.valueOf(result));
            }

            operator = "";
            isResultShown = true;

        } catch (Exception e) {
            tvDisplay.setText("Error");
        }
    }
}