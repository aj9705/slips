// Q.1) Create application to send an email. [10 Marks]
// File Name: MainActivity.java
// File Path: src/main/java/com/example/emailapp/MainActivity.java

package com.example.emailapp;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.util.Patterns;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private EditText etEmailTo, etEmailSubject, etEmailMessage;
    private Button btnSendEmail;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Bind layout views
        etEmailTo = findViewById(R.id.etEmailTo);
        etEmailSubject = findViewById(R.id.etEmailSubject);
        etEmailMessage = findViewById(R.id.etEmailMessage);
        btnSendEmail = findViewById(R.id.btnSendEmail);

        btnSendEmail.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                sendEmail();
            }
        });
    }

    private void sendEmail() {
        String recipient = etEmailTo.getText().toString().trim();
        String subject = etEmailSubject.getText().toString().trim();
        String message = etEmailMessage.getText().toString().trim();

        // Validate recipient email
        if (recipient.isEmpty()) {
            etEmailTo.setError("Recipient email is required");
            etEmailTo.requestFocus();
            return;
        }

        if (!Patterns.EMAIL_ADDRESS.matcher(recipient).matches()) {
            etEmailTo.setError("Please enter a valid email address");
            etEmailTo.requestFocus();
            return;
        }

        if (subject.isEmpty()) {
            etEmailSubject.setError("Subject is required");
            etEmailSubject.requestFocus();
            return;
        }

        if (message.isEmpty()) {
            etEmailMessage.setError("Message body is required");
            etEmailMessage.requestFocus();
            return;
        }

        // Implicit Intent to invoke email clients using ACTION_SENDTO with mailto scheme
        Intent emailIntent = new Intent(Intent.ACTION_SENDTO);
        emailIntent.setData(Uri.parse("mailto:")); // Ensures only email apps handle this intent
        emailIntent.putExtra(Intent.EXTRA_EMAIL, new String[]{recipient});
        emailIntent.putExtra(Intent.EXTRA_SUBJECT, subject);
        emailIntent.putExtra(Intent.EXTRA_TEXT, message);

        try {
            startActivity(Intent.createChooser(emailIntent, "Choose an Email Client:"));
        } catch (android.content.ActivityNotFoundException e) {
            Toast.makeText(MainActivity.this, "No email client installed on this device.", Toast.LENGTH_SHORT).show();
        }
    }
}