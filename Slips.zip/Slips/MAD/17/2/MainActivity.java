// Q.2) Create Tables Project (pno, p_name, ptype, duration) and Employee (id, e_name, qualification, join-date), assume Project – employee has a many to many relationship. Using database perform following operation. 1) Add new record into table. 2) Accept a project name from user and display information of employees working on the project.
// File Name: MainActivity.java
// File Path: src/main/java/com/example/projectemployeeapp/MainActivity.java

package com.example.projectemployeeapp;

import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private DatabaseHelper dbHelper;

    // Project Inputs
    private EditText etProjectNo, etProjectName, etProjectType, etProjectDuration;
    private Button btnAddProject;

    // Employee Inputs
    private EditText etEmpId, etEmpName, etEmpQualification, etEmpJoinDate;
    private Button btnAddEmployee;

    // Assignment Inputs
    private EditText etAssignPno, etAssignEmpId;
    private Button btnAssign;

    // Search Inputs & Output
    private EditText etSearchProjectName;
    private Button btnSearchEmployees;
    private TextView tvDisplayResults;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        dbHelper = new DatabaseHelper(this);

        // Bind Project Views
        etProjectNo = findViewById(R.id.etProjectNo);
        etProjectName = findViewById(R.id.etProjectName);
        etProjectType = findViewById(R.id.etProjectType);
        etProjectDuration = findViewById(R.id.etProjectDuration);
        btnAddProject = findViewById(R.id.btnAddProject);

        // Bind Employee Views
        etEmpId = findViewById(R.id.etEmpId);
        etEmpName = findViewById(R.id.etEmpName);
        etEmpQualification = findViewById(R.id.etEmpQualification);
        etEmpJoinDate = findViewById(R.id.etEmpJoinDate);
        btnAddEmployee = findViewById(R.id.btnAddEmployee);

        // Bind Assignment Views
        etAssignPno = findViewById(R.id.etAssignPno);
        etAssignEmpId = findViewById(R.id.etAssignEmpId);
        btnAssign = findViewById(R.id.btnAssign);

        // Bind Search Views
        etSearchProjectName = findViewById(R.id.etSearchProjectName);
        btnSearchEmployees = findViewById(R.id.btnSearchEmployees);
        tvDisplayResults = findViewById(R.id.tvDisplayResults);

        // 1. Insert Project
        btnAddProject.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String pnoStr = etProjectNo.getText().toString().trim();
                String pName = etProjectName.getText().toString().trim();
                String pType = etProjectType.getText().toString().trim();
                String duration = etProjectDuration.getText().toString().trim();

                if (pnoStr.isEmpty() || pName.isEmpty() || pType.isEmpty() || duration.isEmpty()) {
                    Toast.makeText(MainActivity.this, "Fill all Project fields", Toast.LENGTH_SHORT).show();
                    return;
                }

                int pno = Integer.parseInt(pnoStr);
                if (dbHelper.insertProject(pno, pName, pType, duration)) {
                    Toast.makeText(MainActivity.this, "Project Added Successfully", Toast.LENGTH_SHORT).show();
                    etProjectNo.setText("");
                    etProjectName.setText("");
                    etProjectType.setText("");
                    etProjectDuration.setText("");
                } else {
                    Toast.makeText(MainActivity.this, "Project insertion failed (PNO exists)", Toast.LENGTH_SHORT).show();
                }
            }
        });

        // 1. Insert Employee
        btnAddEmployee.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String idStr = etEmpId.getText().toString().trim();
                String eName = etEmpName.getText().toString().trim();
                String qualification = etEmpQualification.getText().toString().trim();
                String joinDate = etEmpJoinDate.getText().toString().trim();

                if (idStr.isEmpty() || eName.isEmpty() || qualification.isEmpty() || joinDate.isEmpty()) {
                    Toast.makeText(MainActivity.this, "Fill all Employee fields", Toast.LENGTH_SHORT).show();
                    return;
                }

                int empId = Integer.parseInt(idStr);
                if (dbHelper.insertEmployee(empId, eName, qualification, joinDate)) {
                    Toast.makeText(MainActivity.this, "Employee Added Successfully", Toast.LENGTH_SHORT).show();
                    etEmpId.setText("");
                    etEmpName.setText("");
                    etEmpQualification.setText("");
                    etEmpJoinDate.setText("");
                } else {
                    Toast.makeText(MainActivity.this, "Employee insertion failed (ID exists)", Toast.LENGTH_SHORT).show();
                }
            }
        });

        // 1. Map Employee to Project (Many-to-Many Assignment)
        btnAssign.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String pnoStr = etAssignPno.getText().toString().trim();
                String empIdStr = etAssignEmpId.getText().toString().trim();

                if (pnoStr.isEmpty() || empIdStr.isEmpty()) {
                    Toast.makeText(MainActivity.this, "Enter both Project No and Employee ID", Toast.LENGTH_SHORT).show();
                    return;
                }

                int pno = Integer.parseInt(pnoStr);
                int empId = Integer.parseInt(empIdStr);

                if (dbHelper.assignEmployeeToProject(pno, empId)) {
                    Toast.makeText(MainActivity.this, "Employee assigned to Project", Toast.LENGTH_SHORT).show();
                    etAssignPno.setText("");
                    etAssignEmpId.setText("");
                } else {
                    Toast.makeText(MainActivity.this, "Assignment failed (Already mapped)", Toast.LENGTH_SHORT).show();
                }
            }
        });

        // 2. Accept Project Name and display employees working on that project
        btnSearchEmployees.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String searchProject = etSearchProjectName.getText().toString().trim();

                if (searchProject.isEmpty()) {
                    Toast.makeText(MainActivity.this, "Please enter a project name to search", Toast.LENGTH_SHORT).show();
                    return;
                }

                Cursor cursor = dbHelper.getEmployeesByProjectName(searchProject);

                if (cursor == null || cursor.getCount() == 0) {
                    tvDisplayResults.setText("No employees found working on project: " + searchProject);
                    Toast.makeText(MainActivity.this, "No matching records found", Toast.LENGTH_SHORT).show();
                    return;
                }

                StringBuilder sb = new StringBuilder();
                sb.append("Employees on Project: ").append(searchProject).append("\n");
                sb.append("====================================\n");

                while (cursor.moveToNext()) {
                    int empId = cursor.getInt(0);
                    String empName = cursor.getString(1);
                    String qualification = cursor.getString(2);
                    String joinDate = cursor.getString(3);

                    sb.append("Employee ID   : ").append(empId).append("\n");
                    sb.append("Employee Name : ").append(empName).append("\n");
                    sb.append("Qualification : ").append(qualification).append("\n");
                    sb.append("Join Date     : ").append(joinDate).append("\n");
                    sb.append("------------------------------------\n");
                }
                cursor.close();

                tvDisplayResults.setText(sb.toString());
            }
        });
    }
}