// Q.2) Create Tables Project (pno, p_name, ptype, duration) and Employee (id, e_name, qualification, join-date), assume Project – employee has a many to many relationship. Using database perform following operation. 1) Add new record into table. 2) Accept a project name from user and display information of employees working on the project.
// File Name: DatabaseHelper.java
// File Path: src/main/java/com/example/projectemployeeapp/DatabaseHelper.java

package com.example.projectemployeeapp;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class DatabaseHelper extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "CompanyDB.db";
    private static final int DATABASE_VERSION = 1;

    // Table 1: Project
    public static final String TABLE_PROJECT = "Project";
    public static final String COL_PNO = "pno";
    public static final String COL_P_NAME = "p_name";
    public static final String COL_PTYPE = "ptype";
    public static final String COL_DURATION = "duration";

    // Table 2: Employee
    public static final String TABLE_EMPLOYEE = "Employee";
    public static final String COL_EMP_ID = "id";
    public static final String COL_E_NAME = "e_name";
    public static final String COL_QUALIFICATION = "qualification";
    public static final String COL_JOIN_DATE = "join_date";

    // Table 3: Junction Table for Many-to-Many Relationship (Project_Employee)
    public static final String TABLE_PROJECT_EMPLOYEE = "Project_Employee";
    public static final String COL_PE_PNO = "pno";
    public static final String COL_PE_EMP_ID = "emp_id";

    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        // Create Project Table
        String createProjectTable = "CREATE TABLE " + TABLE_PROJECT + " ("
                + COL_PNO + " INTEGER PRIMARY KEY, "
                + COL_P_NAME + " TEXT, "
                + COL_PTYPE + " TEXT, "
                + COL_DURATION + " TEXT)";
        db.execSQL(createProjectTable);

        // Create Employee Table
        String createEmployeeTable = "CREATE TABLE " + TABLE_EMPLOYEE + " ("
                + COL_EMP_ID + " INTEGER PRIMARY KEY, "
                + COL_E_NAME + " TEXT, "
                + COL_QUALIFICATION + " TEXT, "
                + COL_JOIN_DATE + " TEXT)";
        db.execSQL(createEmployeeTable);

        // Create Junction Table for Many-to-Many Relationship
        String createJunctionTable = "CREATE TABLE " + TABLE_PROJECT_EMPLOYEE + " ("
                + COL_PE_PNO + " INTEGER, "
                + COL_PE_EMP_ID + " INTEGER, "
                + "PRIMARY KEY (" + COL_PE_PNO + ", " + COL_PE_EMP_ID + "), "
                + "FOREIGN KEY (" + COL_PE_PNO + ") REFERENCES " + TABLE_PROJECT + "(" + COL_PNO + "), "
                + "FOREIGN KEY (" + COL_PE_EMP_ID + ") REFERENCES " + TABLE_EMPLOYEE + "(" + COL_EMP_ID + "))";
        db.execSQL(createJunctionTable);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_PROJECT_EMPLOYEE);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_PROJECT);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_EMPLOYEE);
        onCreate(db);
    }

    // 1) Add new Project record
    public boolean insertProject(int pno, String pName, String pType, String duration) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put(COL_PNO, pno);
        cv.put(COL_P_NAME, pName);
        cv.put(COL_PTYPE, pType);
        cv.put(COL_DURATION, duration);
        long res = db.insert(TABLE_PROJECT, null, cv);
        return res != -1;
    }

    // 1) Add new Employee record
    public boolean insertEmployee(int empId, String eName, String qualification, String joinDate) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put(COL_EMP_ID, empId);
        cv.put(COL_E_NAME, eName);
        cv.put(COL_QUALIFICATION, qualification);
        cv.put(COL_JOIN_DATE, joinDate);
        long res = db.insert(TABLE_EMPLOYEE, null, cv);
        return res != -1;
    }

    // 1) Assign Employee to Project (Many-to-Many mapping)
    public boolean assignEmployeeToProject(int pno, int empId) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put(COL_PE_PNO, pno);
        cv.put(COL_PE_EMP_ID, empId);
        long res = db.insert(TABLE_PROJECT_EMPLOYEE, null, cv);
        return res != -1;
    }

    // 2) Accept Project Name from user and display information of employees working on the project
    public Cursor getEmployeesByProjectName(String projectName) {
        SQLiteDatabase db = this.getReadableDatabase();
        String query = "SELECT e." + COL_EMP_ID + ", e." + COL_E_NAME + ", e." + COL_QUALIFICATION + ", e." + COL_JOIN_DATE + ", p." + COL_P_NAME
                + " FROM " + TABLE_EMPLOYEE + " e "
                + " JOIN " + TABLE_PROJECT_EMPLOYEE + " pe ON e." + COL_EMP_ID + " = pe." + COL_PE_EMP_ID
                + " JOIN " + TABLE_PROJECT + " p ON pe." + COL_PE_PNO + " = p." + COL_PNO
                + " WHERE LOWER(p." + COL_P_NAME + ") = LOWER(?)";

        return db.rawQuery(query, new String[]{projectName});
    }
}