// Q.1) Design an application for login activity. Write android code to check login credentials with username = "mca" and password = "android". Display appropriate toast message to the user. [10 Marks]
// File Name: MainActivity.java
// File Path: src/main/java/com/example/loginactivityapp/MainActivity.java

package com.example.loginactivityapp;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private EditText etUsername, etPassword;
    private Button btnLogin;

    // Expected valid credentials
    private static final String CORRECT_USERNAME = "mca";
    private static final String CORRECT_PASSWORD = "android";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Bind layout views
        etUsername = findViewById(R.id.etUsername);
        etPassword = findViewById(R.id.etPassword);
        btnLogin = findViewById(R.id.btnLogin);

        btnLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                checkLogin();
            }
        });
    }

    private void checkLogin() {
        String username = etUsername.getText().toString().trim();
        String password = etPassword.getText().toString().trim();

        // Validation for empty inputs
        if (username.isEmpty() || password.isEmpty()) {
            Toast.makeText(MainActivity.this, "Please enter both username and password", Toast.LENGTH_SHORT).show();
            return;
        }

        // Credential verification
        if (username.equals(CORRECT_USERNAME) && password.equals(CORRECT_PASSWORD)) {
            Toast.makeText(MainActivity.this, "Login Successful! Welcome " + username, Toast.LENGTH_LONG).show();
        } else {
            Toast.makeText(MainActivity.this, "Login Failed: Invalid Credentials!", Toast.LENGTH_SHORT).show();
        }
    }
}