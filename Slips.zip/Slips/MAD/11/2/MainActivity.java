// Q.2) Create the simple calculator shown below also perform appropriate operation.
// File Name: MainActivity.java
// File Path: src/main/java/com/example/assignment1/MainActivity.java

package com.example.assignment1;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    private EditText etDisplay;

    private double firstOperand = 0;
    private String operator = "";
    private boolean isNewOperation = true;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        etDisplay = findViewById(R.id.etDisplay);

        // Numeric and special buttons
        int[] numButtonIds = {
                R.id.btn0, R.id.btn1, R.id.btn2, R.id.btn3, R.id.btn4,
                R.id.btn5, R.id.btn6, R.id.btn7, R.id.btn8, R.id.btn9,
                R.id.btnDot, R.id.btnClear
        };

        for (int id : numButtonIds) {
            findViewById(id).setOnClickListener(this);
        }

        // Operator buttons
        findViewById(R.id.btnAdd).setOnClickListener(this);
        findViewById(R.id.btnSub).setOnClickListener(this);
        findViewById(R.id.btnMul).setOnClickListener(this);
        findViewById(R.id.btnDiv).setOnClickListener(this);
        findViewById(R.id.btnEqual).setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        int viewId = v.getId();

        // 1. Clear button
        if (viewId == R.id.btnClear) {
            etDisplay.setText("");
            firstOperand = 0;
            operator = "";
            isNewOperation = true;
            return;
        }

        // 2. Equals button
        if (viewId == R.id.btnEqual) {
            calculateResult();
            return;
        }

        // 3. Operator buttons
        if (viewId == R.id.btnAdd || viewId == R.id.btnSub || viewId == R.id.btnMul || viewId == R.id.btnDiv) {
            String currentText = etDisplay.getText().toString().trim();
            if (!currentText.isEmpty()) {
                firstOperand = Double.parseDouble(currentText);
                Button opBtn = (Button) v;
                operator = opBtn.getText().toString();
                isNewOperation = true;
            }
            return;
        }

        // 4. Dot button
        if (viewId == R.id.btnDot) {
            if (isNewOperation) {
                etDisplay.setText("0.");
                isNewOperation = false;
            } else if (!etDisplay.getText().toString().contains(".")) {
                etDisplay.append(".");
            }
            return;
        }

        // 5. Number buttons
        Button digitButton = (Button) v;
        String digit = digitButton.getText().toString();

        if (isNewOperation) {
            etDisplay.setText(digit);
            isNewOperation = false;
        } else {
            etDisplay.append(digit);
        }
    }

    private void calculateResult() {
        String currentText = etDisplay.getText().toString().trim();

        if (currentText.isEmpty() || operator.isEmpty()) {
            return;
        }

        double secondOperand = Double.parseDouble(currentText);
        double result = 0;

        switch (operator) {
            case "+":
                result = firstOperand + secondOperand;
                break;
            case "-":
                result = firstOperand - secondOperand;
                break;
            case "*":
                result = firstOperand * secondOperand;
                break;
            case "/":
                if (secondOperand == 0) {
                    Toast.makeText(this, "Cannot divide by zero", Toast.LENGTH_SHORT).show();
                    etDisplay.setText("");
                    operator = "";
                    isNewOperation = true;
                    return;
                }
                result = firstOperand / secondOperand;
                break;
        }

        // Format whole numbers cleanly without trailing decimal point
        if (result == (long) result) {
            etDisplay.setText(String.format("%d", (long) result));
        } else {
            etDisplay.setText(String.valueOf(result));
        }

        firstOperand = result;
        operator = "";
        isNewOperation = true;
    }
}