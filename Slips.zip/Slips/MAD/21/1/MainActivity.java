// Q.1) Create a Simple Application, which reads a positive number from the user and display its factorial value in another activity.
// File Name: MainActivity.java
// File Path: src/main/java/com/example/factorialactivityapp/MainActivity.java

package com.example.factorialactivityapp;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private EditText etNumber;
    private Button btnSubmit;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Bind views
        etNumber = findViewById(R.id.etNumber);
        btnSubmit = findViewById(R.id.btnSubmit);

        btnSubmit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                processAndNavigate();
            }
        });
    }

    private void processAndNavigate() {
        String input = etNumber.getText().toString().trim();

        if (input.isEmpty()) {
            Toast.makeText(MainActivity.this, "Please enter a number", Toast.LENGTH_SHORT).show();
            return;
        }

        try {
            int number = Integer.parseInt(input);

            // Verify number is positive (>= 0; strictly positive usually implies > 0, 0! = 1)
            if (number < 0) {
                Toast.makeText(MainActivity.this, "Please enter a positive number", Toast.LENGTH_SHORT).show();
                return;
            }

            if (number > 20) {
                Toast.makeText(MainActivity.this, "Enter a number <= 20 to avoid integer overflow", Toast.LENGTH_SHORT).show();
                return;
            }

            // Calculate factorial
            long factorial = 1;
            for (int i = 1; i <= number; i++) {
                factorial *= i;
            }

            // Send input number and computed factorial to the second activity
            Intent intent = new Intent(MainActivity.this, ResultActivity.class);
            intent.putExtra("INPUT_NUMBER", number);
            intent.putExtra("FACTORIAL_RESULT", factorial);
            startActivity(intent);

        } catch (NumberFormatException e) {
            Toast.makeText(MainActivity.this, "Number is too large", Toast.LENGTH_SHORT).show();
        }
    }
}