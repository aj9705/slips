// Q.1) Create a Simple Application, which reads a positive number from the user and display its factorial value in another activity.
// File Name: ResultActivity.java
// File Path: src/main/java/com/example/factorialactivityapp/ResultActivity.java

package com.example.factorialactivityapp;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class ResultActivity extends AppCompatActivity {

    private TextView tvInputSummary, tvFactorialValue;
    private Button btnBack;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_result);

        // Bind layout views
        tvInputSummary = findViewById(R.id.tvInputSummary);
        tvFactorialValue = findViewById(R.id.tvFactorialValue);
        btnBack = findViewById(R.id.btnBack);

        // Retrieve data sent from MainActivity
        Intent intent = getIntent();
        int inputNumber = intent.getIntExtra("INPUT_NUMBER", 0);
        long factorialResult = intent.getLongExtra("FACTORIAL_RESULT", 1);

        // Set output values
        tvInputSummary.setText("Input Number: " + inputNumber);
        tvFactorialValue.setText(inputNumber + "! = " + factorialResult);

        // Back button to close this activity
        btnBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
    }
}