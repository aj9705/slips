// Q.2) Create an Android App, it reads the Students Details (Name, Surname, Class, Gender, Hobbies, Marks) and display the all information in another activity in table format on click of Submit button. [20 Marks]
// File Name: MainActivity.java
// File Path: src/main/java/com/example/studenttableapp/MainActivity.java

package com.example.studenttableapp;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    private EditText etName, etSurname, etClass, etMarks;
    private RadioGroup rgGender;
    private CheckBox cbReading, cbSports, cbMusic;
    private Button btnSubmit;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Bind form views
        etName = findViewById(R.id.etName);
        etSurname = findViewById(R.id.etSurname);
        etClass = findViewById(R.id.etClass);
        etMarks = findViewById(R.id.etMarks);
        rgGender = findViewById(R.id.rgGender);
        cbReading = findViewById(R.id.cbReading);
        cbSports = findViewById(R.id.cbSports);
        cbMusic = findViewById(R.id.cbMusic);
        btnSubmit = findViewById(R.id.btnSubmit);

        btnSubmit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                processAndSubmit();
            }
        });
    }

    private void processAndSubmit() {
        String name = etName.getText().toString().trim();
        String surname = etSurname.getText().toString().trim();
        String studentClass = etClass.getText().toString().trim();
        String marks = etMarks.getText().toString().trim();

        // 1. Text Validations
        if (name.isEmpty()) {
            etName.setError("Name is required");
            etName.requestFocus();
            return;
        }

        if (surname.isEmpty()) {
            etSurname.setError("Surname is required");
            etSurname.requestFocus();
            return;
        }

        if (studentClass.isEmpty()) {
            etClass.setError("Class is required");
            etClass.requestFocus();
            return;
        }

        if (marks.isEmpty()) {
            etMarks.setError("Marks are required");
            etMarks.requestFocus();
            return;
        }

        // 2. Extract Gender
        int selectedGenderId = rgGender.getCheckedRadioButtonId();
        RadioButton selectedRadio = findViewById(selectedGenderId);
        String gender = (selectedRadio != null) ? selectedRadio.getText().toString() : "Not Specified";

        // 3. Extract Selected Hobbies
        ArrayList<String> hobbiesList = new ArrayList<>();
        if (cbReading.isChecked()) hobbiesList.add("Reading");
        if (cbSports.isChecked()) hobbiesList.add("Sports");
        if (cbMusic.isChecked()) hobbiesList.add("Music");

        String hobbies = hobbiesList.isEmpty() ? "None" : android.text.TextUtils.join(", ", hobbiesList);

        // 4. Pass Data to Table Display Activity
        Intent intent = new Intent(MainActivity.this, TableDisplayActivity.class);
        intent.putExtra("STU_NAME", name);
        intent.putExtra("STU_SURNAME", surname);
        intent.putExtra("STU_CLASS", studentClass);
        intent.putExtra("STU_GENDER", gender);
        intent.putExtra("STU_HOBBIES", hobbies);
        intent.putExtra("STU_MARKS", marks);

        startActivity(intent);
    }
}