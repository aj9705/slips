// Q.2) Create an Android App, it reads the Students Details (Name, Surname, Class, Gender, Hobbies, Marks) and display the all information in another activity in table format on click of Submit button. [20 Marks]
// File Name: TableDisplayActivity.java
// File Path: src/main/java/com/example/studenttableapp/TableDisplayActivity.java

package com.example.studenttableapp;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class TableDisplayActivity extends AppCompatActivity {

    private TextView tvTableName, tvTableSurname, tvTableClass, tvTableGender, tvTableHobbies, tvTableMarks;
    private Button btnBack;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_table_display);

        // Bind table cells
        tvTableName = findViewById(R.id.tvTableName);
        tvTableSurname = findViewById(R.id.tvTableSurname);
        tvTableClass = findViewById(R.id.tvTableClass);
        tvTableGender = findViewById(R.id.tvTableGender);
        tvTableHobbies = findViewById(R.id.tvTableHobbies);
        tvTableMarks = findViewById(R.id.tvTableMarks);
        btnBack = findViewById(R.id.btnBack);

        // Retrieve data from Intent
        Intent intent = getIntent();
        String name = intent.getStringExtra("STU_NAME");
        String surname = intent.getStringExtra("STU_SURNAME");
        String studentClass = intent.getStringExtra("STU_CLASS");
        String gender = intent.getStringExtra("STU_GENDER");
        String hobbies = intent.getStringExtra("STU_HOBBIES");
        String marks = intent.getStringExtra("STU_MARKS");

        // Populate table views
        tvTableName.setText(name);
        tvTableSurname.setText(surname);
        tvTableClass.setText(studentClass);
        tvTableGender.setText(gender);
        tvTableHobbies.setText(hobbies);
        tvTableMarks.setText(marks);

        btnBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
    }
}