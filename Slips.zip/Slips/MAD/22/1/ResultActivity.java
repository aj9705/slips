// Q.1) Create an Android Application to accept two numbers and find power and Average. Display the result on the next activity on Button click.
// File Name: ResultActivity.java
// File Path: src/main/java/com/example/poweravgapp/ResultActivity.java

package com.example.poweravgapp;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

import java.util.Locale;

public class ResultActivity extends AppCompatActivity {

    private TextView tvInputs, tvPower, tvAverage;
    private Button btnBack;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_result);

        // Bind views
        tvInputs = findViewById(R.id.tvInputs);
        tvPower = findViewById(R.id.tvPower);
        tvAverage = findViewById(R.id.tvAverage);
        btnBack = findViewById(R.id.btnBack);

        // Retrieve data from Intent
        Intent intent = getIntent();
        double base = intent.getDoubleExtra("BASE_VAL", 0.0);
        double exponent = intent.getDoubleExtra("EXP_VAL", 0.0);
        double power = intent.getDoubleExtra("POWER_RES", 0.0);
        double average = intent.getDoubleExtra("AVG_RES", 0.0);

        // Format and display details
        tvInputs.setText(String.format(Locale.getDefault(), "Number 1 (Base): %.2f\nNumber 2 (Exponent): %.2f", base, exponent));
        tvPower.setText(String.format(Locale.getDefault(), "Power (%.2f ^ %.2f) = %.2f", base, exponent, power));
        tvAverage.setText(String.format(Locale.getDefault(), "Average = %.2f", average));

        // Return to input activity
        btnBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
    }
}