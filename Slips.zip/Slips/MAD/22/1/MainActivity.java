// Q.1) Create an Android Application to accept two numbers and find power and Average. Display the result on the next activity on Button click.
// File Name: MainActivity.java
// File Path: src/main/java/com/example/poweravgapp/MainActivity.java

package com.example.poweravgapp;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private EditText etNumber1, etNumber2;
    private Button btnCalculate;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Bind layout views
        etNumber1 = findViewById(R.id.etNumber1);
        etNumber2 = findViewById(R.id.etNumber2);
        btnCalculate = findViewById(R.id.btnCalculate);

        btnCalculate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                calculateAndNavigate();
            }
        });
    }

    private void calculateAndNavigate() {
        String num1Str = etNumber1.getText().toString().trim();
        String num2Str = etNumber2.getText().toString().trim();

        // Validate empty fields
        if (num1Str.isEmpty() || num2Str.isEmpty()) {
            Toast.makeText(MainActivity.this, "Please enter both numbers", Toast.LENGTH_SHORT).show();
            return;
        }

        try {
            double base = Double.parseDouble(num1Str);
            double exponent = Double.parseDouble(num2Str);

            // Compute Power and Average
            double power = Math.pow(base, exponent);
            double average = (base + exponent) / 2.0;

            // Pass inputs and calculated results to ResultActivity
            Intent intent = new Intent(MainActivity.this, ResultActivity.class);
            intent.putExtra("BASE_VAL", base);
            intent.putExtra("EXP_VAL", exponent);
            intent.putExtra("POWER_RES", power);
            intent.putExtra("AVG_RES", average);

            startActivity(intent);

        } catch (NumberFormatException e) {
            Toast.makeText(MainActivity.this, "Invalid number entered", Toast.LENGTH_SHORT).show();
        }
    }
}