// Q.2) Create an Android application to perform following operations on table Student (Sid, Sname, phno). Use autoincrement for Sid and Perform following Operations. [20 Marks]
// a) Add Student and display its information.
// b) Delete Student
// File Name: DatabaseHelper.java
// File Path: src/main/java/com/example/studentcrudapp/DatabaseHelper.java

package com.example.studentcrudapp;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class DatabaseHelper extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "StudentManagement.db";
    private static final int DATABASE_VERSION = 1;

    public static final String TABLE_NAME = "Student";
    public static final String COL_SID = "Sid";
    public static final String COL_SNAME = "Sname";
    public static final String COL_PHNO = "phno";

    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        // Table creation with Sid as INTEGER PRIMARY KEY AUTOINCREMENT
        String createTableQuery = "CREATE TABLE " + TABLE_NAME + " ("
                + COL_SID + " INTEGER PRIMARY KEY AUTOINCREMENT, "
                + COL_SNAME + " TEXT, "
                + COL_PHNO + " TEXT)";
        db.execSQL(createTableQuery);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_NAME);
        onCreate(db);
    }

    // a) Add Student (Returns generated autoincrement Sid)
    public long insertStudent(String sname, String phno) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COL_SNAME, sname);
        values.put(COL_PHNO, phno);

        return db.insert(TABLE_NAME, null, values);
    }

    // a) Fetch student by Sid to display newly added student's details
    public Cursor getStudentById(long sid) {
        SQLiteDatabase db = this.getReadableDatabase();
        return db.rawQuery("SELECT * FROM " + TABLE_NAME + " WHERE " + COL_SID + " = ?", new String[]{String.valueOf(sid)});
    }

    // a) Fetch all students
    public Cursor getAllStudents() {
        SQLiteDatabase db = this.getReadableDatabase();
        return db.rawQuery("SELECT * FROM " + TABLE_NAME, null);
    }

    // b) Delete Student by Sid
    public int deleteStudent(int sid) {
        SQLiteDatabase db = this.getWritableDatabase();
        return db.delete(TABLE_NAME, COL_SID + " = ?", new String[]{String.valueOf(sid)});
    }
}