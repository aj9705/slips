// Q.2) Create an Android application to perform following operations on table Student (Sid, Sname, phno). Use autoincrement for Sid and Perform following Operations. [20 Marks]
// a) Add Student and display its information.
// b) Delete Student
// File Name: MainActivity.java
// File Path: src/main/java/com/example/studentcrudapp/MainActivity.java

package com.example.studentcrudapp;

import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private DatabaseHelper dbHelper;
    private EditText etSname, etPhno, etDeleteSid;
    private Button btnAddStudent, btnDisplayAll, btnDeleteStudent;
    private TextView tvDisplayArea;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        dbHelper = new DatabaseHelper(this);

        // Bind layout views
        etSname = findViewById(R.id.etSname);
        etPhno = findViewById(R.id.etPhno);
        etDeleteSid = findViewById(R.id.etDeleteSid);
        btnAddStudent = findViewById(R.id.btnAddStudent);
        btnDisplayAll = findViewById(R.id.btnDisplayAll);
        btnDeleteStudent = findViewById(R.id.btnDeleteStudent);
        tvDisplayArea = findViewById(R.id.tvDisplayArea);

        // a) Add Student and display its information immediately
        btnAddStudent.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                addStudentAndDisplay();
            }
        });

        // Display all students
        btnDisplayAll.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                displayAllStudents();
            }
        });

        // b) Delete Student by Sid
        btnDeleteStudent.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                deleteStudentRecord();
            }
        });
    }

    // a) Insert record and immediately fetch & display its information using the generated Sid
    private void addStudentAndDisplay() {
        String sname = etSname.getText().toString().trim();
        String phno = etPhno.getText().toString().trim();

        if (sname.isEmpty() || phno.isEmpty()) {
            Toast.makeText(this, "Please enter both Student Name and Phone Number", Toast.LENGTH_SHORT).show();
            return;
        }

        long generatedSid = dbHelper.insertStudent(sname, phno);

        if (generatedSid != -1) {
            Toast.makeText(this, "Student added with Sid: " + generatedSid, Toast.LENGTH_SHORT).show();
            etSname.setText("");
            etPhno.setText("");

            // Fetch and display the newly added record
            Cursor cursor = dbHelper.getStudentById(generatedSid);
            if (cursor != null && cursor.moveToFirst()) {
                int sid = cursor.getInt(0);
                String name = cursor.getString(1);
                String phone = cursor.getString(2);
                cursor.close();

                String info = "Newly Added Student Information:\n"
                        + "====================================\n"
                        + "Sid   : " + sid + " (Auto-incremented)\n"
                        + "Sname : " + name + "\n"
                        + "phno  : " + phone + "\n";
                tvDisplayArea.setText(info);
            }
        } else {
            Toast.makeText(this, "Failed to insert student record", Toast.LENGTH_SHORT).show();
        }
    }

    // b) Delete record by Sid
    private void deleteStudentRecord() {
        String sidStr = etDeleteSid.getText().toString().trim();

        if (sidStr.isEmpty()) {
            Toast.makeText(this, "Please enter Sid to delete", Toast.LENGTH_SHORT).show();
            return;
        }

        try {
            int sid = Integer.parseInt(sidStr);
            int rowsDeleted = dbHelper.deleteStudent(sid);

            if (rowsDeleted > 0) {
                Toast.makeText(this, "Student with Sid " + sid + " deleted successfully", Toast.LENGTH_SHORT).show();
                etDeleteSid.setText("");
                tvDisplayArea.setText("Record with Sid: " + sid + " has been deleted from the database.");
            } else {
                Toast.makeText(this, "No record found with Sid: " + sid, Toast.LENGTH_SHORT).show();
            }
        } catch (NumberFormatException e) {
            Toast.makeText(this, "Invalid Sid format", Toast.LENGTH_SHORT).show();
        }
    }

    // Helper: Display all records in table
    private void displayAllStudents() {
        Cursor cursor = dbHelper.getAllStudents();

        if (cursor == null || cursor.getCount() == 0) {
            tvDisplayArea.setText("No student records available in the database.");
            Toast.makeText(this, "No records found", Toast.LENGTH_SHORT).show();
            return;
        }

        StringBuilder sb = new StringBuilder();
        sb.append("All Student Records:\n");
        sb.append("====================================\n");

        while (cursor.moveToNext()) {
            int sid = cursor.getInt(0);
            String name = cursor.getString(1);
            String phno = cursor.getString(2);

            sb.append("Sid   : ").append(sid).append("\n");
            sb.append("Sname : ").append(name).append("\n");
            sb.append("phno  : ").append(phno).append("\n");
            sb.append("------------------------------------\n");
        }
        cursor.close();

        tvDisplayArea.setText(sb.toString());
    }
}