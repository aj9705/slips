# Q2. Write a Program to Implement Travelling Salesman Problem using Python. [20 Marks]

from itertools import permutations

def travelling_salesman_problem(graph, start):
    vertex = []
    for i in range(len(graph)):
        if i != start:
            vertex.append(i)
            
    min_path_weight = float('inf')
    best_path = []
    
    # Generate all possible permutations of visiting cities
    for perm in permutations(vertex):
        current_path_weight = 0
        k = start
        current_path = [start]
        
        for j in perm:
            current_path_weight += graph[k][j]
            k = j
            current_path.append(k)
            
        # Add cost to return to the starting city to complete the cycle
        current_path_weight += graph[k][start]
        current_path.append(start)
        
        # Update minimum cost and optimal path if a cheaper route is found
        if current_path_weight < min_path_weight:
            min_path_weight = current_path_weight
            best_path = current_path
            
    return min_path_weight, best_path

# Example usage:
if __name__ == "__main__":
    # Distance matrix representing graph connections between 4 cities (0, 1, 2, 3)
    graph = [
        [0, 10, 15, 20],
        [10, 0, 35, 25],
        [15, 35, 0, 30],
        [20, 25, 30, 0]
    ]
    
    start_city = 0
    print("--- Travelling Salesman Problem Solver ---")
    min_cost, optimal_path = travelling_salesman_problem(graph, start_city)
    
    print(f"Minimum Path Cost: {min_cost}")
    print(f"Optimal Path: {' -> '.join(map(str, optimal_path))}")