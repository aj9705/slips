# Q1. Implement Dijkstra’s algorithm to find the shortest path from a source node to all other nodes in a weighted graph.

import heapq

def dijkstra(graph, start_node):
    # Dictionary to store the shortest distance from start_node to each node
    distances = {node: float('inf') for node in graph}
    distances[start_node] = 0
    
    # Priority queue stores tuples of (current_distance, node)
    pq = [(0, start_node)]
    
    while pq:
        current_distance, current_node = heapq.heappop(pq)
        
        # If the distance in pq is greater than the recorded shortest distance, skip
        if current_distance > distances[current_node]:
            continue
            
        for neighbor, weight in graph[current_node].items():
            distance = current_distance + weight
            
            # Found a shorter path to the neighbor
            if distance < distances[neighbor]:
                distances[neighbor] = distance
                heapq.heappush(pq, (distance, neighbor))
                
    return distances

# Example usage:
if __name__ == "__main__":
    # Weighted graph represented as an adjacency list
    graph = {
        'A': {'B': 4, 'C': 2},
        'B': {'A': 4, 'C': 1, 'D': 5},
        'C': {'A': 2, 'B': 1, 'D': 8, 'E': 10},
        'D': {'B': 5, 'C': 8, 'E': 2},
        'E': {'C': 10, 'D': 2}
    }
    
    start = 'A'
    shortest_paths = dijkstra(graph, start)
    
    print(f"Shortest distances from source node '{start}':")
    for node, distance in shortest_paths.items():
        print(f"To {node} -> Distance: {distance}")