# Q2. Write a program to implement Iterative Deepening DFS algorithm. [20 Marks] [ Goal Node =G]

def dls(node, goal, depth, graph):
    """Depth Limited Search helper function."""
    if depth == 0 and node == goal:
        return [node]
    if depth > 0:
        for neighbor in graph.get(node, []):
            result = dls(neighbor, goal, depth - 1, graph)
            if result is not None:
                return [node] + result
    return None

def iddfs(start, goal, max_depth, graph):
    """Iterative Deepening Depth-First Search implementation."""
    for depth in range(max_depth + 1):
        print(f"Searching at depth limit: {depth}")
        result = dls(start, goal, depth, graph)
        if result is not None:
            return result
    return None

# Graph representation based on the tree provided in the image
graph = {
    'A': ['B', 'C'],
    'B': ['D', 'E'],
    'C': ['F', 'G'],
    'D': ['H', 'I'],
    'E': [],
    'F': ['K'],
    'G': [],
    'H': [],
    'I': [],
    'K': []
}

# Execution configuration
start_node = 'A'
goal_node = 'G'

print("--- Iterative Deepening DFS (IDDFS) ---")
solution_path = iddfs(start_node, goal_node, max_depth=4, graph=graph)

if solution_path:
    print(f"\nGoal '{goal_node}' found! Path: {' -> '.join(solution_path)}")
else:
    print(f"\nGoal '{goal_node}' not found within the depth limit.")
