# Q2. Develop a FAQ Bot for a University Website (This chatbot can help students with common questions about admissions, course registration, or contact details.)

def university_faq_bot():
    """
    A simple FAQ chatbot for a university website handling admissions,
    course registration, contact details, library hours, and fees.
    """
    faqs = {
        "admissions": "Admissions for the upcoming academic year open on June 1st. You can apply online through the university admissions portal by submitting your transcripts and application fee.",
        "course registration": "Course registration for the semester begins two weeks prior to classes starting. Students can register through the student self-service portal after consulting their academic advisor.",
        "contact details": "You can reach the university administration office at contact@university.edu or call us at +1-800-555-UNIV. Our office hours are Monday to Friday, 9:00 AM to 5:00 PM.",
        "library": "The campus library is open from 8:00 AM to 10:00 PM on weekdays and from 10:00 AM to 6:00 PM on weekends.",
        "fees": "Tuition fees vary by program. Detailed fee structures and payment deadlines can be found in the finance section of the student portal."
    }

    print("=== Welcome to University Virtual Assistant (FAQ Bot) ===")
    print("I can help you with questions regarding admissions, course registration, contact details, library hours, and fees.")
    print("Type 'exit' or 'quit' to end the conversation.\n")

    while True:
        user_query = input("You: ").strip().lower()
        
        if user_query in ['exit', 'quit', 'bye']:
            print("Bot: Thank you for visiting the university website. Have a great day!")
            break
            
        if not user_query:
            print("Bot: Please enter a valid question or keyword.")
            continue

        # Simple keyword matching against FAQ dictionary
        matched = False
        for key, answer in faqs.items():
            if key in user_query:
                print(f"\nBot: {answer}\n")
                matched = True
                break
        
        if not matched:
            print("\nBot: I'm sorry, I couldn't find an exact answer to your question. You can try asking about 'admissions', 'course registration', 'contact details', 'library', or 'fees'.\n")

if __name__ == "__main__":
    university_faq_bot()