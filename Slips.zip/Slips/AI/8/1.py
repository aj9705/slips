# Q1. Write a program to implement Best First Search. [10 Marks]

import heapq

def best_first_search(start, goal, graph, heuristics):
    """
    Greedy Best-First Search implementation using heuristic values.
    """
    # Priority queue stores tuples of (heuristic_value, current_node, path_history)
    pq = [(heuristics[start], start, [start])]
    visited = set()
    
    while pq:
        h, current, path = heapq.heappop(pq)
        
        # Check if the goal has been reached
        if current == goal:
            return path
            
        if current in visited:
            continue
            
        visited.add(current)
        
        # Explore neighbors
        for neighbor in graph.get(current, []):
            if neighbor not in visited:
                # Priority is determined entirely by the heuristic value of the neighbor
                heapq.heappush(pq, (heuristics[neighbor], neighbor, path + [neighbor]))
                
    return None

# Example usage:
if __name__ == "__main__":
    # Graph represented as an adjacency list
    graph = {
        'S': ['A', 'B'],
        'A': ['C', 'D'],
        'B': ['E', 'G'],
        'C': [],
        'D': [],
        'E': [],
        'G': []
    }
    
    # Heuristic values (estimated distance/cost to the goal node 'G')
    heuristics = {
        'S': 5,
        'A': 3,
        'B': 4,
        'C': 2,
        'D': 6,
        'E': 1,
        'G': 0
    }
    
    start_node = 'S'
    goal_node = 'G'
    
    print(f"--- Best-First Search from '{start_node}' to '{goal_node}' ---")
    path = best_first_search(start_node, goal_node, graph, heuristics)
    
    if path:
        print(f"Goal found! Path: {' -> '.join(path)}")
    else:
        print("Goal not found.")