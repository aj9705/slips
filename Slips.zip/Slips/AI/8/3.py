# Q2. Solve traveling salesman problem using artificial intelligence technique. [20 Marks]

import random

def create_individual(num_cities):
    """Generates a random route (individual) visiting all cities."""
    individual = list(range(num_cities))
    random.shuffle(individual)
    return individual

def calculate_route_distance(route, distance_matrix):
    """Calculates the total distance of a given route."""
    total_distance = 0
    for i in range(len(route)):
        from_city = route[i]
        to_city = route[(i + 1) % len(route)]
        total_distance += distance_matrix[from_city][to_city]
    return total_distance

def initialize_population(pop_size, num_cities):
    """Creates an initial population of random routes."""
    return [create_individual(num_cities) for _ in range(pop_size)]

def rank_routes(population, distance_matrix):
    """Ranks routes based on fitness (inverse of total distance)."""
    fitness_results = {}
    for i, route in enumerate(population):
        fitness_results[i] = 1 / float(calculate_route_distance(route, distance_matrix))
    return sorted(fitness_results.items(), key=lambda x: x[1], reverse=True)

def selection(population_ranked, elite_size):
    """Selects parents for mating using elitism and tournament selection."""
    selection_results = []
    # Retain elite individuals
    for i in range(elite_size):
        selection_results.append(population_ranked[i][0])
    # Select remaining individuals randomly from top performers
    for i in range(len(population_ranked) - elite_size):
        pick = random.choice(population_ranked[:len(population_ranked) // 2])[0]
        selection_results.append(pick)
    return selection_results

def crossover(parent1, parent2):
    """Performs ordered crossover (OX) between two parents."""
    child = []
    childP1 = []
    childP2 = []
    
    geneA = int(random.random() * len(parent1))
    geneB = int(random.random() * len(parent1))
    
    start_gene = min(geneA, geneB)
    end_gene = max(geneA, geneB)
    
    for i in range(start_gene, end_gene):
        childP1.append(parent1[i])
        
    childP2 = [item for item in parent2 if item not in childP1]
    child = childP1 + childP2
    return child

def mate_population(mating_pool, elite_size):
    """Creates the next generation population through crossover."""
    children = []
    length = len(mating_pool) - elite_size
    pool = random.sample(mating_pool, len(mating_pool))
    
    for i in range(elite_size):
        children.append(mating_pool[i])
        
    for i in range(length):
        parent1 = pool[i]
        parent2 = pool[len(pool) - 1 - i]
        child = crossover(parent1, parent2)
        children.append(child)
    return children

def mutate(individual, mutation_rate):
    """Mutates an individual by swapping two cities based on mutation rate."""
    for swapped in range(len(individual)):
        if random.random() < mutation_rate:
            swap_with = int(random.random() * len(individual))
            individual[swapped], individual[swap_with] = individual[swap_with], individual[swapped]
    return individual

def mutate_population(population, mutation_rate):
    """Applies mutation across the entire population."""
    return [mutate(ind, mutation_rate) for ind in population]

def next_generation(current_gen, elite_size, mutation_rate, distance_matrix):
    """Executes one full iteration of the genetic cycle."""
    population_ranked = rank_routes(current_gen, distance_matrix)
    selection_results = selection(population_ranked, elite_size)
    children = mate_population(selection_results, elite_size)
    next_gen = mutate_population(children, mutation_rate)
    return next_gen

def genetic_algorithm(distance_matrix, pop_size, elite_size, mutation_rate, generations):
    """Runs the Genetic Algorithm optimizer for the Travelling Salesman Problem."""
    num_cities = len(distance_matrix)
    population = initialize_population(pop_size, num_cities)
    
    initial_best_distance = calculate_route_distance(population[rank_routes(population, distance_matrix)[0][0]], distance_matrix)
    print(f"Initial Best Distance: {initial_best_distance}")
    
    for _ in range(generations):
        population = next_generation(population, elite_size, mutation_rate, distance_matrix)
        
    best_route_index = rank_routes(population, distance_matrix)[0][0]
    best_route = population[best_route_index]
    best_distance = calculate_route_distance(best_route, distance_matrix)
    return best_route, best_distance

# Example usage:
if __name__ == "__main__":
    # Symmetric Distance Matrix representing travel costs between 5 cities (0 to 4)
    distance_matrix = [
        [0, 29, 20, 21, 15],
        [29, 0, 15, 17, 28],
        [20, 15, 0, 28, 18],
        [21, 17, 28, 0, 39],
        [15, 28, 18, 39, 0]
    ]
    
    print("--- Solving TSP using Artificial Intelligence (Genetic Algorithm) ---")
    best_route, best_distance = genetic_algorithm(
        distance_matrix=distance_matrix, 
        pop_size=100, 
        elite_size=20, 
        mutation_rate=0.01, 
        generations=300
    )
    
    print(f"\nOptimal Route Found: {' -> '.join(map(str, best_route))} -> {best_route[0]}")
    print(f"Minimum Path Distance: {best_distance}")