# Q2. Write a Python program to solve water jug problem. [20 Marks]

from collections import deque

def water_jug_solver(capacity_a, capacity_b, target):
    """
    Solves the Water Jug problem using Breadth-First Search (BFS).
    Finds the sequence of steps to measure the target amount of water.
    """
    # Queue stores tuples of (current_a, current_b, path_history)
    queue = deque([(0, 0, [])])
    visited = set([(0, 0)])
    
    while queue:
        a, b, path = queue.popleft( )
        
        # Check if target is reached in either jug
        if a == target or b == target:
            return path + [(a, b, "Goal Reached")]
            
        # Possible transitions (next_a, next_b, description)
        transitions = [
            (capacity_a, b, "Fill Jug A"),
            (a, capacity_b, "Fill Jug B"),
            (0, b, "Empty Jug A"),
            (a, 0, "Empty Jug B"),
            # Pour Jug A -> Jug B
            (a - min(a, capacity_b - b), b + min(a, capacity_b - b), "Pour Jug A to Jug B"),
            # Pour Jug B -> Jug A
            (a + min(b, capacity_a - a), b - min(b, capacity_a - a), "Pour Jug B to Jug A")
        ]
        
        for next_a, next_b, action in transitions:
            state = (next_a, next_b)
            if state not in visited:
                visited.add(state)
                queue.append((next_a, next_b, path + [(a, b, action)]))
                
    return None

if __name__ == "__main__":
    jug_a_capacity = 4
    jug_b_capacity = 3
    target_amount = 2
    
    print(f"--- Water Jug Problem Solver (Jug A: {jug_a_capacity}L, Jug B: {jug_b_capacity}L, Target: {target_amount}L) ---")
    solution = water_jug_solver(jug_a_capacity, jug_b_capacity, target_amount)
    
    if solution:
        print(f"\nSolution found in {len(solution)} steps:\n")
        print("Start: Jug A: 0L, Jug B: 0L")
        for i, (a, b, action) in enumerate(solution, 1):
            print(f"Step {i}: {action} -> Jug A: {a}L, Jug B: {b}L")
        print("\nTarget successfully measured!")
    else:
        print("No solution exists for the given capacities and target.")