# Q1. Write a Program to Implement Depth First Search using Python. [10 Marks]

def depth_first_search(graph, start_node, visited=None, traversal_order=None):
    """
    Implements Depth First Search (DFS) traversal for a graph recursively.
    """
    if visited is None:
        visited = set()
    if traversal_order is None:
        traversal_order = []
        
    visited.add(start_node)
    traversal_order.append(start_node)
    
    # Explore neighbors
    for neighbor in graph.get(start_node, []):
        if neighbor not in visited:
            depth_first_search(graph, neighbor, visited, traversal_order)
            
    return traversal_order

# Example usage:
if __name__ == "__main__":
    # Graph represented as an adjacency list
    graph = {
        'A': ['B', 'C'],
        'B': ['A', 'D', 'E'],
        'C': ['A', 'F'],
        'D': ['B'],
        'E': ['B', 'F'],
        'F': ['C', 'E']
    }
    
    start = 'A'
    print(f"--- Depth First Search starting from node '{start}' ---")
    result = depth_first_search(graph, start)
    print(" -> ".join(result))