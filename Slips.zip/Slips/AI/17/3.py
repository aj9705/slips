# Q2. Write a program to implement Tic-Tac-Toe_take. [20 Marks]

import math

def print_board(board):
    """Displays the current state of the Tic-Tac-Toe board."""
    print("\n")
    for i in range(0, 9, 3):
        print(f" {board[i]} | {board[i+1]} | {board[i+2]} ")
        if i < 6:
            print("-----------")
    print("\n")

def check_winner(board):
    """Checks for a winner ('X', 'O') or a tie ('Tie'), or returns None if ongoing."""
    winning_combinations = [
        [0, 1, 2], [3, 4, 5], [6, 7, 8],  # Rows
        [0, 3, 6], [1, 4, 7], [2, 5, 8],  # Columns
        [0, 4, 8], [2, 4, 6]             # Diagonals
    ]
    for combo in winning_combinations:
        if board[combo[0]] == board[combo[1]] == board[combo[2]] and board[combo[0]] != " ":
            return board[combo[0]]
    if " " not in board:
        return "Tie"
    return None

def minimax(board, depth, is_maximizing):
    """
    Minimax algorithm to find the optimal move for the AI.
    """
    winner = check_winner(board)
    if winner == 'O':  # AI is 'O' (Maximizing)
        return 10 - depth
    elif winner == 'X':  # Human is 'X' (Minimizing)
        return depth - 10
    elif winner == 'Tie':
        return 0

    if is_maximizing:
        best_score = -math.inf
        for i in range(9):
            if board[i] == " ":
                board[i] = 'O'
                score = minimax(board, depth + 1, False)
                board[i] = " "
                best_score = max(score, best_score)
        return best_score
    else:
        best_score = math.inf
        for i in range(9):
            if board[i] == " ":
                board[i] = 'X'
                score = minimax(board, depth + 1, True)
                board[i] = " "
                best_score = min(score, best_score)
        return best_score

def best_move(board):
    """
    Determines the best available move for the AI ('O').
    """
    best_score = -math.inf
    move = -1
    for i in range(9):
        if board[i] == " ":
            board[i] = 'O'
            score = minimax(board, 0, False)
            board[i] = " "
            if score > best_score:
                best_score = score
                move = i
    return move

def play_tic_tac_toe():
    """Main game loop for Human (X) vs Unbeatable AI (O)."""
    board = [" "] * 9
    
    print("=== Tic-Tac-Toe with Minimax AI ===")
    print("You are 'X' and the AI is 'O'.")
    print("Positions are numbered from 0 to 8 as shown below:")
    print(" 0 | 1 | 2 ")
    print("-----------")
    print(" 3 | 4 | 5 ")
    print("-----------")
    print(" 6 | 7 | 8 ")
    
    while True:
        print_board(board)
        
        # Human turn
        try:
            user_move = int(input("Enter your move (0-8): "))
            if user_move < 0 or user_move > 8 or board[user_move] != " ":
                print("Invalid move! Position already taken or out of range. Try again.")
                continue
        except ValueError:
            print("Please enter a valid integer between 0 and 8.")
            continue
            
        board[user_move] = 'X'
        
        # Check game status after human move
        result = check_winner(board)
        if result:
            print_board(board)
            if result == "Tie":
                print("It's a Tie!")
            else:
                print(f"Winner: {result}!")
            break
            
        # AI turn
        print("AI is making a move...")
        ai_move = best_move(board)
        if ai_move != -1:
            board[ai_move] = 'O'
            
        # Check game status after AI move
        result = check_winner(board)
        if result:
            print_board(board)
            if result == "Tie":
                print("It's a Tie!")
            else:
                print(f"Winner: {result}! (AI wins)")
            break

if __name__ == "__main__":
    play_tic_tac_toe()