# Q2. Write a program to conduct min - max algorithm

def minimax(depth, node_index, maximizing_player, values, max_depth):
    """
    A recursive implementation of the Minimax algorithm for a binary game tree.
    """
    # Base case: leaf node reached
    if depth == max_depth:
        return values[node_index]
    
    if maximizing_player:
        best = float('-inf')
        # Recur for left and right children
        for i in range(2):
            val = minimax(depth + 1, node_index * 2 + i, False, values, max_depth)
            best = max(best, val)
        return best
    else:
        best = float('inf')
        # Recur for left and right children
        for i in range(2):
            val = minimax(depth + 1, node_index * 2 + i, True, values, max_depth)
            best = min(best, val)
        return best

# Example usage:
if __name__ == "__main__":
    # Leaf node values for a binary tree of depth 3 (2^3 = 8 leaf nodes)
    score_values = [3, 5, 2, 9, 12, 5, 23, 3]
    tree_depth = 3
    
    print("--- Minimax Algorithm Implementation ---")
    optimal_value = minimax(0, 0, True, score_values, tree_depth)
    print(f"Leaf Node Values: {score_values}")
    print(f"Optimal Value calculated by Minimax: {optimal_value}")