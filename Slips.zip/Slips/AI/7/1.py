# Q1. Write a Program to Implement Breadth First Search using Python. [10 Marks]

from collections import deque

def bfs(graph, start_node):
    visited = set()
    queue = deque([start_node])
    visited.add(start_node)
    traversal_order = []
    
    while queue:
        current_node = queue.popleft()
        traversal_order.append(current_node)
        
        for neighbor in graph.get(current_node, []):
            if neighbor not in visited:
                visited.add(neighbor)
                queue.append(neighbor)
                
    return traversal_order

# Example usage:
if __name__ == "__main__":
    # Graph represented as an adjacency list
    graph = {
        'A': ['B', 'C'],
        'B': ['D', 'E'],
        'C': ['F'],
        'D': [],
        'E': ['F'],
        'F': []
    }
    
    start = 'A'
    print(f"Breadth First Search starting from node '{start}':")
    result = bfs(graph, start)
    print(" -> ".join(result))