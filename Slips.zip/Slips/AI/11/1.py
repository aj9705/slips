# Given an array of integers, write a Python Program to sort the array in ascending order using Selection Sort.

def selection_sort_ascending(arr):
    """
    Sorts an array of integers in ascending order using Selection Sort.
    """
    n = len(arr)
    for i in range(n):
        # Assume the first element of the unsorted segment is the minimum
        min_index = i
        for j in range(i + 1, n):
            if arr[j] < arr[min_index]:
                min_index = j
        
        # Swap the found minimum element with the first element of the unsorted segment
        if min_index != i:
            arr[i], arr[min_index] = arr[min_index], arr[i]
            
    return arr

# Example usage:
if __name__ == "__main__":
    sample_array = [64, 25, 12, 22, 11]
    print(f"Original Array: {sample_array}")
    
    sorted_array = selection_sort_ascending(sample_array)
    print(f"Sorted Array (Ascending): {sorted_array}")