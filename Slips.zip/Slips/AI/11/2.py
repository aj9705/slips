# Q2. Write a Python program to implement Breadth First Search algorithm. Refer the following graph as an Input for the program. [Initial node=1,Goal node=8] [ 20 Marks ]

from collections import deque

def bfs_shortest_path(graph, start_node, goal_node):
    """
    Implements Breadth First Search to find the path from start_node to goal_node.
    """
    queue = deque([[start_node]])
    visited = set([start_node])
    
    while queue:
        path = queue.popleft()
        current_node = path[-1]
        
        # Check if we have reached the goal node
        if current_node == goal_node:
            return path
            
        # Explore neighbors
        for neighbor in graph.get(current_node, []):
            if neighbor not in visited:
                visited.add(neighbor)
                new_path = list(path)
                new_path.append(neighbor)
                queue.append(new_path)
                
    return None

# Graph representation based on the input graph structure in the image
graph = {
    1: [2, 4],
    2: [3],
    3: [5, 6],
    4: [2, 3],
    5: [7, 8],
    6: [8],
    7: [8],
    8: []
}

if __name__ == "__main__":
    initial_node = 1
    goal_node = 8
    
    print(f"--- Breadth First Search (Initial Node: {initial_node}, Goal Node: {goal_node}) ---")
    path = bfs_shortest_path(graph, initial_node, goal_node)
    
    if path:
        print(f"\nGoal '{goal_node}' successfully found!")
        print(f"Traversal Path: {' -> '.join(map(str, path))}")
        print(f"Total hops/steps: {len(path) - 1}")
    else:
        print(f"\nGoal '{goal_node}' could not be reached from initial node '{initial_node}'.")
