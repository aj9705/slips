# Q2. Write a Program to Implement Monkey Banana Problem using Python. [20 Marks]

from collections import deque

class MonkeyBananaState:
    def __init__(self, monkey_pos, box_pos, on_box, has_banana):
        self.monkey_pos = monkey_pos  # 'door', 'window', 'middle'
        self.box_pos = box_pos        # 'door', 'window', 'middle'
        self.on_box = on_box          # True or False
        self.has_banana = has_banana  # True or False

    def __eq__(self, other):
        return (self.monkey_pos == other.monkey_pos and
                self.box_pos == other.box_pos and
                self.on_box == other.on_box and
                self.has_banana == other.has_banana)

    def __hash__(self):
        return hash((self.monkey_pos, self.box_pos, self.on_box, self.has_banana))

def solve_monkey_banana():
    # Initial state: Monkey at 'door', Box at 'window', on floor, no banana
    initial_state = MonkeyBananaState('door', 'window', False, False)
    
    # Queue for BFS: stores tuples of (current_state, path_of_actions)
    queue = deque([(initial_state, [])])
    visited = {initial_state}

    while queue:
        current, path = queue.popleft()

        # Goal check: Monkey has successfully grabbed the banana
        if current.has_banana:
            return path

        possible_actions = []

        # 1. Walk: Monkey moves on the floor to a different position
        if not current.on_box:
            for pos in ['door', 'window', 'middle']:
                if pos != current.monkey_pos:
                    new_state = MonkeyBananaState(pos, current.box_pos, False, current.has_banana)
                    possible_actions.append((new_state, f"Walk from {current.monkey_pos} to {pos}"))

        # 2. Push Box: Monkey pushes the box to a new position (requires monkey and box to be at the same place)
        if not current.on_box and current.monkey_pos == current.box_pos:
            for pos in ['door', 'window', 'middle']:
                if pos != current.box_pos:
                    new_state = MonkeyBananaState(pos, pos, False, current.has_banana)
                    possible_actions.append((new_state, f"Push box from {current.box_pos} to {pos}"))

        # 3. Climb Up: Monkey climbs onto the box (requires monkey to be at the box position)
        if not current.on_box and current.monkey_pos == current.box_pos:
            new_state = MonkeyBananaState(current.monkey_pos, current.box_pos, True, current.has_banana)
            possible_actions.append((new_state, "Climb up onto the box"))

        # 4. Climb Down: Monkey climbs down from the box
        if current.on_box:
            new_state = MonkeyBananaState(current.monkey_pos, current.box_pos, False, current.has_banana)
            possible_actions.append((new_state, "Climb down from the box"))

        # 5. Grab Banana: Monkey grabs the banana (requires monkey to be on the box and the box to be in the 'middle')
        if current.on_box and current.box_pos == 'middle' and not current.has_banana:
            new_state = MonkeyBananaState(current.monkey_pos, current.box_pos, True, True)
            possible_actions.append((new_state, "Grab the banana"))

        # Explore all valid next states
        for next_state, action in possible_actions:
            if next_state not in visited:
                visited.add(next_state)
                queue.append((next_state, path + [action]))

    return None

# Execution:
if __name__ == "__main__":
    print("--- Monkey and Banana Problem Solver ---")
    solution_steps = solve_monkey_banana()
    
    if solution_steps:
        print(f"Solution found in {len(solution_steps)} steps:\n")
        for step, action in enumerate(solution_steps, 1):
            print(f"Step {step}: {action}")
        print("\nGoal Achieved: The monkey has successfully obtained the banana!")
    else:
        print("No solution found.")