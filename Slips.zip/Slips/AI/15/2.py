# Q2. Write a Program to Implement Alpha-Beta Pruning using Python. [20 Marks]

def alphabeta(depth, node_index, maximizing_player, values, alpha, beta, max_depth):
    """
    Implementation of the Alpha-Beta Pruning algorithm for a binary game tree.
    """
    # Base case: target depth reached (leaf node)
    if depth == max_depth:
        return values[node_index]
    
    if maximizing_player:
        best = float('-inf')
        # Recur for left and right children
        for i in range(2):
            val = alphabeta(depth + 1, node_index * 2 + i, False, values, alpha, beta, max_depth)
            best = max(best, val)
            alpha = max(alpha, best)
            
            # Beta cutoff (pruning)
            if beta <= alpha:
                break
        return best
    else:
        best = float('inf')
        # Recur for left and right children
        for i in range(2):
            val = alphabeta(depth + 1, node_index * 2 + i, True, values, alpha, beta, max_depth)
            best = min(best, val)
            beta = min(beta, best)
            
            # Alpha cutoff (pruning)
            if beta <= alpha:
                break
        return best

# Example usage:
if __name__ == "__main__":
    # Leaf node values for a game tree of depth 3 (2^3 = 8 leaf nodes)
    leaf_values = [3, 5, 6, 9, 1, 2, 0, -1]
    tree_depth = 3
    
    print("--- Alpha-Beta Pruning Algorithm Execution ---")
    optimal_utility = alphabeta(0, 0, True, leaf_values, float('-inf'), float('inf'), tree_depth)
    print(f"Leaf Node Scores: {leaf_values}")
    print(f"Optimal Value (Alpha-Beta Result): {optimal_utility}")