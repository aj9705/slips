# Q2. Develop a Restaurant Reservation Assistant (A simple chatbot that helps customers make reservations or ask about the menu.)

def show_menu():
    """Displays the restaurant menu."""
    print("\n--- Restaurant Menu ---")
    print("1. Starters: Garlic Bread ($5), Paneer Tikka ($8), Soup ($4)")
    print("2. Main Course: Margherita Pizza ($12), Pasta Alfredo ($14), Veg Biryani ($10)")
    print("3. Desserts: Chocolate Brownie ($6), Tiramisu ($7)")
    print("4. Beverages: Cold Coffee ($4), Lemonade ($3), Fresh Juice ($5)\n")

def make_reservation():
    """Handles table reservation details from the user."""
    print("\n--- Table Reservation ---")
    name = input("Enter your full name: ")
    date = input("Enter reservation date (DD-MM-YYYY): ")
    time = input("Enter reservation time (e.g., 07:30 PM): ")
    
    try:
        guests = int(input("Enter number of guests: "))
        if guests <= 0:
            print("Number of guests must be greater than zero.")
            return
    except ValueError:
        print("Invalid input for guests. Please enter a valid number.")
        return
        
    print(f"\nSuccess! Table reserved for {guests} guest(s) under the name '{name}' on {date} at {time}.")
    print("We look forward to serving you!\n")

def restaurant_chatbot():
    """Main interactive chatbot loop."""
    print("=== Welcome to Gourmet Delight Restaurant Assistant ===")
    print("Hello! I am your virtual assistant. How can I help you today?")
    
    while True:
        print("\nPlease choose an option:")
        print("1. View Menu")
        print("2. Make a Table Reservation")
        print("3. Exit")
        
        choice = input("Enter your choice (1/2/3): ").strip()
        
        if choice == '1':
            show_menu()
        elif choice == '2':
            make_reservation()
        elif choice == '3':
            print("\nThank you for visiting Gourmet Delight! Have a wonderful day!")
            break
        else:
            print("\nInvalid choice! Please select 1, 2, or 3.")

if __name__ == "__main__":
    restaurant_chatbot()