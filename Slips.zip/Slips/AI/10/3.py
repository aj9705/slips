# Q2. Write a Python program to implement Mini-Max Algorithm. [20 Marks]

def minimax(depth, node_index, maximizing_player, values, max_depth):
    """
    Implementation of the Mini-Max algorithm for a binary game tree.
    """
    # Base case: target depth reached (leaf node)
    if depth == max_depth:
        return values[node_index]
    
    if maximizing_player:
        best = float('-inf')
        # Recur for left and right children
        for i in range(2):
            val = minimax(depth + 1, node_index * 2 + i, False, values, max_depth)
            best = max(best, val)
        return best
    else:
        best = float('inf')
        # Recur for left and right children
        for i in range(2):
            val = minimax(depth + 1, node_index * 2 + i, True, values, max_depth)
            best = min(best, val)
        return best

# Example usage:
if __name__ == "__main__":
    # Leaf node values for a game tree of depth 3 (2^3 = 8 leaf nodes)
    leaf_values = [3, 5, 2, 9, 12, 5, 23, 3]
    tree_depth = 3
    
    print("--- Mini-Max Algorithm Execution ---")
    optimal_utility = minimax(0, 0, True, leaf_values, tree_depth)
    print(f"Leaf Node Scores: {leaf_values}")
    print(f"Optimal Value (Mini-Max Result): {optimal_utility}")