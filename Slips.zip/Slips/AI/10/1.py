# Q1. Given a number of cities and the cost of connecting them, find the minimum cost to connect all cities. Use Prim's algorithm to solve. [10 Marks]

import heapq

def prims_algorithm(graph, start_node=1):
    """
    Implements Prim's algorithm to find the Minimum Spanning Tree (MST) 
    and total minimum cost to connect all nodes.
    """
    visited = set()
    min_heap = [(0, start_node, -1)]  # (weight, current_node, parent_node)
    mst_edges = []
    total_cost = 0
    
    while min_heap and len(visited) < len(graph):
        weight, u, parent = heapq.heappop(min_heap)
        
        if u in visited:
            continue
            
        visited.add(u)
        
        # If it's not the start node, record the edge in the MST
        if parent != -1:
            mst_edges.append((parent, u, weight))
            total_cost += weight
            
        # Explore adjacent nodes
        for v, cost in graph.get(u, []):
            if v not in visited:
                heapq.heappush(min_heap, (cost, v, u))
                
    return total_cost, mst_edges

# Graph representation based on the cities and costs shown in the image:
# Nodes represent cities (1 to 7) and weights represent connection costs.
graph = {
    1: [(2, 28), (6, 10)],
    2: [(1, 28), (7, 14), (3, 16)],
    3: [(2, 16), (4, 12)],
    4: [(3, 12), (5, 22), (7, 18)],
    5: [(6, 25), (7, 24), (4, 22)],
    6: [(1, 10), (5, 25)],
    7: [(2, 14), (5, 24), (4, 18)]
}

# Example execution:
if __name__ == "__main__":
    start_city = 1
    print(f"--- Prim's Algorithm (Starting from City {start_city}) ---")
    min_cost, mst = prims_algorithm(graph, start_city)
    
    print("\nEdges in the Minimum Spanning Tree (MST):")
    for u, v, weight in mst:
        print(f"City {u} -- City {v} : Cost = {weight}")
        
    print(f"\nTotal Minimum Cost to Connect All Cities: {min_cost}")