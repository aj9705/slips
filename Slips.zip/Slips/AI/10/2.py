# Q2. Write a program to implement A* algorithm. [20 Marks]

import heapq

def a_star_search(start, goal, graph, heuristics):
    """
    A* Search Algorithm implementation using f(n) = g(n) + h(n).
    """
    # Priority queue stores tuples of (f_score, current_node, g_score, path_history)
    pq = [(heuristics[start], start, 0, [start])]
    g_scores = {start: 0}
    visited = set()
    
    while pq:
        f, current, g, path = heapq.heappop(pq)
        
        # Check if the goal node is reached
        if current == goal:
            return path, g
            
        if current in visited:
            continue
            
        visited.add(current)
        
        # Explore neighbors
        for neighbor, weight in graph.get(current, {}).items():
            tentative_g = g + weight
            
            # If a shorter path to the neighbor is found
            if neighbor not in g_scores or tentative_g < g_scores[neighbor]:
                g_scores[neighbor] = tentative_g
                f_score = tentative_g + heuristics.get(neighbor, 0)
                heapq.heappush(pq, (f_score, neighbor, tentative_g, path + [neighbor]))
                
    return None, float('inf')

# Example usage:
if __name__ == "__main__":
    # Weighted graph represented as an adjacency list: {node: {neighbor: weight}}
    graph = {
        'S': {'A': 1, 'G': 10},
        'A': {'B': 2, 'C': 1},
        'B': {'D': 5},
        'C': {'D': 3, 'G': 4},
        'D': {'G': 2},
        'G': {}
    }
    
    # Heuristic values estimating the cost from each node to the goal node 'G'
    heuristics = {
        'S': 5,
        'A': 3,
        'B': 4,
        'C': 2,
        'D': 1,
        'G': 0
    }
    
    start_node = 'S'
    goal_node = 'G'
    
    print(f"--- A* Search Algorithm from '{start_node}' to '{goal_node}' ---")
    path, total_cost = a_star_search(start_node, goal_node, graph, heuristics)
    
    if path:
        print(f"Optimal Path Found: {' -> '.join(path)}")
        print(f"Total Path Cost: {total_cost}")
    else:
        print("No path found to the goal.")