# Q1. Write a Python program to implement Depth First Search algorithm. Refer the following graph as an Input for the program. [Initial node=1, Goal node=8]. [10 Marks]

# Adjacency list representation of the graph from the image
graph = {
    1: [2, 3],
    2: [4, 5],
    3: [6, 7],
    4: [8],
    5: [8],
    6: [8],
    7: [8],
    8: []
}

def dfs(current_node, goal_node, visited=None, path=None):
    if visited is None:
        visited = set()
    if path is None:
        path = []
        
    visited.add(current_node)
    path.append(current_node)
    
    if current_node == goal_node:
        return path
        
    for neighbor in graph.get(current_node, []):
        if neighbor not in visited:
            result = dfs(neighbor, goal_node, visited, path)
            if result:
                return result
                
    path.pop()  # Backtrack if the goal is not found in this branch
    return None

# Execution
initial_node = 1
goal_node = 8
path = dfs(initial_node, goal_node)

print(f"DFS Path from {initial_node} to {goal_node}: {' -> '.join(map(str, path))}")