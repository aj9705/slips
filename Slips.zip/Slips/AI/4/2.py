# Q2. Write a program to implement AO* algorithm. [20 Marks]

# File Name: ao_star.py

def compute_minimum_cost(node, weight_matrix, heuristics):
    """Computes the minimum cost of a node and its children in an AND/OR graph."""
    
    # If the node has no outgoing branches (terminal node)
    if node not in weight_matrix:
        return heuristics.get(node, 0), {node: []}
        
    min_cost = float('inf')
    best_branch = None
    
    # weight_matrix[node] contains OR alternatives, 
    # and each alternative is a list of AND nodes with their respective edge weights: (child, weight)
    for branch in weight_matrix[node]:
        branch_cost = 0
        current_path = {}
        for child, cost in branch:
            child_cost, child_path = compute_minimum_cost(child, weight_matrix, heuristics)
            branch_cost += cost + child_cost
            current_path[child] = child_path
            
        if branch_cost < min_cost:
            min_cost = branch_cost
            best_branch = current_path
            
    heuristics[node] = min_cost
    return min_cost, {node: best_branch}

# Example usage with an AND/OR graph structure:
if __name__ == "__main__":
    # Graph representation:
    # 'A' has two OR choices: 
    # Choice 1: B and C (AND nodes) with edge weights 1 and 1
    # Choice 2: D (OR node) with edge weight 2
    weight_matrix = {
        'A': [
            [('B', 1), ('C', 1)], 
            [('D', 2)]
        ],
        'B': [
            [('E', 3)], 
            [('F', 4)]
        ],
        'C': [
            [('G', 2)]
        ]
    }

    # Initial heuristic values for the nodes
    heuristics = {
        'A': 10, 
        'B': 5, 
        'C': 2, 
        'D': 7, 
        'E': 0, 
        'F': 0, 
        'G': 0
    }

    print("--- Running AO* Algorithm ---")
    min_cost, solution_tree = compute_minimum_cost('A', weight_matrix, heuristics)
    
    print(f"\nMinimum Cost for Start Node 'A': {min_cost}")
    print(f"Optimal Solution Tree: {solution_tree}")