# Q2. Write a Program to Implement Water-Jug problem using Python. [20 Marks]

from collections import deque

def water_jug_problem(capacity_a, capacity_b, target):
    # Queue stores states as (jug_a, jug_b, path_history)
    queue = deque([(0, 0, [])])
    visited = set()
    visited.add((0, 0))
    
    while queue:
        a, b, path = queue.popleft()
        
        # Record current state in path
        current_path = path + [(a, b)]
        
        # Check if target is reached in either jug
        if a == target or b == target:
            return current_path
            
        # Possible transitions (actions)
        transitions = [
            (capacity_a, b),             # Fill Jug A completely
            (a, capacity_b),             # Fill Jug B completely
            (0, b),                      # Empty Jug A
            (a, 0),                      # Empty Jug B
            # Pour Jug A into Jug B
            (a - min(a, capacity_b - b), b + min(a, capacity_b - b)),
            # Pour Jug B into Jug A
            (a + min(b, capacity_a - a), b - min(b, capacity_a - a))
        ]
        
        for next_state in transitions:
            if next_state not in visited:
                visited.add(next_state)
                queue.append((next_state[0], next_state[1], current_path))
                
    return None

# Example usage:
if __name__ == "__main__":
    jug1_capacity = 4
    jug2_capacity = 3
    target_amount = 2
    
    print(f"Solving Water-Jug Problem: Jug 1 ({jug1_capacity}L), Jug 2 ({jug2_capacity}L), Target ({target_amount}L)")
    solution = water_jug_problem(jug1_capacity, jug2_capacity, target_amount)
    
    if solution:
        print(f"Solution found in {len(solution) - 1} steps:\n")
        for step, (a, b) in enumerate(solution):
            print(f"Step {step}: Jug 1 = {a}L, Jug 2 = {b}L")
    else:
        print("No solution possible for the given target.")