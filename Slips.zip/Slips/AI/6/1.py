# Given an array of integers, write a Python Program to sort the array in descending order using Selection Sort.

def selection_sort_descending(arr):
    n = len(arr)
    for i in range(n):
        # Assume the first element of the unsorted portion is the maximum
        max_idx = i
        for j in range(i + 1, n):
            if arr[j] > arr[max_idx]:
                max_idx = j
        
        # Swap the found maximum element with the first element of the unsorted portion
        arr[i], arr[max_idx] = arr[max_idx], arr[i]
        
    return arr

# Example usage:
if __name__ == "__main__":
    sample_array = [64, 25, 12, 22, 11]
    print(f"Original Array: {sample_array}")
    sorted_array = selection_sort_descending(sample_array)
    print(f"Sorted Array in Descending Order: {sorted_array}")