# Develop an elementary Chatbot for any suitable customer interaction application

def customer_support_chatbot():
    print("=== Welcome to ShopEase Customer Support ===")
    print("Hello! I am your virtual assistant. How can I help you today?")
    print("Type 'bye', 'exit', or 'quit' to end the chat.\n")
    
    # Predefined knowledge base of keywords and responses
    knowledge_base = {
        "shipping": "We offer standard shipping (3-5 business days) and express shipping (1-2 business days). Shipping is free on orders over $50!",
        "order": "You can track your order status by logging into your account and visiting the 'My Orders' section.",
        "return": "We have a 30-day hassle-free return policy. Items must be unused and in their original packaging.",
        "refund": "Refunds are processed back to your original payment method within 5-7 business days after we receive your returned item.",
        "hours": "Our customer support team is available Monday through Friday, 9:00 AM to 6:00 PM EST.",
        "contact": "You can reach our human support team via email at support@shopease.com or call us at 1-800-555-0199.",
        "hello": "Hi there! How can I assist you with your shopping experience today?",
        "hi": "Hello! Feel free to ask me about shipping, orders, returns, or store hours."
    }
    
    while True:
        # Get user input and convert to lowercase for easier matching
        user_input = input("You: ").strip().lower()
        
        # Check for exit condition
        if user_input in ["bye", "exit", "quit"]:
            print("Chatbot: Thank you for shopping with ShopEase! Have a wonderful day! Goodbye!")
            break
            
        if not user_input:
            print("Chatbot: Please type something so I can help you.")
            continue
            
        # Search for matching keywords in the knowledge base
        response_found = False
        for keyword, response in knowledge_base.items():
            if keyword in user_input:
                print(f"Chatbot: {response}")
                response_found = True
                break
                
        # Fallback response if no keywords match
        if not response_found:
            print("Chatbot: I'm sorry, I didn't quite catch that. You can ask me about 'shipping', 'order status', 'returns', 'refunds', or 'store hours'.")
        
        print("-" * 50)

# Run the chatbot program:
if __name__ == "__main__":
    customer_support_chatbot()