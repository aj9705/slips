# Q2. Write a python program to implement A star Algorithm. [20 Marks]

import heapq

def a_star_algorithm(start_node, goal_node, graph, heuristics):
    """
    Implements the A* Search algorithm using the evaluation function f(n) = g(n) + h(n).
    """
    # Priority queue stores tuples of (f_score, current_node, g_score, path)
    pq = [(heuristics[start_node], start_node, 0, [start_node])]
    g_scores = {start_node: 0}
    visited = set()
    
    while pq:
        f, current, g, path = heapq.heappop(pq)
        
        # Check if we have reached the goal
        if current == goal_node:
            return path, g
            
        if current in visited:
            continue
            
        visited.add(current)
        
        # Explore neighbors
        for neighbor, weight in graph.get(current, {}).items():
            tentative_g = g + weight
            
            # If a shorter path to the neighbor is found
            if neighbor not in g_scores or tentative_g < g_scores[neighbor]:
                g_scores[neighbor] = tentative_g
                f_score = tentative_g + heuristics.get(neighbor, 0)
                heapq.heappush(pq, (f_score, neighbor, tentative_g, path + [neighbor]))
                
    return None, float('inf')

# Example usage:
if __name__ == "__main__":
    # Graph represented as an adjacency list with edge weights: {node: {neighbor: cost}}
    graph = {
        'S': {'A': 1, 'G': 10},
        'A': {'B': 2, 'C': 1},
        'B': {'D': 5},
        'C': {'D': 3, 'G': 4},
        'D': {'G': 2},
        'G': {}
    }
    
    # Heuristic values from each node to the goal node 'G'
    heuristics = {
        'S': 5,
        'A': 3,
        'B': 4,
        'C': 2,
        'D': 1,
        'G': 0
    }
    
    start = 'S'
    goal = 'G'
    
    print(f"--- A* Search Algorithm (Start: '{start}', Goal: '{goal}') ---")
    path, total_cost = a_star_algorithm(start, goal, graph, heuristics)
    
    if path:
        print(f"\nOptimal Path Found: {' -> '.join(path)}")
        print(f"Total Path Cost: {total_cost}")
    else:
        print("\nNo path found to the goal.")