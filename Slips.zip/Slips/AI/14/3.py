# Q2. Write a program to solve Missionaries and Cannibals problem. [20 Marks]

from collections import deque

def is_valid(m_left, c_left):
    """
    Checks if a given state is valid according to the problem rules.
    """
    m_right = 3 - m_left
    c_right = 3 - c_left
    
    # Check if counts are out of bounds (0 to 3)
    if m_left < 0 or m_left > 3 or c_left < 0 or c_left > 3:
        return False
        
    # Cannibals cannot outnumber missionaries on the left bank
    if m_left > 0 and c_left > m_left:
        return False
        
    # Cannibals cannot outnumber missionaries on the right bank
    if m_right > 0 and c_right > m_right:
        return False
        
    return True

def solve_missionaries_and_cannibals():
    """
    Finds the sequence of states to move all 3 missionaries and 3 cannibals 
    from the left bank to the right bank using BFS.
    """
    # State representation: (missionaries_left, cannibals_left, boat_position)
    # boat_position: 1 for Left bank, 0 for Right bank
    initial_state = (3, 3, 1)
    goal_state = (0, 0, 0)
    
    queue = deque([(initial_state, [])])
    visited = {initial_state}
    
    # Possible boat moves (m, c): boat capacity is at most 2, at least 1 person
    possible_moves = [
        (1, 0), (2, 0), (0, 1), (0, 2), (1, 1)
    ]
    
    while queue:
        current_state, path = queue.popleft()
        m_l, c_l, boat = current_state
        
        if current_state == goal_state:
            return path + [current_state]
            
        # If boat is on the left (1), people move from left to right (-1)
        # If boat is on the right (0), people move from right to left (+1)
        multiplier = -1 if boat == 1 else 1
        
        for dm, dc in possible_moves:
            new_m_l = m_l + multiplier * dm
            new_c_l = c_l + multiplier * dc
            new_boat = 1 - boat
            
            if is_valid(new_m_l, new_c_l):
                next_state = (new_m_l, new_c_l, new_boat)
                if next_state not in visited:
                    visited.add(next_state)
                    queue.append((next_state, path + [current_state]))
                    
    return None

# Execution:
if __name__ == "__main__":
    print("--- Missionaries and Cannibals Problem Solver ---")
    solution_path = solve_missionaries_and_cannibals()
    
    if solution_path:
        print(f"Solution found in {len(solution_path) - 1} steps:\n")
        for step, state in enumerate(solution_path):
            m_l, c_l, boat = state
            m_r = 3 - m_l
            c_r = 3 - c_l
            boat_location = "Left Bank" if boat == 1 else "Right Bank"
            print(f"Step {step:2d} -> Left Bank: [M: {m_l}, C: {c_l}] | Right Bank: [M: {m_r}, C: {c_r}] | Boat is at: {boat_location}")
        print("\nGoal Achieved: All missionaries and cannibals successfully crossed the river!")
    else:
        print("No solution found.")