# Q2. Write a Python program to implement Depth First Search algorithm. Refer the following graph as an Input for the program. [Initial node=2,Goal node=7] [20 Marks]

def dfs_path(graph, current, goal, visited=None, path=None):
    """
    Recursive Depth First Search implementation to find a path from current node to goal node.
    """
    if visited is None:
        visited = set()
    if path is None:
        path = []

    visited.add(current)
    path = path + [current]

    if current == goal:
        return path

    for neighbor in graph.get(current, []):
        if neighbor not in visited:
            result_path = dfs_path(graph, neighbor, goal, visited, path)
            if result_path:
                return result_path

    return None

# Graph adjacency list representation based on the input graph structure in the image
graph = {
    1: [2, 3, 4],
    2: [1, 4, 5],
    3: [1, 4],
    4: [1, 2, 3, 7],
    5: [2, 6, 7],
    6: [5, 7],
    7: [4, 5, 6]
}

if __name__ == "__main__":
    initial_node = 2
    goal_node = 7
    
    print(f"--- Depth First Search (Initial Node: {initial_node}, Goal Node: {goal_node}) ---")
    path = dfs_path(graph, initial_node, goal_node)
    
    if path:
        print(f"\nGoal '{goal_node}' successfully reached!")
        print(f"Traversal Path: {' -> '.join(map(str, path))}")
        print(f"Total steps: {len(path) - 1}")
    else:
        print(f"\nGoal '{goal_node}' could not be reached from initial node '{initial_node}'.")
