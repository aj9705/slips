# Use an undirected graph and develop a recursive algorithm for searching all the vertices of a graph.

def recursive_dfs_search(graph, vertex, visited=None, traversal_order=None):
    """
    Recursive algorithm to search and visit all vertices of an undirected graph.
    """
    if visited is None:
        visited = set()
    if traversal_order is None:
        traversal_order = []
        
    # Mark the current vertex as visited and add it to the traversal order
    visited.add(vertex)
    traversal_order.append(vertex)
    
    # Recursively traverse all adjacent vertices that haven't been visited yet
    for neighbor in graph.get(vertex, []):
        if neighbor not in visited:
            recursive_dfs_search(graph, neighbor, visited, traversal_order)
            
    return traversal_order

# Example usage:
if __name__ == "__main__":
    # Undirected graph represented as an adjacency list (bidirectional edges)
    undirected_graph = {
        'A': ['B', 'C'],
        'B': ['A', 'D', 'E'],
        'C': ['A', 'F'],
        'D': ['B'],
        'E': ['B', 'F'],
        'F': ['C', 'E']
    }
    
    start_node = 'A'
    print(f"--- Recursive Vertex Search on Undirected Graph (Start: '{start_node}') ---")
    
    visited_vertices = recursive_dfs_search(undirected_graph, start_node)
    
    print(f"\nTraversal Order: {' -> '.join(visited_vertices)}")
    print(f"Total Vertices Visited: {len(visited_vertices)}")
