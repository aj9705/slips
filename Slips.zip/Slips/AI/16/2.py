# Q2. Write a Program to Implement Tic-Tac-Toe game using Python. [20 Marks]

def print_board(board):
    """Displays the current state of the Tic-Tac-Toe board."""
    print("\n")
    for i in range(0, 9, 3):
        print(f" {board[i]} | {board[i+1]} | {board[i+2]} ")
        if i < 6:
            print("-----------")
    print("\n")

def check_winner(board):
    """Checks if there is a winner or a tie."""
    winning_combinations = [
        [0, 1, 2], [3, 4, 5], [6, 7, 8],  # Rows
        [0, 3, 6], [1, 4, 7], [2, 5, 8],  # Columns
        [0, 4, 8], [2, 4, 6]             # Diagonals
    ]
    for combo in winning_combinations:
        if board[combo[0]] == board[combo[1]] == board[combo[2]] and board[combo[0]] != " ":
            return board[combo[0]]
    if " " not in board:
        return "Tie"
    return None

def play_tic_tac_toe():
    """Main game loop for two players (X and O)."""
    board = [" "] * 9
    current_player = "X"
    
    print("=== Tic-Tac-Toe Game ===")
    print("Positions are numbered from 0 to 8 as shown below:")
    print(" 0 | 1 | 2 ")
    print("-----------")
    print(" 3 | 4 | 5 ")
    print("-----------")
    print(" 6 | 7 | 8 ")
    
    while True:
        print_board(board)
        try:
            move = int(input(f"Player {current_player}, enter your move (0-8): "))
            if move < 0 or move > 8 or board[move] != " ":
                print("Invalid move! Position already taken or out of range. Try again.")
                continue
        except ValueError:
            print("Please enter a valid integer between 0 and 8.")
            continue
            
        board[move] = current_player
        
        winner = check_winner(board)
        if winner:
            print_board(board)
            if winner == "Tie":
                print("It's a Tie!")
            else:
                print(f"Congratulations! Player {winner} wins!")
            break
            
        # Switch player
        current_player = "O" if current_player == "X" else "X"

if __name__ == "__main__":
    play_tic_tac_toe()