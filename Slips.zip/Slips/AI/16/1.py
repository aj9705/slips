# Q1. Write a Python program to implement Depth First Search algorithm. Refer the following graph as an Input for the program. [Initial node=1,Goal node=8]. [10 Marks]

def dfs_path(graph, current, goal, visited=None, path=None):
    """
    Recursive Depth First Search implementation to find a path from current node to goal node.
    """
    if visited is None:
        visited = set()
    if path is None:
        path = []

    visited.add(current)
    path = path + [current]

    if current == goal:
        return path

    for neighbor in graph.get(current, []):
        if neighbor not in visited:
            result_path = dfs_path(graph, neighbor, goal, visited, path)
            if result_path:
                return result_path

    return None

# Graph adjacency list representation based on the input graph structure in the image[cite: 6]
graph = {
    1: [2, 3],
    2: [4, 5],
    3: [6, 7],
    4: [8],
    5: [8],
    6: [8],
    7: [8],
    8: []
}

if __name__ == "__main__":
    initial_node = 1
    goal_node = 8
    
    print(f"--- Depth First Search (Initial Node: {initial_node}, Goal Node: {goal_node}) ---")
    path = dfs_path(graph, initial_node, goal_node)
    
    if path:
        print(f"\nGoal '{goal_node}' successfully reached!")
        print(f"Traversal Path: {' -> '.join(map(str, path))}")
        print(f"Total steps: {len(path) - 1}")
    else:
        print(f"\nGoal '{goal_node}' could not be reached from initial node '{initial_node}'.")