# Q2. Given a number of cities and the cost of connecting them, find the minimum cost to connect all cities. Use Kruskal's algorithm to solve. [20 Marks]

class DisjointSet:
    def __init__(self, vertices):
        self.parent = {v: v for v in vertices}
        self.rank = {v: 0 for v in vertices}

    def find(self, item):
        if self.parent[item] != item:
            self.parent[item] = self.find(self.parent[item])
        return self.parent[item]

    def union(self, set1, set2):
        root1 = self.find(set1)
        root2 = self.find(set2)

        if root1 != root2:
            if self.rank[root1] < self.rank[root2]:
                self.parent[root1] = root2
            elif self.rank[root1] > self.rank[root2]:
                self.parent[root2] = root1
            else:
                self.parent[root2] = root1
                self.rank[root1] += 1
            return True
        return False

def kruskals_algorithm(vertices, edges):
    """
    Implements Kruskal's algorithm to find the Minimum Spanning Tree (MST) 
    and total minimum cost to connect all cities.
    """
    # Sort edges based on weight
    sorted_edges = sorted(edges, key=lambda x: x[2])
    ds = DisjointSet(vertices)
    
    mst_edges = []
    total_cost = 0
    
    for u, v, weight in sorted_edges:
        if ds.union(u, v):
            mst_edges.append((u, v, weight))
            total_cost += weight
            
    return total_cost, mst_edges

# Graph representation based on the cities and connection costs shown in the image[cite: 6]:
vertices = ['A', 'B', 'C', 'D', 'E', 'F', 'G']
edges = [
    ('A', 'B', 6),
    ('A', 'G', 15),
    ('B', 'D', 5),
    ('B', 'C', 11),
    ('C', 'D', 17),
    ('C', 'F', 9),
    ('C', 'G', 25),
    ('D', 'E', 22),
    ('E', 'F', 10),
    ('F', 'G', 12)
]

if __name__ == "__main__":
    print("--- Kruskal's Algorithm for City Connectivity ---")
    min_cost, mst = kruskals_algorithm(vertices, edges)
    
    print("\nEdges in the Minimum Spanning Tree (MST):")
    for u, v, weight in mst:
        print(f"City {u} -- City {v} : Cost = {weight}")
        
    print(f"\nTotal Minimum Cost to Connect All Cities: {min_cost}")