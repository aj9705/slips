# Q2. Write a Program to Implement Depth First Search using Python. [20 Marks]

def dfs(graph, start_node, visited=None, traversal_order=None):
    """
    Implements Depth First Search (DFS) traversal on a directed graph.
    """
    if visited is None:
        visited = set()
    if traversal_order is None:
        traversal_order = []
        
    visited.add(start_node)
    traversal_order.append(start_node)
    
    # Explore all adjacent neighbors recursively
    for neighbor in graph.get(start_node, []):
        if neighbor not in visited:
            dfs(graph, neighbor, visited, traversal_order)
            
    return traversal_order

# Graph adjacency list representation based on the directed graph structure shown in the image:
graph = {
    1: [2, 3],
    2: [4],
    3: [2],
    4: [5, 6],
    5: [3, 7],
    6: [],
    7: [6]
}

if __name__ == "__main__":
    start_node = 1
    print(f"--- Depth First Search (Starting from Node {start_node}) ---")
    
    traversal_result = dfs(graph, start_node)
    
    print(f"\nTraversal Order: {' -> '.join(map(str, traversal_result))}")
    print(f"Total Vertices Visited: {len(traversal_result)}")