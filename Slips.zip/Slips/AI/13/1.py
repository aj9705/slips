# Q1. Write a Program to Implement Breadth First Search using Python. [10 Marks]

from collections import deque

def breadth_first_search(graph, start_node):
    """
    Implements Breadth First Search (BFS) traversal for a graph.
    """
    visited = set()
    queue = deque([start_node])
    traversal_order = []
    
    visited.add(start_node)
    
    while queue:
        current_node = queue.popleft()
        traversal_order.append(current_node)
        
        # Explore neighbors
        for neighbor in graph.get(current_node, []):
            if neighbor not in visited:
                visited.add(neighbor)
                queue.append(neighbor)
                
    return traversal_order

# Example usage:
if __name__ == "__main__":
    # Graph represented as an adjacency list
    graph = {
        'A': ['B', 'C'],
        'B': ['A', 'D', 'E'],
        'C': ['A', 'F'],
        'D': ['B'],
        'E': ['B', 'F'],
        'F': ['C', 'E']
    }
    
    start = 'A'
    print(f"--- Breadth First Search starting from node '{start}' ---")
    result = breadth_first_search(graph, start)
    print(" -> ".join(result))