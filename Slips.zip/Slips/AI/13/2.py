# Q2. Implement AO star Algorithm. [20 Marks]

class Graph:
    def __init__(self, start_node, heuristics, graph_node):
        self.start_node = start_node
        self.heuristics = heuristics
        self.graph_node = graph_node
        self.solved_nodes = {}

    def get_heuristic(self, node):
        return self.heuristics.get(node, 0)

    def set_heuristic(self, node, value):
        self.heuristics[node] = value

    def compute_minimum_cost_child(self, node):
        """
        Computes the minimum cost among the children branches of a node.
        Handles both OR nodes and AND nodes.
        """
        min_cost = float('inf')
        best_child_group = []
        
        # graph_node[node] contains a list of branches. 
        # Each branch is a list of child nodes (AND combination if multiple nodes).
        branches = self.graph_node.get(node, [])
        
        for branch in branches:
            cost = 0
            branch_cost_details = {}
            for child in branch:
                # Cost = arc cost (assumed 1 per edge for simplicity) + heuristic of child
                edge_cost = 1
                child_cost = edge_cost + self.get_heuristic(child)
                branch_cost_details[child] = child_cost
                cost += child_cost
            
            if cost < min_cost:
                min_cost = cost
                best_child_group = branch
                
        return min_cost, best_child_group

    fn = compute_minimum_cost_child # alias

    def ao_star(self, node, visited=None):
        """
        Recursive AO* search algorithm.
        """
        if visited is None:
            visited = set()
            
        print(f"Traversing node: {node}")
        
        # If node has no children (leaf node or terminal), return its heuristic
        if node not in self.graph_node or len(self.graph_node[node]) == 0:
            return self.get_heuristic(node)
            
        min_cost, best_branch = self.compute_minimum_cost_child(node)
        
        # Update heuristic of current node with the minimum cost found
        self.set_heuristic(node, min_cost)
        
        # Mark solved if cost is 0 or all children are terminal/solved
        if min_cost == 0:
            self.solved_nodes[node] = True
            
        # Recursively visit children in the best branch
        for child in best_branch:
            if child not in visited:
                visited.add(child)
                self.ao_star(child, visited)
                
        return min_cost

# Example usage:
if __name__ == "__main__":
    # Heuristic values for each node
    heuristics = {
        'A': 10,
        'B': 6,
        'C': 5,
        'D': 7,
        'E': 3,
        'F': 1,
        'G': 0,
        'H': 0
    }
    
    # Graph structure: 
    # Key = Parent Node
    # Value = List of branches (each branch can be a single node for OR, or multiple nodes for AND)
    graph_structure = {
        'A': [['B', 'C'], ['D']],       # Node A can go to (B AND C) OR (D)
        'B': [['E', 'F']],             # Node B goes to (E AND F)
        'C': [['G']],                  # Node C goes to (G)
        'D': [['H']]                   # Node D goes to (H)
    }
    
    print("--- AO* Algorithm Execution ---")
    ao_graph = Graph(start_node='A', heuristics=heuristics, graph_node=graph_structure)
    
    initial_cost = ao_graph.ao_star('A')
    
    print(f"\nFinal Optimal Cost for Root Node 'A': {initial_cost}")
    print(f"Updated Heuristics (Cost Table): {ao_graph.heuristics}")