# Q2. Develop Healthcare Appointment Bot (simple chatbot that helps patients book appointments or find clinic information.)

def healthcare_chatbot():
    print("=== Welcome to MediCare Clinic Assistant ===")
    print("Hello! I am your virtual healthcare assistant. I can help you book appointments or provide clinic information.")
    print("Type 'exit' or 'quit' at any time to end the conversation.\n")
    
    # Clinic information database
    clinic_info = {
        "address": "123 Health Avenue, Wellness City, CA 90210",
        "timings": "Monday to Saturday: 8:00 AM - 8:00 PM, Sunday: Closed",
        "contact": "Phone: (555) 123-4567 | Email: info@medicareclinic.com",
        "departments": ["General Medicine", "Cardiology", "Pediatrics", "Dermatology"]
    }
    
    appointments = []

    while True:
        print("\nPlease choose an option:")
        print("1. Book an Appointment")
        print("2. Find Clinic Information")
        print("3. Exit")
        
        choice = input("You (Enter 1, 2, or 3): ").strip().lower()
        
        if choice in ["3", "exit", "quit"]:
            print("\nMediCare Bot: Thank you for reaching out. Take care and stay healthy! Goodbye!")
            break
            
        elif choice == "1" or "book" in choice:
            print("\n--- Appointment Booking ---")
            name = input("Enter patient's full name: ").strip()
            if name.lower() in ["exit", "quit"]:
                break
                
            print("Available Departments:")
            for i, dept in enumerate(clinic_info["departments"], 1):
                print(f"{i}. {dept}")
            
            dept_choice = input("Select department number or type name: ").strip()
            selected_dept = "General Medicine"
            if dept_choice.isdigit() and 1 <= int(dept_choice) <= len(clinic_info["departments"]):
                selected_dept = clinic_info["departments"][int(dept_choice) - 1]
            elif dept_choice:
                selected_dept = dept_choice
                
            date = input("Enter preferred appointment date (YYYY-MM-DD): ").strip()
            time_slot = input("Enter preferred time slot (e.g., 10:00 AM - 11:00 AM): ").strip()
            
            # Save appointment record
            appointment_record = {
                "name": name,
                "department": selected_dept,
                "date": date,
                "time": time_slot
            }
            appointments.append(appointment_record)
            
            print(f"\nSuccess! Appointment booked for {name} in {selected_dept} on {date} at {time_slot}.")
            print("We look forward to seeing you.")
            
        elif choice == "2" or "info" in choice or "clinic" in choice:
            print("\n--- Clinic Information ---")
            print(f"Address: {clinic_info['address']}")
            print(f"Timings: {clinic_info['timings']}")
            print(f"Contact: {clinic_info['contact']}")
            print("Departments Available:")
            for dept in clinic_info["departments"]:
                print(f" - {dept}")
        else:
            print("\nMediCare Bot: I didn't understand that option. Please select 1, 2, or 3.")
        
        print("-" * 50)

# Run the chatbot program:
if __name__ == "__main__":
    healthcare_chatbot()