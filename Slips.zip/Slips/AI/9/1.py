# Q1. Write a Program to Implement Depth First Search using Python. [10 Marks]

def dfs(graph, start_node, visited=None, traversal_order=None):
    if visited is None:
        visited = set()
    if traversal_order is None:
        traversal_order = []
        
    visited.add(start_node)
    traversal_order.append(start_node)
    
    for neighbor in graph.get(start_node, []):
        if neighbor not in visited:
            dfs(graph, neighbor, visited, traversal_order)
            
    return traversal_order

# Example usage:
if __name__ == "__main__":
    # Graph represented as an adjacency list
    graph = {
        'A': ['B', 'C'],
        'B': ['D', 'E'],
        'C': ['F'],
        'D': [],
        'E': ['F'],
        'F': []
    }
    
    start = 'A'
    print(f"Depth First Search starting from node '{start}':")
    result = dfs(graph, start)
    print(" -> ".join(result))