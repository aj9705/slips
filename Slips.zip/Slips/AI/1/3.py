# OR: Q2. Write a Program to Implement Monkey Banana Problem using Python. [20 Marks]

# File Name: monkey_banana.py

def solve_monkey_banana():
    print("=== Monkey and Banana Problem Solver ===")
    
    # Extension feature: Dynamic state dictionary simulation tracking positions in real-time
    state = {"monkey": "A", "box": "B", "on_box": False, "banana": "C", "has_banana": False}
    
    actions = [
        ("Monkey moves from A to B", lambda s: s.update({"monkey": "B"})),
        ("Monkey pushes the box from B to C (under the banana)", lambda s: s.update({"box": "C", "monkey": "C"})),
        ("Monkey climbs up onto the box", lambda s: s.update({"on_box": True})),
        ("Monkey reaches and grabs the banana!", lambda s: s.update({"has_banana": True}))
    ]
    
    for step_num, (description, action) in enumerate(actions, 1):
        print(f"\nStep {step_num}: {description}")
        action(state)
        print(f"Current State -> Monkey: {state['monkey']}, Box: {state['box']}, On Box: {state['on_box']}, Has Banana: {state['has_banana']}")
        
    print("\nGoal Achieved: The monkey successfully got the banana!")

solve_monkey_banana()