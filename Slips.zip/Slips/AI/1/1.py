# Q1. Implement Dijkstra's Algorithm to find the shortest path from a single source for the following graph G. [10 Marks]

import heapq

def dijkstra_with_path(graph, start, goal):
    distances = {node: float('inf') for node in graph}
    previous_nodes = {node: None for node in graph}
    distances[start] = 0
    pq = [(0, start)]
    
    while pq:
        current_distance, current_node = heapq.heappop(pq)
        
        if current_distance > distances[current_node]:
            continue
            
        if current_node == goal:
            break
            
        for neighbor, weight in graph[current_node].items():
            distance = current_distance + weight
            if distance < distances[neighbor]:
                distances[neighbor] = distance
                previous_nodes[neighbor] = current_node
                heapq.heappush(pq, (distance, neighbor))
                
    # Extension feature: Reconstructing the exact shortest path
    path, current = [], goal
    while current:
        path.insert(0, current)
        current = previous_nodes[current]
        
    return distances[goal], path

# Graph from the image
graph_g = {
    'A': {'B': 4, 'C': 5},
    'B': {'A': 4, 'C': 11, 'D': 9, 'E': 7},
    'C': {'A': 5, 'B': 11, 'E': 3},
    'D': {'B': 9, 'E': 13, 'F': 2},
    'E': {'B': 7, 'C': 3, 'D': 13, 'F': 6},
    'F': {'D': 2, 'E': 6}
}

dist, path = dijkstra_with_path(graph_g, 'A', 'F')
print(f"Shortest distance from A to F: {dist}")
print(f"Path: {' -> '.join(path)}")