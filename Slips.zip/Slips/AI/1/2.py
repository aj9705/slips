# Q2. Write a Python program to implement Depth First Search algorithm. Refer the following graph as an input for the program. [Initial node=1,Goal node=8] [20 Marks]

# File Name: dfs_search.py

graph = {
    1: [2, 3],
    2: [4, 5],
    3: [6, 7],
    4: [8],
    5: [8],
    6: [8],
    7: [8],
    8: []
}

def find_all_dfs_paths(graph, current, goal, path=[]):
    path = path + [current]
    if current == goal:
        return [path]
    if current not in graph:
        return []
    
    # Extension feature: Finding ALL unique paths from start to goal via DFS
    all_paths = []
    for neighbor in graph[current]:
        if neighbor not in path:
            new_paths = find_all_dfs_paths(graph, neighbor, goal, path)
            all_paths.extend(new_paths)
            
    return all_paths

initial_node = 1
goal_node = 8
all_paths = find_all_dfs_paths(graph, initial_node, goal_node)

print(f"All possible DFS paths from {initial_node} to {goal_node}:")
for p in all_paths:
    print(" -> ".join(map(str, p)))