# Q2. Implement Minimum Spanning Tree using Kruskal's Algorithm. [20 Marks]

class DisjointSet:
    def __init__(self, vertices):
        self.parent = {v: v for v in vertices}
        self.rank = {v: 0 for v in vertices}

    def find(self, i):
        if self.parent[i] == i:
            return i
        self.parent[i] = self.find(self.parent[i])
        return self.parent[i]

    def union(self, i, j):
        root_i = self.find(i)
        root_j = self.find(j)

        if root_i != root_j:
            if self.rank[root_i] < self.rank[root_j]:
                self.parent[root_i] = root_j
            elif self.rank[root_i] > self.rank[root_j]:
                self.parent[root_j] = root_i
            else:
                self.parent[root_j] = root_i
                self.rank[root_i] += 1

def kruskal_mst(vertices, edges):
    # Edges format: (weight, u, v)
    edges.sort()
    ds = DisjointSet(vertices)
    mst = []
    total_cost = 0

    for weight, u, v in edges:
        if ds.find(u) != ds.find(v):
            ds.union(u, v)
            mst.append((u, v, weight))
            total_cost += weight

    return mst, total_cost

# Example usage:
if __name__ == "__main__":
    vertices = ['A', 'B', 'C', 'D', 'E']
    # List of edges: (weight, u, v)
    edges = [
        (1, 'A', 'B'),
        (3, 'A', 'C'),
        (3, 'B', 'C'),
        (6, 'B', 'D'),
        (4, 'C', 'D'),
        (2, 'C', 'E'),
        (5, 'D', 'E')
    ]
    
    mst, cost = kruskal_mst(vertices, edges)
    print("Minimum Spanning Tree using Kruskal's Algorithm:")
    for u, v, w in mst:
        print(f"Edge: {u} - {v} with weight {w}")
    print(f"Total Cost of MST: {cost}")