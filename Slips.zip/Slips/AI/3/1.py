# Q1. Given an array of integers, write a Python Program to sort the array in ascending order using Selection Sort. [10 Marks]

def selection_sort(arr):
    n = len(arr)
    for i in range(n):
        # Assume the first element of the unsorted portion is the minimum
        min_idx = i
        for j in range(i + 1, n):
            if arr[j] < arr[min_idx]:
                min_idx = j
        
        # Swap the found minimum element with the first element of the unsorted portion
        arr[i], arr[min_idx] = arr[min_idx], arr[i]
        
    return arr

# Example usage:
if __name__ == "__main__":
    sample_array = [64, 25, 12, 22, 11]
    print(f"Original Array: {sample_array}")
    sorted_array = selection_sort(sample_array)
    print(f"Sorted Array in Ascending Order: {sorted_array}")
