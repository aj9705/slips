# Q2. Write a Program to implement 8-Puzzle problem using Python. [20 Marks]

# File Name: eight_puzzle.py

import heapq

class PuzzleNode:
    def __init__(self, board, parent, move, depth, cost):
        self.board = board
        self.parent = parent
        self.move = move
        self.depth = depth
        self.cost = cost
        self.index = board.index(0) # Find position of blank space (0)

    def __lt__(self, other):
        return self.cost < other.cost

def calculate_manhattan(board, goal):
    distance = 0
    for i in range(9):
        val = board[i]
        if val != 0:
            target_idx = goal.index(val)
            distance += abs(i // 3 - target_idx // 3) + abs(i % 3 - target_idx % 3)
    return distance

def get_neighbors(node):
    neighbors = []
    r, c = node.index // 3, node.index % 3
    directions = [("UP", -1, 0), ("DOWN", 1, 0), ("LEFT", 0, -1), ("RIGHT", 0, 1)]

    for move, dr, dc in directions:
        nr, nc = r + dr, c + dc
        if 0 <= nr < 3 and 0 <= nc < 3:
            new_idx = nr * 3 + nc
            new_board = list(node.board)
            # Swap blank with neighbor
            new_board[node.index], new_board[new_idx] = new_board[new_idx], new_board[node.index]
            neighbors.append(PuzzleNode(tuple(new_board), node, move, node.depth + 1, 0))

    return neighbors

def solve_8_puzzle(start, goal):
    initial_node = PuzzleNode(start, None, "START", 0, 0)
    initial_node.cost = initial_node.depth + calculate_manhattan(start, goal)
    
    pq = []
    heapq.heappush(pq, (initial_node.cost, initial_node))
    explored = set()

    while pq:
        _, current = heapq.heappop(pq)

        if current.board == goal:
            path = []
            while current.parent:
                path.append((current.move, current.board))
                current = current.parent
            return path[::-1]

        explored.add(current.board)

        for neighbor in get_neighbors(current):
            if neighbor.board in explored:
                continue
            neighbor.cost = neighbor.depth + calculate_manhattan(neighbor.board, goal)
            heapq.heappush(pq, (neighbor.cost, neighbor))

    return None

# Example usage:
if __name__ == "__main__":
    initial_state = (1, 2, 3, 
                     8, 0, 4, 
                     7, 6, 5)
    goal_state =    (1, 2, 3, 
                     8, 4, 0, 
                     7, 6, 5)
    
    print("Solving 8-Puzzle Problem...")
    solution_path = solve_8_puzzle(initial_state, goal_state)
    
    if solution_path:
        print(f"Solution found in {len(solution_path)} steps:")
        for step, (move, board) in enumerate(solution_path, 1):
            print(f"Step {step}: Move {move}")
            for i in range(0, 9, 3):
                print(f" {board[i]} {board[i+1]} {board[i+2]} ")
            print("-" * 10)
    else:
        print("No solution found.")
