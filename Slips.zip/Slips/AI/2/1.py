# Q1. Write a Program to Implement Depth First Search using Python. [10 Marks]

# File Name: dfs_graph.py

# Graph representation based on the provided image input
graph = {
    1: [2, 3, 4],
    2: [1, 4, 5],
    3: [1, 4],
    4: [1, 2, 3, 7],
    5: [2, 6, 7],
    6: [5, 7],
    7: [4, 5, 6]
}

def dfs(current_node, goal_node, visited=None, path=None):
    if visited is None:
        visited = set()
    if path is None:
        path = []
        
    visited.add(current_node)
    path.append(current_node)
    
    if current_node == goal_node:
        return path
        
    for neighbor in graph.get(current_node, []):
        if neighbor not in visited:
            result = dfs(neighbor, goal_node, visited, path)
            if result:
                return result
                
    path.pop()  # Backtrack if goal is not found in this branch
    return None

# Execution example: Finding path from node 1 to node 6
initial_node = 1
goal_node = 6
path = dfs(initial_node, goal_node)

print(f"DFS Traversal Path from {initial_node} to {goal_node}: {' -> '.join(map(str, path))}")