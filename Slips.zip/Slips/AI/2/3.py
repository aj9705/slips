# Q2. Write a Program to Implement Tic-Tac-Toe game using Python. [20 Marks]

# File Name: tictactoe.py

def print_board(board):
    print("\n")
    for i in range(0, 9, 3):
        print(f" {board[i]} | {board[i+1]} | {board[i+2]} ")
        if i < 6:
            print("---|---|---")
    print("\n")

def check_winner(board, player):
    win_combinations = [
        [0, 1, 2], [3, 4, 5], [6, 7, 8], # Rows
        [0, 3, 6], [1, 4, 7], [2, 5, 8], # Columns
        [0, 4, 8], [2, 4, 6]            # Diagonals
    ]
    return any(all(board[spot] == player for spot in combo) for combo in win_combinations)

def tic_tac_toe():
    board = [str(i) for i in range(1, 10)]
    current_player = "X"
    
    print("=== Tic-Tac-Toe Game ===")
    for turn in range(9):
        print_board(board)
        move = input(f"Player {current_player}, choose slot (1-9): ")
        
        if not move.isdigit() or not (1 <= int(move) <= 9):
            print("Invalid input! Choose a number between 1 and 9.")
            continue
            
        index = int(move) - 1
        if board[index] in ["X", "O"]:
            print("Spot already taken! Try another one.")
            continue
            
        board[index] = current_player
        
        if check_winner(board, current_player):
            print_board(board)
            print(f"Congratulations! Player {current_player} wins!")
            return
            
        current_player = "O" if current_player == "X" else "X"
        
    print_board(board)
    print("It's a tie!")

# To run the interactive game, uncomment the line below:
# tic_tac_toe()
# Q2. Write a Program to Implement Tic-Tac-Toe game using Python. [20 Marks]

# File Name: tictactoe.py

def print_board(board):
    print("\n")
    for i in range(0, 9, 3):
        print(f" {board[i]} | {board[i+1]} | {board[i+2]} ")
        if i < 6:
            print("---|---|---")
    print("\n")

def check_winner(board, player):
    win_combinations = [
        [0, 1, 2], [3, 4, 5], [6, 7, 8], # Rows
        [0, 3, 6], [1, 4, 7], [2, 5, 8], # Columns
        [0, 4, 8], [2, 4, 6]            # Diagonals
    ]
    return any(all(board[spot] == player for spot in combo) for combo in win_combinations)

def tic_tac_toe():
    board = [str(i) for i in range(1, 10)]
    current_player = "X"
    
    print("=== Tic-Tac-Toe Game ===")
    for turn in range(9):
        print_board(board)
        move = input(f"Player {current_player}, choose slot (1-9): ")
        
        if not move.isdigit() or not (1 <= int(move) <= 9):
            print("Invalid input! Choose a number between 1 and 9.")
            continue
            
        index = int(move) - 1
        if board[index] in ["X", "O"]:
            print("Spot already taken! Try another one.")
            continue
            
        board[index] = current_player
        
        if check_winner(board, current_player):
            print_board(board)
            print(f"Congratulations! Player {current_player} wins!")
            return
            
        current_player = "O" if current_player == "X" else "X"
        
    print_board(board)
    print("It's a tie!")

# Run the interactive game:
tic_tac_toe()