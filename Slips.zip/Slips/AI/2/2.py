# Q2. Write a program to implement A* algorithm. [20 Marks]
# File Name: a_star.py

import heapq

def a_star_search(graph, heuristics, start, goal):
    # Priority queue stores: (f_score, g_score, current_node, path)
    pq = [(heuristics[start], 0, start, [start])]
    visited = set()
    
    while pq:
        f, g, current, path = heapq.heappop(pq)
        
        if current == goal:
            return path, g
            
        if current in visited:
            continue
        visited.add(current)
        
        for neighbor, weight in graph.get(current, {}).items():
            if neighbor not in visited:
                tentative_g = g + weight
                tentative_f = tentative_g + heuristics.get(neighbor, 0)
                heapq.heappush(pq, (tentative_f, tentative_g, neighbor, path + [neighbor]))
                
    return None, float('inf')

# Sample graph structure and heuristic values
graph = {
    'A': {'B': 1, 'C': 4},
    'B': {'A': 1, 'D': 2, 'E': 5},
    'C': {'A': 4, 'F': 3},
    'D': {'B': 2, 'G': 1},
    'E': {'B': 5, 'G': 2},
    'F': {'C': 3, 'G': 5},
    'G': {'D': 1, 'E': 2, 'F': 5}
}

heuristics = {
    'A': 7, 'B': 6, 'C': 2, 'D': 1, 'E': 3, 'F': 4, 'G': 0
}

path, cost = a_star_search(graph, heuristics, 'A', 'G')
print(f"A* Shortest Path: {' -> '.join(path)} with Total Cost: {cost}")