# Q2. Write a program to implement A* algorithm. [20 Marks]

import heapq

def a_star_search(graph, heuristics, start, goal):
    """
    Implements the A* Search algorithm to find the optimal path from start to goal
    using path cost g(n) and heuristic estimate h(n).
    """
    # Priority queue stores tuples of (f_score, current_node, path, g_score)
    pq = [(heuristics[start], start, [start], 0)]
    visited = set()
    
    while pq:
        f, current, path, g = heapq.heappop(pq)
        
        if current == goal:
            return path, g
            
        if current in visited:
            continue
        visited.add(current)
        
        for neighbor, weight in graph.get(current, []):
            if neighbor not in visited:
                new_g = g + weight
                new_f = new_g + heuristics.get(neighbor, 0)
                new_path = path + [neighbor]
                heapq.heappush(pq, (new_f, neighbor, new_path, new_g))
                
    return None, float('inf')

# Example graph represented as an adjacency list with edge weights: {node: [(neighbor, cost), ...]}
graph = {
    'S': [('A', 1), ('G', 10)],
    'A': [('B', 2), ('C', 1)],
    'B': [('D', 5)],
    'C': [('D', 3), ('G', 4)],
    'D': [('G', 2)],
    'G': []
}

# Heuristic values (estimated cost from each node to the goal node 'G')
heuristics = {
    'S': 5,
    'A': 3,
    'B': 4,
    'C': 2,
    'D': 1,
    'G': 0
}

if __name__ == "__main__":
    start_node = 'S'
    goal_node = 'G'
    
    print(f"--- A* Search Algorithm (Start: {start_node}, Goal: {goal_node}) ---")
    path, total_cost = a_star_search(graph, heuristics, start_node, goal_node)
    
    if path:
        print(f"\nGoal '{goal_node}' successfully reached!")
        print(f"Optimal Path: {' -> '.join(path)}")
        print(f"Total Cost (g-score): {total_cost}")
    else:
        print(f"\nGoal '{goal_node}' could not be reached from '{start_node}'.")