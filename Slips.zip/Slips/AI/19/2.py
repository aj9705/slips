# Q2. Write a Python program to implement Breadth First Search algorithm. Refer the following graph as an Input for the program.[Initial node=1,Goal node=8] [20 Marks]

from collections import deque

def bfs_path(graph, start, goal):
    """
    Implements Breadth-First Search to find the shortest path 
    from the start node to the goal node in a directed graph.
    """
    queue = deque([[start]])
    visited = {start}
    
    while queue:
        path = queue.popleft()
        current = path[-1]
        
        if current == goal:
            return path
            
        for neighbor in graph.get(current, []):
            if neighbor not in visited:
                visited.add(neighbor)
                new_path = list(path)
                new_path.append(neighbor)
                queue.append(new_path)
                
    return None

# Graph adjacency list representation based on the input graph structure in the image[cite: 4]:
graph = {
    1: [2, 4],
    2: [3],
    3: [4, 5, 6],
    4: [2],
    5: [7, 8],
    6: [8],
    7: [8],
    8: []
}

if __name__ == "__main__":
    initial_node = 1
    goal_node = 8
    
    print(f"--- Breadth-First Search (Initial Node: {initial_node}, Goal Node: {goal_node}) ---")
    path = bfs_path(graph, initial_node, goal_node)
    
    if path:
        print(f"\nGoal '{goal_node}' successfully reached!")
        print(f"Traversal Path: {' -> '.join(map(str, path))}")
        print(f"Total steps (cost): {len(path) - 1}")
    else:
        print(f"\nGoal '{goal_node}' could not be reached from initial node '{initial_node}'.")