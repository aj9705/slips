# Q2. Write a program to implement AO* algorithm. [20 Marks]

class Graph:
    def __init__(self, adjacency_list, heuristic):
        self.adjacency_list = adjacency_list
        self.heuristic = heuristic

    def get_neighbors(self, v):
        return self.adjacency_list.get(v, [])

    def get_heuristic(self, v):
        return self.heuristic.get(v, 0)

    def set_heuristic(self, v, h):
        self.heuristic[v] = h

    def apply_ao_star(self, start_node):
        """
        Performs AO* search on the AND-OR graph.
        """
        print(f"Evaluating node: {start_node}")
        
        # Base case: if node has no outgoing edges (leaf node)
        if start_node not in self.adjacency_list or not self.adjacency_list[start_node]:
            return self.get_heuristic(start_node)

        min_cost = float('inf')
        best_path = None

        # Explore each branch (OR choices, where each branch can contain multiple nodes forming an AND condition)
        for branch in self.adjacency_list[start_node]:
            current_cost = 0
            
            for node, weight in branch:
                cost = weight + self.apply_ao_star(node)
                current_cost += cost
            
            if current_cost < min_cost:
                min_cost = current_cost
                best_path = branch

        self.set_heuristic(start_node, min_cost)
        return min_cost

if __name__ == "__main__":
    # Example AND-OR Graph representation:
    # Each node maps to a list of branches (OR). Each branch is a list of tuples: (child_node, edge_weight).
    # Multiple nodes in a single branch represent an AND condition.
    adjacency_list = {
        'A': [[('B', 1), ('C', 1)], [('D', 2)]],
        'B': [[('E', 3), ('F', 3)]],
        'C': [[('G', 2)]],
        'D': [[('H', 4)]],
        'E': [],
        'F': [],
        'G': [],
        'H': []
    }

    # Initial heuristic values for each node
    heuristic = {
        'A': 10,
        'B': 5,
        'C': 2,
        'D': 4,
        'E': 0,
        'F': 0,
        'G': 0,
        'H': 0
    }

    print("--- AO* Algorithm Execution ---")
    graph = Graph(adjacency_list, heuristic)
    optimal_cost = graph.apply_ao_star('A')
    
    print(f"\nOptimal Cost for start node 'A': {optimal_cost}")
    print(f"Final Updated Heuristics/Costs: {graph.heuristic}")